const { env } = process;

if (env.BROWSER) {
  throw new Error(
    'Do not import `config.js` from inside the client-side code.',
  );
}
const hostname = require('os').hostname();

const smartpassPublicBase = env.SMARTPASS_PUBLIC_BASE || '';
const topLevelUrl = smartpassPublicBase
  .replace(/https?:\/\//, '')
  .split('/')
  .shift();

const topLevelDomain = topLevelUrl
  ? topLevelUrl.replace(/(.+?)\.(.+?)\.(.+)/, '.$2.$3')
  : '';

const protocol = env.PROTOCOL || 'http';

const isProduction = env.NODE_ENV === 'production';
if (!isProduction) {
  // add vars from .env to env
  const dotenv = require('dotenv').config(); // eslint-disable-line global-require
  if (dotenv.error) {
    require('dotenv').config({ path: '../../../.env' }); // eslint-disable-line global-require
  }
}

const smartpassBala3nadhUuidMaxAge = env.SMARTPASS_bala3nadh_UUID_MAX_AGE
  ? parseInt(env.SMARTPASS_bala3nadh_UUID_MAX_AGE, 10)
  : 2 * 60 * 60;

env.APP_PORT = env.APP_PORT || '3000';

if (env.APP_BEHIND_PROXY === undefined) {
  env.APP_BEHIND_PROXY = 'false';
}
if (env.APP_OVER_HTTPS === undefined) {
  env.APP_OVER_HTTPS = 'false';
}
if (env.APP_DEMO_LOGIN === undefined) {
  env.APP_DEMO_LOGIN = 'false';
}
env.COMPOSE_PROJECT_NAME = env.COMPOSE_PROJECT_NAME || 'COMPOSE_PROJECT_NAME';
env.APP_PORT = env.APP_PORT || '3000';
env.API_CLIENT_URL = env.API_CLIENT_URL || '';
env.API_SERVER_URL =
  env.API_SERVER_URL || `${protocol}://${hostname}:${env.APP_PORT}`;

const config = {
  env: env.NODE_ENV,
  // Node.js app
  projectName: env.COMPOSE_PROJECT_NAME,
  port: env.APP_PORT,
  behindProxy: !(env.APP_BEHIND_PROXY === 'false'),
  overHttps: !(env.APP_OVER_HTTPS === 'false'),
  demoLogin: !(env.APP_DEMO_LOGIN === 'false'),
  sesSecret: env.SESSION_SECRET || '',
  journeyId: env.JOURNEY_ID,
  targetDomain: env.TARGET_DOMAIN || topLevelDomain,
  // APID
  api: {
    // API URL to be used in the client-side code
    clientUrl: env.API_CLIENT_URL,
    // API URL to be used in the server-side code
    serverUrl: env.API_SERVER_URL,
  },
  // Bunyan Logger
  log: {
    level: env.LOG_LEVEL || 'error',
    directory: env.LOG_PATH || '.',
    types: env.LOG_TYPES ? env.LOG_TYPES.split(',') : ['console'],
  },

  eventTracker: {
    host: env.EVENT_TRACKER_HOST,
  },

  basePath: env.APP_NESTED_PATH || '',
  ioTools: {
    host: env.IO_TOOLS_SERVICE_HOST,
    apolloEndpoint: env.IO_TOOLS_SERVICE_APOLLO_ENDPOINT,
  },
  smartpass: {
    host: {
      public:
        env.SMARTPASS_PUBLIC_BASE ||
        'https://stage-api.bala3nadh.abudhabi/gateway/Bala3nadhJourneySmartpassClient/1.0',
      private:
        env.SMARTPASS_PRIVATE_BASE ||
        'https://stage-sgs.api.abudhabi.ae/gateway/Bala3nadhJourneySession-store-mgmt/1.0',
    },
    endpoints: {
      generateBala3nadhUuid: env.SMARTPASS_GENERATE_bala3nadh_UUID_ENDPOINT,
    },
    authCookies: env.SMARTPASS_AUTH_COOKEIS,
    bala3nadhUuid: {
      maxAge: smartpassBala3nadhUuidMaxAge * 1000, // 2 hours in milliseconds
    },
  },
  uaepass: {
    host: env.UAEPASS_MICROSERVICE_BASE,
    endpoints: {
      signDocument: env.UAEPASS_SIGN_DOCUMENT_ENDPOINT,
      downloadSignedDocument: env.UAEPASS_DOWNLOAD_SIGNED_DOCUMENT_ENDPOINT,
    },
  },

  cms: {
    host: env.CMS_HOST,
    auth: {
      domain: env.CMS_AUTH_DOMAIN,
      username: env.CMS_AUTH_USERNAME,
      password: env.CMS_AUTH_PASSWORD,
    },
    baseCacheDir: env.CMS_BASE_CACHE_DIR || 'public/cms',
    translations: {
      endpoint: env.CMS_TRANSLATIONS_ENDPOINT,
      key: env.CMS_TRANSLATIONS_KEY,
      directory: env.CMS_TRANSLATIONS_CACHE_DIR || 'translations',
    },
    templates: {
      endpoint: env.CMS_TEMPLATES_ENDPOINT,
      directory: env.CMS_TEMPLATES_CACHE_DIR || 'templates',
    },
    journeyItems: {
      endpoint: env.CMS_JOURNEY_ITEMS_ENDPOINT,
      directory: env.CMS_JOURNEY_ITEMS_CACHE_DIR || 'journey-items',
      linkHost: env.CMS_JOURNEY_ITEMS_LINK_HOST,
    },
    journeyInfo: {
      endpoint: env.CMS_JOURNEY_INFO_ENDPOINT,
      directory: env.CMS_JOURNEY_INFO_CACHE_DIR || 'journey-info',
    },
    search: {
      globalSearchEndpoint: env.CMS_SEARCH_ENDPOINT,
      searchFiltersEndpoint: env.CMS_SEARCH_FILTERS_ENDPOINT,
      searchAutoSuggest: env.CMS_SEARCH_AUTO_SUGGEST_ENDPOINT,
      autoSuggest: env.CMS_SEARCH_AUTO_SUGGEST_ENDPOINT,
    },
    category: {
      categoryListEndpoint: env.CMS_CATEGORY_LIST_ENDPOINT,
      categoryInfoEndpoint: env.CMS_CATEGORY_INFO_ENDPOINT,
      categoryAutoSuggestEndpoint: env.CMS_CATEGORY_AUTO_SUGGEST_ENDPOINT,
      categorySearchEndpoint: env.CMS_CATEGORY_SEARCH_ENDPOINT,
    },
    bala3nadhUrl: env.bala3nadh_URL,
    bala3nadhWorkbenchUrl: env.bala3nadh_WORKBENCH_URL,
  },

  documentStore: {
    host: env.DOCUMENT_STORE_HOST,
    appId: env.DOCUMENT_STORE_APP_ID,
    userId: env.DOCUMENT_STORE_USER_ID,
    stage: env.DOCUMENT_STORE_UPLOAD_STAGE,
  },

  gsp: {
    host: env.GSP_HOST,
    baseCacheDir: env.GSP_BASE_CACHE_DIR || 'public/gsp',
    services: {
      endpoint: env.GSP_SERVICES_ENDPOINT,
    },
    servicesAll: {
      adgeList: env.GSP_ADGE_LIST_ENDPOINT,
      adgeServiceList: env.GSP_SERVICES_BY_ADGE_ENDPOINT,
      kioskLocations: env.GSP_KIOSK_ENDPOINT,
      serviceCenters: env.GSP_SERVICE_CENTERS_ENDPOINT,
      serviceByPath: env.GSP_SERVICE_BY_PATH_ENDPOINT,
      cacheDir: env.GSP_PATH_BASE_CACHE_DIR || 'public/gsp-path',
    },
    serviceByCode: {
      endpoint: env.GSP_SERVICE_BY_CODE,
    },
  },

  sense: {
    key: env.SENSE_ANALYTICS_KEY,
  },

  adu: {
    host: env.ADU_MICROSERVICE_HOST,
  },
  globalContext: {
    endpoint: env.GLOBAL_CONTEXT_MICROSERVICE,
  },
  journeyTracker: {
    host: env.JOURNEY_TRACKER_HOST,
    endpoints: {
      upsert: env.JOURNEY_TRACKER_UPSERT_ENDPOINT,
      getList: env.JOURNEY_TRACKER_GET_LIST_ENDPOINT,
      getJourneyInstance: env.JOURNEY_TRACKER_GET_JOURNEY_INSTANCE,
    },
  },
  applicationTracker: {
    host: env.APPLICATION_TRACKER_HOST,
    endpoints: {
      getApplicationList: env.APPLICATION_TRACKER_GET_APPLICATION_LIST,
    },
  },
  eligibilityEngine: {
    host: env.ELIGIBILITY_ENGINE_HOST,
    endpoints: {
      checkEligibilityWithCriteria:
        env.ELIGIBILITY_ENGINE_CHECK_ELIGIBILITY_WITH_CRITERIA,
    },
  },
  documentConverter: {
    host: env.DOCUMENT_CONVERTER_HOST,
    endpoints: {
      htmlToPdf: env.DOCUMENT_CONVERTER_PDF_ENDPOINT,
    },
  },
  adlServicesInProgress: {
    host: env.ADLOCKER_SERVICES_IN_PROGRESS_HOST,
    endpoints: {
      upsert: env.ADLOCKER_SERVICES_IN_PROGRESS_UPSERT_ENDPOINT,
    },
  },
  serviceApiBaseUrl: env.SERVICE_API_BASE_URL,

  gateway: {
    header: process.env.API_GATEWAY_HEADER || '',
    key: process.env.API_GATEWAY_KEY || '',
  },

  staticUrl: env.STATIC_URL || '',
  analyticsAppKey: env.ANALYTICS_APP_KEY || '',
  analyticsHost: env.ANALYTICS_HOST || '',

  adFeedbackUrl: env.ADFEEDBACK_URL || '',
  jiraBoard: env.JIRA_BOARD || '',
  jiraFields: env.JIRA_FIELDS || '{}',
  ded: {
    password: env.DED_PASSWORD,
    userId: env.DED_USER_ID,
    agency: env.DED_AGENCY,
  },

  adpf: {
    token: env.ADPF_TOKEN || '',
  },

  featureFlags: env.FEATURE_FLAGS,

  io: {
    db: env.IO_URL,
    memory: env.IO_MEMORY_URL,
  },
  oop: {
    host: env.OOP_HOST || '',
    endpoints: {
      serviceFields: env.OOP_SERVICE_FIELDS_ENDPOINT,
      serviceFieldsData: env.OOP_SERVICE_FIELDS_DATA_ENDPOINT,
      record: env.OOP_RECORD_ENDPOINT,
      profileItems: env.OOP_PROFILE_ITEMS_ENDPOINT,
    },
    useMockUser: env.OOP_USE_MOCK_USER === 'true',
  },
  onwani: {
    host: env.ONWANI_HOST,
    endpoints: {
      onwaniSearch: env.ONWANI_SEARCH_ENDPOINT,
    },
  },
  proxyAuthEndpoints: (env.PROXY_AUTH_ENABLED_ENPOINTS || '').split(','),
  camunda: {
    processName: env.CAMUNDA_ID_PROCESS_NAME || '',
  },
  proxyTestMiddleware: parseInt(env.PROXY_TEST_MIDDLEWARE || '0', 10),
  doe: {
    sitePlanUsername: env.SITE_PLAN_USERNAME,
    sitePlanPassword: env.SITE_PLAN_PASSWORD,
    elKeyToken: env.ELKEYTOKEN,
    elKey: env.ELKEY,
  },
};

export default config;
