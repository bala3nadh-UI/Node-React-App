import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { fetchMapData } from '@bala3nadh/oop/client/components/OnceOnlyOnwaniModal';
import baseUrl from 'client/utils/baseUrl';
import { Viewport, ViewportProvider } from '@bala3nadh/ui-lib-v2-viewport';
import './embedded.less';

export const ComposerLicensePOC = lazy(() =>
  import('./_examples/license-poc/Composer'),
);

export const ComposerExported: any = lazy(() =>
  import('./_examples/exported/Composer'),
);

export const ComposerExportedPlayground: any = lazy(() =>
  import('./_examples/exported-playground/Composer'),
);

export const ComposerCustomContent: any = lazy(() =>
  import('./_examples/custom-content/Composer'),
);

export const ComposerDashboard: any = lazy(() =>
  import('./_examples/dashboard/Composer'),
);

export const ComposerExportedBundle: any = lazy(() =>
  import('./_examples/exported-bundle/Composer'),
);

export const ComposerV5Preview = lazy(() => import('./_examples/v5/Composer'));

export const ComposerV5PreviewCommenting = lazy(() =>
  import('./_examples/v5-commenting/Composer'),
);

export const ComposerSmartQuestionnairePreview = lazy(() =>
  import('./_examples/questionnaire/Composer'),
);

export const ComposerJourneyDashboard = lazy(() =>
  import('./_examples/journey-dashboard/Composer'),
);

export const ComposerSimulator = lazy(() =>
  import('./_examples/simulator/Composer'),
);

export const ComposerDlsPlayground = lazy(() =>
  import('./_examples/dls-playground/Composer'),
);

export const ComposerOopExample = lazy(() =>
  import('./_examples/oop-example/Composer'),
);

export const ServiceComponentRoot = lazy(() =>
  import('client/components/ServiceComponentRoot'),
);

window.addEventListener('message', fetchMapData);

const App: React.FC = () => {
  return (
    <ViewportProvider>
      <Viewport sm md lg xl>
        <Router basename={baseUrl}>
          <Suspense fallback={<div>Loading...</div>}>
            <Switch>
              <Route
                path="/services/:serviceId/:serviceADGE?/:serviceNo?/:serviceName?"
                component={ServiceComponentRoot}
              />

              <Route path={['/v5', '/j/:journeyId/:stageId/:userJourneyId']}>
                <ComposerV5Preview />
              </Route>

              <Route path="/questionnaire/:questionnairePath?/:userJourneyId?/:deploymentId?">
                <ComposerSmartQuestionnairePreview />
              </Route>

              <Route path="/journeys">
                <ComposerJourneyDashboard />
              </Route>

              <Route
                path={[
                  '/simulator/:simulatorPath/:simulatorInstanceId?/:userJourneyId?/step/:stepId?',
                  '/simulator/:simulatorPath/:simulatorInstanceId?/:userJourneyId?',
                ]}
              >
                <ComposerSimulator />
              </Route>

              <Route path="/dls-playground">
                <ComposerDlsPlayground />
              </Route>

              <Route path="/oop-example">
                <ComposerOopExample />
              </Route>

              <Route path="/v5-commenting">
                <ComposerV5PreviewCommenting />
              </Route>

              <Route path="/custom-content">
                <ComposerCustomContent path="/custom-content" />
              </Route>
              <Route path="/dashboard">
                <ComposerDashboard path="/dashboard" />
              </Route>
              <Route path="/exported">
                <ComposerExported path="/exported" />
              </Route>
              <Route path="/exported-playground">
                <ComposerExportedPlayground path="/exported-playground" />
              </Route>
              <Route path="/exported-bundle">
                <ComposerExportedBundle path="/exported-bundle" />
              </Route>
              <Route path="/">
                <ComposerLicensePOC />
              </Route>
            </Switch>
          </Suspense>
        </Router>
      </Viewport>
    </ViewportProvider>
  );
};

export default App;
