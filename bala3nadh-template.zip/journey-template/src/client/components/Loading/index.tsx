import React from 'react';

function Loading() {
  return <div>Loading...</div>;
}

Loading.defaultProps = {};

export default Loading;
