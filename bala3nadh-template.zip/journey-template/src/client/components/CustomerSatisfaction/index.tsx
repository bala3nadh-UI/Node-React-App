import React, { useCallback, useState } from 'react';

import { fetchWithError } from 'client/services/fetch';

import CustomerSatisfactionComponent from '@bala3nadh/ui-lib-v2-customer-satisfaction';

interface FeedbackProps {
  i18n: any;
  serviceId: string;
  productId?: string;
  onSubmit?: any;
}

export function CustomerSatisfaction(props: FeedbackProps) {
  const [status, setStatus] = useState<
    'idle' | 'active' | 'pending' | 'success' | 'error'
  >('idle');
  const handleSubmit = useCallback(
    async (smileyType: string, options: Record<string, string>) => {
      setStatus('pending');

      try {
        const result = await fetchWithError(() => {
          setStatus('error');
        })('/pub/feedback/feedbacks', 'POST', {
          surveyType: 'service',
          smileyType,
          comments: options.comment,
          ratings: {
            clearness: options['customer_satisfaction.clear'],
            ease: options['customer_satisfaction.easy'],
            speed: options['customer_satisfaction.fast'],
            performance: options['customer_satisfaction.perf'],
          },
          pageUrl: window.location.href,
          serviceId: props.serviceId,
          productId: props.productId,
        });

        if (result.success) {
          setStatus('success');
        }
        if (props.onSubmit) await props.onSubmit(smileyType, options);
      } catch (e) {
        setStatus('error');
      }
    },
    [],
  );

  return (
    <CustomerSatisfactionComponent
      i18n={props.i18n}
      status={status}
      onSubmit={handleSubmit}
    />
  );
}

export default CustomerSatisfaction;
