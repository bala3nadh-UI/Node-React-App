import React, { ReactNode } from 'react';
import Grid from '@bala3nadh/ui-lib-v2-grid';
import classNamesHandler from 'classnames';

import './container.less';

const { Col, Row } = Grid;

function Container(props: {
  children: ReactNode;
  sidebar?: ReactNode;
  locale?: string;
  classNames?: string;
}) {
  const className = classNamesHandler('container', props.classNames);
  if (props.sidebar && props.locale === 'en') {
    return (
      <div className={className}>
        <Row gutter={20}>
          <Col xl={9} lg={8} md={12} sm={12} xs={12}>
            {props.children}
          </Col>
          <Col xl={3} lg={4} md={12} sm={12} xs={12}>
            {props.sidebar}
          </Col>
        </Row>
      </div>
    );
  }

  if (props.sidebar && props.locale === 'ar') {
    return (
      <div className={className}>
        <Row gutter={20}>
          <Col lg={4} xl={3} md={12} sm={12} xs={12}>
            {props.sidebar}
          </Col>
          <Col lg={8} xl={9} md={12} sm={12} xs={12}>
            {props.children}
          </Col>
        </Row>
      </div>
    );
  }

  return <div className={className}>{props.children}</div>;
}

function ContainerWithRowFlex(props: {
  children: ReactNode;
  sidebar?: ReactNode;
  locale?: string;
  classNames?: string;
}) {
  const className = classNamesHandler('container', props.classNames);
  if (props.sidebar) {
    return (
      <div className={className}>
        <Row flex gutter={20}>
          <Col xl={9} lg={8} md={12} sm={12} xs={12}>
            {props.children}
          </Col>
          <Col xl={3} lg={4} md={12} sm={12} xs={12}>
            {props.sidebar}
          </Col>
        </Row>
      </div>
    );
  }

  return <div className={className}>{props.children}</div>;
}

export { ContainerWithRowFlex };
export default Container;
