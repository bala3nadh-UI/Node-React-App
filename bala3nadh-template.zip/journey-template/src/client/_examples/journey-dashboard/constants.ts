export const PROCESS_NAME_WORKBENCH = 'journey-dashboard';
export const IS_PREVIEW = true;
