import config from './config';
import templates from './templates';
import translations from './localisation';

const skipFetchState: string[] = [];

export { config, templates, skipFetchState, translations };
