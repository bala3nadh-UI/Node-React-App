import page1 from './pages/request-for-issuing-permit-for-atm--payment-and-self-service-machines';
import page2 from './pages/select-permit-type';
import page3 from './pages/automatic-payment-submit-form';
import page4 from './pages/automatic-payment-form';
import page5 from './pages/automatic-payment-1';
import page6 from './pages/automatic-payment-2';
import page7 from './pages/vending-machine-1';
import page8 from './pages/various-machines';
import page9 from './pages/atm-ad-1';
import page10 from './pages/summary';
import page11 from './pages/approval-in-progress';
import page12 from './pages/application-approved';
import page13 from './pages/payment-failed';
import page14 from './pages/payment-in-progress';
import page15 from './pages/permit-issued';
import page16 from './pages/services-1';
import page17 from './pages/services';
import page18 from './pages/new-page';

import dictEn from './localization/en';
import dictAr from './localization/ar';

import symbol1 from './symbols/rIFp7n48yQM_cm-KBwxyW';
import symbol2 from './symbols/c4Z8Zav-0aQru7aHcXS3G';
import symbol3 from './symbols/hh7K8LKYM8XfcY8wDBHXV';

const config = {
  defaults: {
    title: 'Permit ATM demo',
  },
  initialState: {
    cnNumberUAE: '',
    steps_ebebbfacbc: [
      {
        label: 'Submit permit application',
        link: '',
        status: '',
        icon: '',
      },
      {
        label: 'DED Approval',
        link: '',
        status: '',
        icon: '',
      },
      {
        label: 'Payment',
        link: '',
        status: '',
        icon: '',
      },
      {
        label: 'Download certificate',
        link: '',
        status: '',
        icon: '',
      },
    ],
    currStep: 0,
    companyType: 'Abu Dhabi',
    contact: false,
    label_efcadedcab: 'ed',
    started: false,
  },
  symbols: [...symbol1, ...symbol2, ...symbol3],
  dictionary: {
    en: dictEn,
    ar: dictAr,
  },
  pages: [
    ...page1,
    ...page2,
    ...page3,
    ...page4,
    ...page5,
    ...page6,
    ...page7,
    ...page8,
    ...page9,
    ...page10,
    ...page11,
    ...page12,
    ...page13,
    ...page14,
    ...page15,
    ...page16,
    ...page17,
    ...page18,
  ],
  states: {
    initialState: {
      cnNumberUAE: '',
      steps_ebebbfacbc: [
        {
          label: 'Submit permit application',
          link: '',
          status: '',
          icon: '',
        },
        {
          label: 'DED Approval',
          link: '',
          status: '',
          icon: '',
        },
        {
          label: 'Payment',
          link: '',
          status: '',
          icon: '',
        },
        {
          label: 'Download certificate',
          link: '',
          status: '',
          icon: '',
        },
      ],
      currStep: 0,
      companyType: 'Abu Dhabi',
      contact: false,
      label_efcadedcab: 'ed',
      started: false,
    },
    newState2: {
      currStep: 1,
      steps_ebebbfacbc: [
        {
          label: 'Submit permit application',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'DED Approval',
          link: '',
          status: '',
          icon: '',
        },
        {
          label: 'Payment',
          link: '',
          status: '',
          icon: '',
        },
        {
          label: 'Download certificate',
          link: '',
          status: '',
          icon: '',
        },
      ],
    },
    newState3: {
      steps_ebebbfacbc: [
        {
          label: 'Submit permit application',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'DED Approval',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'Payment',
          link: '',
          status: 'wait',
          icon: '',
        },
        {
          label: 'Download certificate',
          link: '',
          status: '',
          icon: '',
        },
      ],
      currStep: 2,
    },
    newState4: {
      steps_ebebbfacbc: [
        {
          label: 'Submit permit application',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'DED Approval',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'Payment',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'Download certificate',
          link: '',
          status: '',
          icon: '',
        },
      ],
      currStep: 3,
    },
    newState5: {
      steps_ebebbfacbc: [
        {
          label: 'Submit permit application',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'DED Approval',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'Payment',
          link: '',
          status: 'finish',
          icon: '',
        },
        {
          label: 'Download certificate',
          link: '',
          status: 'finish',
          icon: '',
        },
      ],
      currStep: 3,
    },
    newState6: {
      started: true,
    },
  },
  hero: [
    {
      type: 'symbol',
      props: {
        symbol: 'hh7K8LKYM8XfcY8wDBHXV',
      },
    },
  ],
  sidebar: [
    {
      type: 'symbol',
      props: {
        symbol: 'c4Z8Zav-0aQru7aHcXS3G',
      },
    },
  ],
  version: '1',
};

export default config;
