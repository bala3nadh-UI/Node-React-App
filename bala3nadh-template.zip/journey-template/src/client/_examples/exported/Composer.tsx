import React, { useState, useCallback } from 'react';
import { Store } from 'redux';
import AppComposer, { IVariables } from '@bala3nadh/app-composer';
import baseUrl from 'client/utils/baseUrl';
import {
  getSmartpassData,
  getMetaData,
  getCMSData,
} from 'client/utils/appData';
import fetch from 'client/services/fetch';
import bpm from 'client/services/bpm';
import templates from 'client/_examples/v5/templates';
import formatJSConfig from 'client/utils/workbench/formatJSConfig';
import analytics from '@bala3nadh/analytics';

import '@bala3nadh/ui-lib-v2-styles/common.less';
import '@bala3nadh/ui-lib-v2-styles/colors.less';

import exported from './index';
import { StoreContext } from 'client/services/context';

const SERVER_SIDE_HANDLED = [
  '/api/smartpass/login',
  '/api/smartpass/logout',
  '/api/smartpass/demo-login',
  '/api/smartpass/demo-logout',
];

const FETCH_STATE_LONG_INTERVAL = 1000 * 15; // 1 minute

const Composer: React.FC = (props: IVariables) => {
  const { metaTags, metaPages, bala3nadhUrl, bala3nadhWorkbenchUrl } = getCMSData();
  const [store, setStore] = useState<Store | null>(null);

  const meta = {
    meta: getMetaData(),
    ...(metaTags || {}),
    ...(metaPages ? { pages: metaPages } : {}),
  };

  meta.en = {};
  meta.ar = {};

  const journeyConfig: any = formatJSConfig(exported, {
    header: {
      template: 'header',
      breadcrumbs: [
        {
          label: 'home',
          link: '#',
        },
      ],
      props: {},
    },
    footer: {
      template: 'footer',
      state: {
        mapState: ['user'],
      },
    },
  });

  const onInit = useCallback(
    (value: Store) => {
      setStore(value);
    },
    [setStore],
  );

  return (
    <StoreContext.Provider value={store}>
      <AppComposer
        config={journeyConfig.config}
        baseUrl={`${baseUrl}${props.path}`}
        user={getSmartpassData()}
        meta={meta}
        translations={journeyConfig.translations}
        serverHandled={SERVER_SIDE_HANDLED}
        fetchStateInterval={FETCH_STATE_LONG_INTERVAL}
        customTemplates={templates}
        services={{
          bala3nadhWorkbenchUrl,
          bala3nadhUrl,
          fetch,
          bpm,
          analytics,
        }}
        onInit={onInit}
      />
    </StoreContext.Provider>
  );
};

export default Composer;
