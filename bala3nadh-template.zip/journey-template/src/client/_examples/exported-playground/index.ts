import page1 from './pages/home';

import dictEn from './localization/en';
import dictAr from './localization/ar';

import symbol1 from './symbols/G4kSD5ZUGaYl6bjnqweXQ';
import symbol2 from './symbols/auT1g-eeOz0KnOZDtvTYc';
import symbol3 from './symbols/M_qE8Re-q1DZ_ozKDee02';
import symbol4 from './symbols/E8RrFec1K9t1pedCA-5xQ';
import symbol5 from './symbols/44mpEX4ihrpV1kRThjwLq';

const config = {
  version: '50',
  appName: 'profile-data-1',
  appId: '189608',
  defaults: {
    title: 'profile-data-1',
  },
  initialState: {
    customActionsArray: [],
    variable3: 'Initial value',
  },
  persistStates: [],
  symbols: [...symbol1, ...symbol2, ...symbol3, ...symbol4, ...symbol5],
  skipFetchState: [],
  pages: [...page1],
  states: {
    initialState: {
      customActionsArray: [],
      variable3: 'Initial value',
    },
    persistStates: [],
  },
  hero: [
    {
      type: 'symbol',
      props: {
        symbol: 'auT1g-eeOz0KnOZDtvTYc',
      },
      state: {
        mapState: ['customActionsArray', 'variable3'],
        mapDispatch: ['variable3'],
      },
    },
  ],
  sidebar: false,
  dictionary: {
    en: dictEn,
    ar: dictAr,
  },
};

export default config;
