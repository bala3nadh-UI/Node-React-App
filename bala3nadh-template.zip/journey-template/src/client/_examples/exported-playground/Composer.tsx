import React, { useCallback, useState, useEffect } from 'react';
import { Store } from 'redux';
import AppComposer, { IVariables } from '@bala3nadh/app-composer';
import { OnceOnlyProvider } from '@bala3nadh/oop/client';
import { CmsProvider } from 'client/services/cms/cmsContext';
import {
  getSmartpassData,
  getMetaData,
  getCMSData,
} from 'client/utils/appData';
import formatJSConfig from 'client/utils/workbench/formatJSConfig';
import { StoreContext } from 'client/services/context';
import * as componentsRefStoreService from 'client/services/componentsRefStore';
import baseUrl from 'client/utils/baseUrl';
import templates from 'client/_examples/v5/templates';

import { fetchWithError } from 'client/services/fetch';
import { BpmClient } from 'client/services/bpm';
import analytics from '@bala3nadh/analytics';
import { nanoid } from 'nanoid';
import { mapServiceData } from 'client/utils/workbench/service';
import { withRouter } from 'react-router-dom';
import withJourney from 'client/services/journey/withJourney';
import { ComposerServicesProvider } from 'client/services/ComposerServices';
import composerRedirect from 'client/services/composerRedirect';

import exported from './index';

import '@bala3nadh/ui-lib-v2-styles/common.less';
import '@bala3nadh/ui-lib-v2-styles/colors.less';

const SERVER_SIDE_HANDLED = [
  '/api/smartpass/login',
  '/api/smartpass/logout',
  '/api/smartpass/demo-login',
  '/api/smartpass/demo-logout',
];

const FETCH_STATE_LONG_INTERVAL = 1000 * 15; // 1 minute

const Composer: React.FC = (props: IVariables) => {
  const { metaTags, metaPages, bala3nadhUrl, bala3nadhWorkbenchUrl } = getCMSData();
  const [store, setStore] = useState<Store | null>(null);

  const meta = {
    meta: getMetaData(),
    ...(metaTags || {}),
    ...(metaPages ? { pages: metaPages } : {}),
    en: {},
    ar: {},
  };

  const { config: journeyConfig, translations }: any = formatJSConfig(
    exported,
    {
      header: {
        template: 'header',
        breadcrumbs: [
          {
            label: 'home',
            link: '#',
          },
        ],
        props: {},
      },
      footer: {
        template: 'footer',
        state: {
          mapState: ['user'],
        },
      },
    },
  );

  const onInit = useCallback(
    (value: Store) => {
      setStore(value);
    },
    [setStore],
  );

  return (
    <StoreContext.Provider value={store}>
      <OnceOnlyProvider baseUrl={`${baseUrl}${props.path}`}>
        <CmsProvider
          loadFromCms={journeyConfig.loadFromCms}
          pages={journeyConfig.pages}
          symbols={journeyConfig.symbols}
        >
          <ComposerServicesProvider>
            <AppComposer
              customTemplateHooks={[withJourney]}
              config={journeyConfig}
              baseUrl={`${baseUrl}${props.path}`}
              user={getSmartpassData()}
              meta={meta}
              translations={translations}
              serverHandled={SERVER_SIDE_HANDLED}
              fetchStateInterval={FETCH_STATE_LONG_INTERVAL}
              skipFetchState={[
                ...(journeyConfig.skipFetchState || []),
                '/login',
              ]}
              customTemplates={templates}
              services={{
                bala3nadhWorkbenchUrl,
                bala3nadhUrl,
                fetch: fetchWithError,
                BpmClient,
                analytics,
                refs: componentsRefStoreService,
                utils: {
                  mapServiceData,
                  nanoid,
                },
                onceOnlyHelpers: {
                  baseUrl,
                },
              }}
              onInit={onInit}
            />
          </ComposerServicesProvider>
        </CmsProvider>
      </OnceOnlyProvider>
    </StoreContext.Provider>
  );
};

export default withRouter(composerRedirect(Composer));
