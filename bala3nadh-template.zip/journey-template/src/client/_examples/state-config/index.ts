import config from './config.json';

export { config };
