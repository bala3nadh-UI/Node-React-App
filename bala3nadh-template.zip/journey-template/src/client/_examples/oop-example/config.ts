import '@bala3nadh/ui-lib-v2-styles/common.less';
import '@bala3nadh/ui-lib-v2-styles/colors.less';
import './override.less';

import home from './pages/Home';

const config = {
  version: '1.0',
  defaults: {
    title: 'OOP Examples',
  },
  initialState: {},
  header: {
    template: 'header',
    breadcrumbs: [
      {
        label: 'home',
        link: '#',
      },
      {
        label: 'businessLaunch',
        link: '#',
      },
    ],
    props: {
      aspectsOfLifeType: 'business-management',
    },
    state: {
      mapState: ['user', 'locale', 'title', 'breadcrumbs'],
      mapDispatch: ['user', 'locale'],
    },
  },
  footer: {
    template: 'footer',
    state: {
      mapState: ['user'],
    },
  },
  pages: [...home],
};

export default config;
