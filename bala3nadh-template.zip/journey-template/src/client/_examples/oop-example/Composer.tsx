import React, { useCallback, useState } from 'react';
import { Store } from 'redux';
import AppComposer from '@bala3nadh/app-composer';
import { OnceOnlyProvider } from '@bala3nadh/oop/client';
import { fetchMapData } from '@bala3nadh/oop/client/components/OnceOnlyOnwaniModal';
import baseUrl from 'client/utils/baseUrl';
import {
  getSmartpassData,
  getMetaData,
  getCMSData,
} from 'client/utils/appData';

import { config, templates, translations } from './index';
import { StoreContext } from 'client/services/context';

const SERVER_SIDE_HANDLED = [
  '/api/smartpass/login',
  '/api/smartpass/logout',
  '/api/smartpass/demo-login',
  '/api/smartpass/demo-logout',
];

const FETCH_STATE_LONG_INTERVAL = 1000 * 15; // 1 minute

window.addEventListener('message', fetchMapData);

const Composer: React.FC = () => {
  const { metaTags, metaPages } = getCMSData();
  const [store, setStore] = useState<Store | null>(null);

  const meta = {
    meta: getMetaData(),
    ...(metaTags || {}),
    ...(metaPages ? { pages: metaPages } : {}),
  };

  meta.en = {};
  meta.ar = {};

  const onInit = useCallback(
    (value: Store) => {
      setStore(value);
    },
    [setStore],
  );

  return (
    <StoreContext.Provider value={store}>
      <OnceOnlyProvider baseUrl={baseUrl}>
        <AppComposer
          config={config}
          baseUrl={`${baseUrl}/oop-example`}
          user={getSmartpassData()}
          meta={meta}
          translations={translations}
          serverHandled={SERVER_SIDE_HANDLED}
          fetchStateInterval={FETCH_STATE_LONG_INTERVAL}
          customTemplates={templates}
          onInit={onInit}
          services={{
            onceOnlyHelpers: {
              baseUrl,
            },
          }}
        />
      </OnceOnlyProvider>
    </StoreContext.Provider>
  );
};

export default Composer;
