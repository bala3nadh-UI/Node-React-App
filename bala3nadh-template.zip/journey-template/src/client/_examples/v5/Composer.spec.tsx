import React from 'react';
import { mount } from 'enzyme';
import Composer from './Composer';
import { BrowserRouter as Router } from 'react-router-dom';

jest.mock('client/utils/appData', () => ({
  getCMSData: jest.fn(() => {
    return {
      navigationItems: {
        en: [],
        ar: [],
      },
    };
  }),
  getSmartpassData: jest.fn(),
  getMetaData: jest.fn(),
  getJourneyContext: jest.fn(),
}));

describe('config/v5/Composer', () => {
  (global as any).config = {
    symbols: [],
  };
  let props: any = {};
  const render = () =>
    mount(
      <Router>
        <Composer {...props} symbols={[]} />
      </Router>,
    );
  it('renders', () => {
    const wrapper = render();
    expect(wrapper.exists()).toBeTruthy();
  });
  it('renders', () => {
    props = {
      match: {
        params: {
          userJourneyId: '222',
          journeyId: '2223',
        },
      },
    };
    const wrapper = render();
    expect(wrapper.exists()).toBeTruthy();
  });
});
