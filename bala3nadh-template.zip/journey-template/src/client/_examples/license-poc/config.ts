import { IVariables } from '@bala3nadh/app-composer';
import bpm from 'client/services/bpm';
import home from './pages/Home';
import tradeNameChecking from './pages/TradeNameChecking';
import tradeNameNotAvailable from './pages/TradeNameNotAvailable';
import tradeNameWaitingApproval from './pages/TradeNameWaitingApproval';
import tradeNameApproved from './pages/TradeNameApproved';
import tradeNameRejected from './pages/TradeNameRejected';
import licenseWaitingApproval from './pages/LicenseWaitingApproval';
import licenseApproved from './pages/LicenseApproved';
import licenseRejected from './pages/LicenseRejected';
import submitLicence from './pages/SubmitLicence';
import profile from './pages/Profile';
import '@bala3nadh/ui-lib-v2-styles/common.less';
import '@bala3nadh/ui-lib-v2-styles/colors.less';
import './override.less';
import steps, { IStep } from './steps';

interface IState {
  formEconomicName: {
    nameEn: string;
    nameAr: string;
    legalForm: string;
  };
  tradeNameEn: string;
  tradeNameAr: string;
  businessType: string;
  stepsStatus: IVariables;
  steps: IStep[];
}

const initialState: IState = {
  formEconomicName: {
    nameEn: '',
    nameAr: '',
    legalForm: '',
  },
  tradeNameEn: '',
  tradeNameAr: '',
  businessType: '',
  stepsStatus: {},
  steps,
};

const config = {
  // configuration/app version, please keep updateding
  // for now redux counts on this to disregard the old state
  version: '1.2',
  // default variables, for now title is used
  defaults: {
    title: 'Get Trade License',
  },
  getVariables: bpm.getVariables,
  // initial redux state, you can configure per your project need,
  initialState,

  header: {
    template: 'header',
    breadcrumbs: [
      {
        label: 'home',
        link: '#',
      },
      {
        label: 'businessLaunch',
        link: '#',
      },
    ],
    props: {
      aspectsOfLifeType: 'business-management',
    },
    state: {
      mapState: ['user', 'locale', 'title', 'breadcrumbs'],
      mapDispatch: ['user', 'locale'],
    },
    // hideForPaths: ['/login'],
  },
  footer: {
    template: 'footer',
    state: {
      mapState: ['user'],
    },
    // hideForPaths: ['/login'],
  },
  // pages of the application
  pages: [
    ...home,
    ...submitLicence,
    ...tradeNameChecking,
    ...tradeNameNotAvailable,
    ...tradeNameWaitingApproval,
    ...tradeNameApproved,
    ...tradeNameRejected,
    ...licenseWaitingApproval,
    ...licenseApproved,
    ...licenseRejected,
    ...profile,
  ],
};

export default config;
