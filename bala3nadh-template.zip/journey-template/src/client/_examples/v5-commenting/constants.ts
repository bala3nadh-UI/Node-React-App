export const PROCESS_NAME_WORKBENCH = 'workbench';
