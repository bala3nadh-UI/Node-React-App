import page1 from './pages/home';

import dictEn from './localization/en';
import dictAr from './localization/ar';

import symbol1 from './symbols/YTY68VoAnryWX7uLitENt';
import symbol2 from './symbols/upviKFb4l1BFN2YErkUc7';

// HOWTO: import camunda process definition ID from env file
// import {
//   getCamundaData,
// } from 'client/utils/appData';

const config = {
  version: '1',
  appName: 'CustomContentTest',
  defaults: {
    title: 'CustomContentTest',
  },
  initialState: {
    customContent: {
      componentId: 'ho-BkceGNLdRQTJrATvsx',
      type: 'text',
      props: {
        variant: 'h3',
        content: 'Service description',
        space: {
          marginTop: 'xl',
        },
      },
      sharedProps: ['i18n'],
    },
    metaData: {
      title: 'HomeInitial',
      image:
        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/TPN---Home/logo.svg',
    },
  },
  persistStates: [],
  symbols: [...symbol1, ...symbol2],
  dictionary: {
    en: dictEn,
    ar: dictAr,
  },
  skipFetchState: [],
  pages: [...page1],
  states: {
    initialState: {},
    persistStates: [],
  },
  hero: [
    {
      type: 'symbol',
      props: {
        symbol: 'YTY68VoAnryWX7uLitENt',
      },
      state: {
        mapState: [],
        mapDispatch: [],
      },
    },
  ],
  sidebar: [
    {
      type: 'symbol',
      props: {
        symbol: 'upviKFb4l1BFN2YErkUc7',
      },
    },
  ],
  // HOWTO: import camunda process definition ID from env file
  // camunda: {
  // processDefinitionId: getCamundaData().processName,
  // }
};

export default config;
