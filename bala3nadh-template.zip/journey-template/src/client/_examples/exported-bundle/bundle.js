export default /** *** */ (function (modules) {
  // webpackBootstrap
  /** *** */ // The module cache
  /** *** */ const installedModules = {}; // The require function
  /** *** */
  /** *** */ /** *** */ function __webpack_require__(moduleId) {
    /** *** */
    /** *** */ // Check if module is in cache
    /** *** */ if (installedModules[moduleId]) {
      /** *** */ return installedModules[moduleId].exports;
      /** *** */
    } // Create a new module (and put it into the cache)
    /** *** */ /** *** */ const module = (installedModules[moduleId] = {
      /** *** */ i: moduleId,
      /** *** */ l: false,
      /** *** */ exports: {},
      /** *** */
    }); // Execute the module function
    /** *** */
    /** *** */ /** *** */ modules[moduleId].call(
      module.exports,
      module,
      module.exports,
      __webpack_require__,
    ); // Flag the module as loaded
    /** *** */
    /** *** */ /** *** */ module.l = true; // Return the exports of the module
    /** *** */
    /** *** */ /** *** */ return module.exports;
    /** *** */
  } // expose the modules object (__webpack_modules__)
  /** *** */
  /** *** */
  /** *** */ /** *** */ __webpack_require__.m = modules; // expose the module cache
  /** *** */
  /** *** */ /** *** */ __webpack_require__.c = installedModules; // define getter function for harmony exports
  /** *** */
  /** *** */ /** *** */ __webpack_require__.d = function (
    exports,
    name,
    getter,
  ) {
    /** *** */ if (!__webpack_require__.o(exports, name)) {
      /** *** */ Object.defineProperty(exports, name, {
        enumerable: true,
        get: getter,
      });
      /** *** */
    }
    /** *** */
  }; // define __esModule on exports
  /** *** */
  /** *** */ /** *** */ __webpack_require__.r = function (exports) {
    /** *** */ if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
      /** *** */ Object.defineProperty(exports, Symbol.toStringTag, {
        value: 'Module',
      });
      /** *** */
    }
    /** *** */ Object.defineProperty(exports, '__esModule', { value: true });
    /** *** */
  }; // create a fake namespace object // mode & 1: value is a module id, require it // mode & 2: merge all properties of value into the ns // mode & 4: return value when already ns object // mode & 8|1: behave like require
  /** *** */
  /** *** */ /** *** */ /** *** */ /** *** */ /** *** */ /** *** */ __webpack_require__.t = function (
    value,
    mode,
  ) {
    /** *** */ if (mode & 1) value = __webpack_require__(value);
    /** *** */ if (mode & 8) return value;
    /** *** */ if (
      mode & 4 &&
      typeof value === 'object' &&
      value &&
      value.__esModule
    )
      return value;
    /** *** */ const ns = Object.create(null);
    /** *** */ __webpack_require__.r(ns);
    /** *** */ Object.defineProperty(ns, 'default', {
      enumerable: true,
      value,
    });
    /** *** */ if (mode & 2 && typeof value !== 'string')
      for (const key in value)
        __webpack_require__.d(
          ns,
          key,
          function (key) {
            return value[key];
          }.bind(null, key),
        );
    /** *** */ return ns;
    /** *** */
  }; // getDefaultExport function for compatibility with non-harmony modules
  /** *** */
  /** *** */ /** *** */ __webpack_require__.n = function (module) {
    /** *** */ const getter =
      module && module.__esModule
        ? /** *** */ function getDefault() {
            return module.default;
          }
        : /** *** */ function getModuleExports() {
            return module;
          };
    /** *** */ __webpack_require__.d(getter, 'a', getter);
    /** *** */ return getter;
    /** *** */
  }; // Object.prototype.hasOwnProperty.call
  /** *** */
  /** *** */ /** *** */ __webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  }; // __webpack_public_path__
  /** *** */
  /** *** */ /** *** */ __webpack_require__.p = ''; // Load entry module and return exports
  /** *** */
  /** *** */
  /** *** */ /** *** */ return __webpack_require__((__webpack_require__.s = 0));
  /** *** */
})(
  /** ********************************************************************* */
  /** *** */ [
    /* 0 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _pages_request_for_issuing_permit_for_atm_payment_and_self_service_machines__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        1,
      );
      /* harmony import */ const _pages_select_permit_type__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        3,
      );
      /* harmony import */ const _pages_automatic_payment_submit_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        5,
      );
      /* harmony import */ const _pages_automatic_payment_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        7,
      );
      /* harmony import */ const _pages_automatic_payment_1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
        8,
      );
      /* harmony import */ const _pages_automatic_payment_2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
        9,
      );
      /* harmony import */ const _pages_vending_machine_1__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
        10,
      );
      /* harmony import */ const _pages_various_machines__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
        11,
      );
      /* harmony import */ const _pages_atm_ad_1__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
        12,
      );
      /* harmony import */ const _pages_summary__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
        13,
      );
      /* harmony import */ const _pages_approval_in_progress__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
        15,
      );
      /* harmony import */ const _pages_application_approved__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
        17,
      );
      /* harmony import */ const _pages_payment_failed__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
        19,
      );
      /* harmony import */ const _pages_payment_in_progress__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
        21,
      );
      /* harmony import */ const _pages_permit_issued__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
        23,
      );
      /* harmony import */ const _pages_services_1__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
        25,
      );
      /* harmony import */ const _pages_services__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
        26,
      );
      /* harmony import */ const _pages_new_page__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
        27,
      );
      /* harmony import */ const _localization_en__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
        28,
      );
      /* harmony import */ const _localization_ar__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
        29,
      );
      /* harmony import */ const _symbols_rIFp7n48yQM_cm_KBwxyW__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
        30,
      );
      /* harmony import */ const _symbols_c4Z8Zav_0aQru7aHcXS3G__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
        31,
      );
      /* harmony import */ const _symbols_hh7K8LKYM8XfcY8wDBHXV__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
        33,
      );

      const config = {
        defaults: {
          title: 'Permit ATM demo',
        },
        initialState: {
          cnNumberUAE: '',
          steps_ebebbfacbc: [
            {
              label: 'Submit permit application',
              link: '',
              status: '',
              icon: '',
            },
            {
              label: 'DED Approval',
              link: '',
              status: '',
              icon: '',
            },
            {
              label: 'Payment',
              link: '',
              status: '',
              icon: '',
            },
            {
              label: 'Download certificate',
              link: '',
              status: '',
              icon: '',
            },
          ],
          currStep: 0,
          companyType: 'Abu Dhabi',
          contact: false,
          label_efcadedcab: 'ed',
          started: false,
        },
        symbols: [
          ..._symbols_rIFp7n48yQM_cm_KBwxyW__WEBPACK_IMPORTED_MODULE_20__.default,
          ..._symbols_c4Z8Zav_0aQru7aHcXS3G__WEBPACK_IMPORTED_MODULE_21__.default,
          ..._symbols_hh7K8LKYM8XfcY8wDBHXV__WEBPACK_IMPORTED_MODULE_22__.default,
        ],
        dictionary: {
          en: _localization_en__WEBPACK_IMPORTED_MODULE_18__.default,
          ar: _localization_ar__WEBPACK_IMPORTED_MODULE_19__.default,
        },
        pages: [
          ..._pages_request_for_issuing_permit_for_atm_payment_and_self_service_machines__WEBPACK_IMPORTED_MODULE_0__.default,
          ..._pages_select_permit_type__WEBPACK_IMPORTED_MODULE_1__.default,
          ..._pages_automatic_payment_submit_form__WEBPACK_IMPORTED_MODULE_2__.default,
          ..._pages_automatic_payment_form__WEBPACK_IMPORTED_MODULE_3__.default,
          ..._pages_automatic_payment_1__WEBPACK_IMPORTED_MODULE_4__.default,
          ..._pages_automatic_payment_2__WEBPACK_IMPORTED_MODULE_5__.default,
          ..._pages_vending_machine_1__WEBPACK_IMPORTED_MODULE_6__.default,
          ..._pages_various_machines__WEBPACK_IMPORTED_MODULE_7__.default,
          ..._pages_atm_ad_1__WEBPACK_IMPORTED_MODULE_8__.default,
          ..._pages_summary__WEBPACK_IMPORTED_MODULE_9__.default,
          ..._pages_approval_in_progress__WEBPACK_IMPORTED_MODULE_10__.default,
          ..._pages_application_approved__WEBPACK_IMPORTED_MODULE_11__.default,
          ..._pages_payment_failed__WEBPACK_IMPORTED_MODULE_12__.default,
          ..._pages_payment_in_progress__WEBPACK_IMPORTED_MODULE_13__.default,
          ..._pages_permit_issued__WEBPACK_IMPORTED_MODULE_14__.default,
          ..._pages_services_1__WEBPACK_IMPORTED_MODULE_15__.default,
          ..._pages_services__WEBPACK_IMPORTED_MODULE_16__.default,
          ..._pages_new_page__WEBPACK_IMPORTED_MODULE_17__.default,
        ],
        states: {
          initialState: {
            cnNumberUAE: '',
            steps_ebebbfacbc: [
              {
                label: 'Submit permit application',
                link: '',
                status: '',
                icon: '',
              },
              {
                label: 'DED Approval',
                link: '',
                status: '',
                icon: '',
              },
              {
                label: 'Payment',
                link: '',
                status: '',
                icon: '',
              },
              {
                label: 'Download certificate',
                link: '',
                status: '',
                icon: '',
              },
            ],
            currStep: 0,
            companyType: 'Abu Dhabi',
            contact: false,
            label_efcadedcab: 'ed',
            started: false,
          },
          newState2: {
            currStep: 1,
            steps_ebebbfacbc: [
              {
                label: 'Submit permit application',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'DED Approval',
                link: '',
                status: '',
                icon: '',
              },
              {
                label: 'Payment',
                link: '',
                status: '',
                icon: '',
              },
              {
                label: 'Download certificate',
                link: '',
                status: '',
                icon: '',
              },
            ],
          },
          newState3: {
            steps_ebebbfacbc: [
              {
                label: 'Submit permit application',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'DED Approval',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'Payment',
                link: '',
                status: 'wait',
                icon: '',
              },
              {
                label: 'Download certificate',
                link: '',
                status: '',
                icon: '',
              },
            ],
            currStep: 2,
          },
          newState4: {
            steps_ebebbfacbc: [
              {
                label: 'Submit permit application',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'DED Approval',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'Payment',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'Download certificate',
                link: '',
                status: '',
                icon: '',
              },
            ],
            currStep: 3,
          },
          newState5: {
            steps_ebebbfacbc: [
              {
                label: 'Submit permit application',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'DED Approval',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'Payment',
                link: '',
                status: 'finish',
                icon: '',
              },
              {
                label: 'Download certificate',
                link: '',
                status: 'finish',
                icon: '',
              },
            ],
            currStep: 3,
          },
          newState6: {
            started: true,
          },
        },
        hero: [
          {
            type: 'symbol',
            props: {
              symbol: 'hh7K8LKYM8XfcY8wDBHXV',
            },
          },
        ],
        sidebar: [
          {
            type: 'symbol',
            props: {
              symbol: 'c4Z8Zav-0aQru7aHcXS3G',
            },
          },
        ],
        version: '1',
      };
      /* harmony default export */ __webpack_exports__.default = config;

      /***/
    },
    /* 1 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        2,
      );

      const pageConfig = [
        {
          title:
            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
          pageId: '0',
          path:
            '/request-for-issuing-permit-for-atm--payment-and-self-service-machines',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: '2fcqc4XiMT41i1jLiCz9l',
                type: 'startLogin',
                props: {
                  i18n: '',
                  title: 'Start',
                  description:
                    'Obtain a permit for any machine or digital platform set up outside the retail outlet mentioned in the economic licence',
                  buttonLabel: 'Start',
                  stickToTop: false,
                  space: {
                    marginTop: 'md',
                  },
                  onClick: _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onClick,
                },
                sharedProps: ['i18n', 'history', 'actions'],
              },
              {
                componentId: 'ho-BkceGNLdRQTJrATvsx',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Service description',
                  space: {
                    marginTop: 'xl',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'gWugAtXaPRlGzCJ2Jt6Dh',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Through this service,  you can request for a permit for any machine or digital platform set up outside the retail outlet mentioned in the economic licence, either in a public or private place, to facilitate purchasing, payment, and requesting or offering any service without the need for human intervention.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'dEaFmglxlOYrpw9OM7Ny3',
                type: 'process',
                props: {
                  title: 'Process',
                  steps: [
                    {
                      id: 'k6ovawiy',
                      label: 'Select permit type',
                      description:
                        'Select the required permit and fill out the required fields.',
                    },
                    {
                      id: 'k6ovbbaz',
                      label: 'Receive response',
                      description:
                        'Receive notification for approval or rejection.',
                    },
                    {
                      id: 'k6ovbhw2',
                      label: 'Pay and receive permit',
                      description:
                        'Pay the required fees and receive the permit.',
                    },
                  ],
                  space: {
                    marginTop: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'heWxz1HnGGTsO5AtXwroU',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Required Documents',
                  space: {
                    marginTop: 'xl',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'GUEDe9H9Drr8bwuhQ8cPw',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k74cvi1s',
                      type: 'string',
                      label: 'Required Document',
                    },
                    {
                      name: 'field-2-k74cvism',
                      type: 'string',
                      label: 'Description',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k74cvi1s': 'Clarification Letter',
                      'field-2-k74cvism':
                        ' Detailed Letter from the company with the numbers and locations of the machines where the advertisement will occur.',
                    },
                    {
                      _id: 2,
                      'field-1-k74cvi1s': 'Concerned Entities Approvals',
                      'field-2-k74cvism':
                        'Approval of the related party where the machines will be placed.',
                    },
                    {
                      _id: 3,
                      'field-1-k74cvi1s': 'Related Entities Approval',
                      'field-2-k74cvism':
                        'Approval of the Central Bank (In case permit requested for the ATM).',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: '0K6a0xrF53adWULI8y6YM',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Fees',
                  space: {
                    marginTop: 'xl',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'FpcM_XqzM97MBdMN8nkDA',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Through this service,  you can request for a permit for any machine or digital platform set up outside the retail outlet mentioned in the economic licence, either in a public or private place, to facilitate purchasing, payment, and requesting or offering any service without the need for human intervention.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '0HmiYpBZHVETqZqCkhz3o',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k74cvi1s',
                      type: 'string',
                      label: 'Name',
                    },
                    {
                      name: 'field-2-k74cvism',
                      type: 'string',
                      label: 'Value',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k74cvi1s':
                        'Permit for ATM advertisements per machine per year',
                      'field-2-k74cvism': 'AED 1,000',
                    },
                    {
                      _id: 2,
                      'field-1-k74cvi1s':
                        'Permit for payment machine advertisements for each machine per year',
                      'field-2-k74cvism': 'AED 1,000',
                    },
                    {
                      _id: 3,
                      'field-1-k74cvi1s':
                        'Permit for vending refrigerators (coin operated) advertisements per each refrigerator a year',
                      'field-2-k74cvism': 'AED 1,000',
                    },
                    {
                      _id: 4,
                      'field-1-k74cvi1s':
                        'Advertising permit for other machine per year for (hot and cold drinks machines, automatic vending machines, doll machines and ice machines)',
                      'field-2-k74cvism': 'AED 500',
                    },
                    {
                      _id: 5,
                      'field-1-k74cvi1s':
                        'Advertising permit for other machines each gum vending machine per year',
                      'field-2-k74cvism': 'AED 200',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: 'qngij8ivZEM-zxt8nNLh8',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Cycle time',
                  space: {
                    marginTop: 'xl',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '_Dhv1lC6BGtdz3ELJuE4O',
                type: 'text',
                props: {
                  variant: 'p',
                  content: '5 minutes',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'kjo4SDGGFyGrwmwEdzJvk',
                type: 'helpfulBlock',
                props: {
                  i18n: '',
                  callValue: false,
                  emailField: null,
                  telephoneField: null,
                  commentField: null,
                  space: {
                    paddingTop: 'xl',
                  },
                },
                sharedProps: ['i18n'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          layout: 'base',
          step: '',
          templateId: '73',
          templateName: 'Service card DEMO',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 2 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onClick',
        function () {
          return f1_onClick;
        },
      );
      async function f1_onClick(props) {
        props.actions.mergeState('newState6');
        props.history.push('/select-permit-type');
      }

      /***/
    },
    /* 3 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        4,
      );

      const pageConfig = [
        {
          title: 'Select permit type',
          pageId: '2',
          path: '/select-permit-type',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: 'FT7oo96vl1x4h0UOK1HTJ',
                type: 'text',
                props: {
                  variant: 'h2',
                  content: 'Select permit type',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'pi2GFsNU3Tqreeoocqnwc',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Choose one of the following available permit types. For assistance or to apply for a permit not listed below please contact us.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'ShqERhdLStBc1l3VKuya-',
                type: 'businessActivities',
                props: {
                  items: [
                    {
                      id: 'k6ox7l7z',
                      title: 'ATM Ad',
                      selected: false,
                      isPackage: false,
                      onSelectToggle: {
                        type: 'func',
                        actions: [
                          {
                            type: 'goToPage',
                            link:
                              '/request-for-issuing-permit-for-atm--payment-and-self-service-machines',
                          },
                          {
                            type: 'updateState',
                          },
                        ],
                      },
                      description: '',
                    },
                    {
                      id: 'k6ox7owh',
                      title: 'Automatic Payment',
                      selected: true,
                    },
                    {
                      id: 'k6ox7pjy',
                      title: 'Various Machines Ad',
                    },
                    {
                      id: 'k6ox7q8l',
                      title: 'Vending Machine AD Permit',
                      isPackage: false,
                    },
                  ],
                  space: {
                    marginBottom: 'lg',
                  },
                },
                sharedProps: ['i18n', 'history', 'actions'],
              },
              {
                componentId: '3Z2he1CLwEqw9g3eHO68I',
                type: 'button',
                props: {
                  label: 'Continue',
                  type: 'button',
                  uiType: 'primary',
                  disabled: false,
                  'aria-label': 'button',
                  size: 'default',
                  icon: null,
                  alignIcon: 'end',
                  withArrow: true,
                  active: false,
                  hidden: false,
                  onClick: _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onClick,
                },
                sharedProps: ['i18n', 'history'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Select permit type',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
          init: _functions__WEBPACK_IMPORTED_MODULE_0__.init,
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 4 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'init',
        function () {
          return init;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onClick',
        function () {
          return f1_onClick;
        },
      );
      async function init(props) {
        props.actions.loading.update(true);
      }
      async function f1_onClick(props) {
        props.history.push('/automatic-payment-submit-form');
      }

      /***/
    },
    /* 5 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        6,
      );

      const pageConfig = [
        {
          title: 'Automatic Payment Submit Form',
          pageId: '3',
          children: [],
          expanded: true,
          path: '/automatic-payment-submit-form',
          template: 'custom',
          props: {
            BP8VxBeKWboF3UfdY1AUP: {
              fields: [
                {
                  id: 'k6oxdpnn',
                  type: 'input',
                  label: 'Field 1',
                  defaultValue: '',
                  name: 'field_0',
                },
                {
                  id: 'k6oxduqv',
                  type: 'input',
                  label: 'Field 2',
                  defaultValue: '',
                  name: 'field_1',
                },
              ],
            },
            definitions: [
              {
                componentId: 'rQhuKQciPLKzcXTknIsuR',
                type: 'text',
                props: {
                  variant: 'h2',
                  content: 'Permit Details',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'Zx2TbvLRjGQ3c1TgSgHTO',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Licence',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'D6vfX43fCgdI5TpDDUQFt',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Licences issued by Abu Dhabi Business Centre - Department of Economic Development.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'cTzIrQ46GdXchLKR1RPZ9',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    componentId: 'aUjIsbDU3lVERVRxxM8x3',
                    type: 'select',
                    props: {
                      placeholder: 'Licence number',
                      label: 'Select licence number:',
                      items: [
                        {
                          id: 'CN1',
                          label: 'CN-2123232',
                          disabled: '',
                        },
                        {
                          id: 'CN2',
                          label: 'CN-32323232',
                          disabled: '',
                        },
                      ],
                      value: null,
                      isOpen: false,
                      disabled: false,
                      isStatic: false,
                      multi: false,
                      showSearch: true,
                      validateStatus: null,
                      help: '',
                      size: 'default',
                      'aria-label': 'select-control',
                      onChange:
                        _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onChange,
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n', 'actions'],
                  },
                ],
              },
              {
                componentId: 'ksm8VjRWyjxwSg5Pjx9fn',
                type: 'text',
                props: {
                  variant: 'p',
                  content: 'or if your company is outside. of Abu Dhabi',
                  space: {
                    marginTop: 'md',
                    marginBottom: 'md',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '8z6QJgheWiTqFswyAitwF',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    componentId: 'bf3UqJzj8G8_OvUCywzbO',
                    type: 'input',
                    props: {
                      label: '${state.label_efcadedcab}',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                      onChange:
                        _functions__WEBPACK_IMPORTED_MODULE_0__.f2_onChange,
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n', 'label_efcadedcab', 'actions'],
                  },
                ],
              },
              {
                componentId: 'rR4bT4IWc-b9FaLfa3Z77',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Contact List',
                  visible: _functions__WEBPACK_IMPORTED_MODULE_0__.f3_visible,
                  space: {
                    marginTop: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'YVKbLWKlTaBoQWfI3ePGP',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Government agencies or non-local companies and local companies not licensed from the Abu Dhabi Business Center - Department of Economic Development. To add new contacts, click the Select from Account or Add New button. To add a contact, click the Edit link.',
                  visible: _functions__WEBPACK_IMPORTED_MODULE_0__.f4_visible,
                  space: {
                    marginBottom: 'md',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'rv4TrwITl_03jF3g2NUN5',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: true,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k7358jgq',
                      type: 'string',
                      label: 'Category',
                    },
                    {
                      name: 'field-2-k7358jys',
                      type: 'string',
                      label: 'Type',
                    },
                    {
                      name: 'field-3-k7358kcm',
                      type: 'string',
                      label: 'Name',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k7358jgq': 'Associated Contact',
                      'field-2-k7358jys': 'Individual',
                      'field-3-k7358kcm': 'Mohammed Khair',
                    },
                  ],
                  title: '',
                  visible: _functions__WEBPACK_IMPORTED_MODULE_0__.f5_visible,
                },
                layout: 'base',
                sharedProps: ['i18n', 'companyType'],
              },
              {
                componentId: '3NrQF6X_Tb-uOR99xHBY_',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: true,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k7358jgq',
                      type: 'string',
                      label: 'Category',
                    },
                    {
                      name: 'field-2-k7358jys',
                      type: 'string',
                      label: 'Type',
                    },
                    {
                      name: 'field-3-k7358kcm',
                      type: 'string',
                      label: 'Name',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k7358jgq': 'Associated Contact',
                      'field-2-k7358jys': 'Individual',
                      'field-3-k7358kcm': 'Alex Gvozden',
                    },
                  ],
                  title: '',
                  visible: _functions__WEBPACK_IMPORTED_MODULE_0__.f6_visible,
                },
                layout: 'base',
                sharedProps: ['i18n', 'companyType', 'contact'],
              },
              {
                componentId: 'hANlDDkp7CeJAlsKQaOEV',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '12dj0buQYhpNrt2J3qK7s',
                    type: 'button',
                    props: {
                      label: 'Add contact',
                      type: 'button',
                      uiType: 'secondary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                      onClick:
                        _functions__WEBPACK_IMPORTED_MODULE_0__.f7_onClick,
                      space: {
                        marginTop: 'lg',
                      },
                      visible:
                        _functions__WEBPACK_IMPORTED_MODULE_0__.f8_visible,
                    },
                    sharedProps: ['i18n', 'companyType', 'actions'],
                  },
                ],
              },
              {
                componentId: 'l9BX8RoWyCgEl0IEnInGC',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Info',
                  space: {
                    marginTop: 'lg',
                    marginBottom: '',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '6dirNrJhoAztn-rHYE4ts',
                type: 'grid',
                props: {
                  columns: 2,
                  space: {
                    marginTop: 'lg',
                  },
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'p1I3T8dxkaCnOJJHEJa9j',
                    type: 'input',
                    props: {
                      label: 'ADvertisement Details*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                      space: {
                        marginTop: 'md',
                      },
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'BSUhnEtIZGH9GTdFzGcGX',
                    type: 'select',
                    props: {
                      placeholder: '',
                      label: 'Advertisement Location*',
                      items: [],
                      value: null,
                      isOpen: false,
                      disabled: false,
                      isStatic: false,
                      multi: false,
                      showSearch: true,
                      validateStatus: null,
                      help: '',
                      size: 'default',
                      space: {
                        marginTop: 'md',
                      },
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hYeNOMAOmOMk209VmUdx3',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'CJ1n1G9btYsLK0-TXNFD4',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'Sk96c1wGq8bPYD7eKbzar',
                type: 'grid',
                props: {
                  columns: '02',
                  space: {
                    marginBottom: 'md',
                  },
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'oKUxot4U97-_DZPd-fwnF',
                    type: 'datePicker',
                    props: {
                      i18n: '',
                      disabledDate: '',
                      onOpenChange: '',
                      onChange: '',
                      id: '',
                      disabled: '',
                      open: '',
                      defaultValue: '',
                      value: '',
                      label: 'ADvertisement Start Date*',
                      size: 'default',
                      help: null,
                      validateStatus: '',
                      space: {
                        marginTop: 'md',
                      },
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'Dc3yhTvLqrNxnB65GU2mf',
                    type: 'datePicker',
                    props: {
                      i18n: '',
                      disabledDate: '',
                      onOpenChange: '',
                      onChange: '',
                      id: '',
                      disabled: '',
                      open: '',
                      defaultValue: '',
                      value: '',
                      label: 'ADvertisement End Date*',
                      size: 'default',
                      help: null,
                      validateStatus: '',
                      space: {
                        marginTop: 'md',
                      },
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'OsOrIx5QL2wxPPZefWcmb',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'vtDzOz1UEZr-4l6gj3vgz',
                    type: 'textArea',
                    props: {
                      label: 'Comments',
                      value: '',
                      'aria-label': 'Text area',
                      validateStatus: '',
                      size: 'default',
                      disabled: false,
                      help: '',
                      placeholder: '',
                      dataKey: '',
                      textDirection: 'ltr',
                      limit: 150,
                      space: {
                        marginTop: 'md',
                      },
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'Fyk_MvwzrXLqGlQci8wWK',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'OFItLKn-kgnGZFgbO01YM',
                    type: 'select',
                    props: {
                      placeholder: 'Select',
                      label: 'PRO Name*',
                      items: [
                        {
                          id: 'k6q561ek',
                          label: 'Item 1',
                        },
                        {
                          id: 'k6q564by',
                          label: 'item 2',
                        },
                      ],
                      value: null,
                      isOpen: false,
                      disabled: false,
                      isStatic: false,
                      multi: false,
                      showSearch: true,
                      validateStatus: null,
                      help: '',
                      size: 'default',
                      space: {
                        marginTop: 'md',
                      },
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'RWRpvktxOolxq0ruv4c9a',
                    type: 'inputTelephone',
                    props: {
                      i18n: '',
                      help: null,
                      validateStatus: '',
                      label: 'PRO Mobile NUMBER*',
                      'aria-label': 'Telephone input',
                      disabled: false,
                      value: '',
                      code: null,
                      countries: [
                        {
                          id: 'k6q56w0p',
                          name: 'United Aram Emirates',
                          code: '971',
                        },
                        {
                          id: 'k6q572lt',
                          name: 'Armenia',
                          code: '374',
                        },
                      ],
                      size: 'default',
                      space: {
                        marginTop: 'md',
                      },
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'C1u0fbK00s10eTLVR7Zy-',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '5CjpmeKrMgVW9uJTKUGp9',
                    type: 'input',
                    props: {
                      label: 'PRO Email *',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: 'email@domain.com',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                      space: {
                        marginTop: 'md',
                      },
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'I_SyoWkVOEE90NOLczc9q',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                columnIndex: 1,
                componentId: 'fHC5CsNOlpdI-6oEh96hF',
                type: 'button',
                props: {
                  label: 'Continue',
                  type: 'button',
                  uiType: 'primary',
                  disabled: false,
                  'aria-label': 'button',
                  size: 'default',
                  icon: null,
                  alignIcon: 'end',
                  withArrow: false,
                  active: false,
                  hidden: false,
                  onClick: _functions__WEBPACK_IMPORTED_MODULE_0__.f9_onClick,
                  space: {
                    marginTop: 'lg',
                    marginBottom: 'lg',
                  },
                },
                sharedProps: ['i18n', 'history'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Select Permit',
          layout: 'base',
          state: {
            mapState: [
              'started',
              'steps_ebebbfacbc',
              'currStep',
              'label_efcadedcab',
              'companyType',
              'contact',
            ],
            mapDispatch: ['companyType', 'contact'],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 6 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onChange',
        function () {
          return f1_onChange;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f2_onChange',
        function () {
          return f2_onChange;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f3_visible',
        function () {
          return f3_visible;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f4_visible',
        function () {
          return f4_visible;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f5_visible',
        function () {
          return f5_visible;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f6_visible',
        function () {
          return f6_visible;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f7_onClick',
        function () {
          return f7_onClick;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f8_visible',
        function () {
          return f8_visible;
        },
      );
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f9_onClick',
        function () {
          return f9_onClick;
        },
      );
      async function f1_onChange(props) {
        props.actions.companyType.update('Abu Dhabi');
      }
      async function f2_onChange(props) {
        props.actions.companyType.update('UAE');
      }
      function f3_visible(props) {}
      function f4_visible(props) {}
      function f5_visible(props) {
        return props.companyType === 'Abu Dhabi';
      }
      function f6_visible(props) {
        return props.companyType === 'UAE' && props.contact === true;
      }
      async function f7_onClick(props) {
        props.actions.contact.update(true);
      }
      function f8_visible(props) {
        return props.companyType === 'UAE';
      }
      async function f9_onClick(props) {
        props.history.push('/summary');
      }

      /***/
    },
    /* 7 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'Automatic Payment Form',
          pageId: 'ndDIzr9cbEFcZo_i8U9lF',
          children: [
            {
              title: 'Select Licence from Account',
              pageId: '9S27HwwGFxihLTqW4_3d1',
              path: '/select-licence-from-account',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'dtv3TGbsjpOlX6ZPdFeCx',
                    type: 'table',
                    props: {
                      size: 'default',
                      selectable: false,
                      clickable: true,
                      columns: [
                        {
                          name: 'field-1-k74rswn6',
                          type: 'string',
                          label: 'Licence Number',
                        },
                        {
                          name: 'field-2-k74rsx2p',
                          type: 'string',
                          label: 'Licence Type',
                        },
                        {
                          name: 'field-3-k74rsxht',
                          type: 'string',
                          label: 'Name',
                        },
                        {
                          name: 'field-4-k74rsy9l',
                          type: 'string',
                          label: 'Business Licence #',
                        },
                      ],
                      items: [
                        {
                          _id: 1,
                          'field-1-k74rswn6': 'CN-12312345',
                          'field-2-k74rsx2p': 'Licence',
                          'field-3-k74rsxht': "Boban's Bistro",
                        },
                        {
                          _id: 2,
                          'field-1-k74rswn6': 'CN-7931234',
                          'field-2-k74rsx2p': 'Licence',
                          'field-3-k74rsxht': "Alex's Angels",
                        },
                      ],
                      title: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hrEdYEieAarw9lW-zeLOQ',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'hBq-AW1X9-AfWKMlU8kPe',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                          onClick: {
                            type: 'func',
                            actions: [],
                          },
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'nhqH4iUQxyOuw7GOvRVI6',
                        type: 'button',
                        props: {
                          label: 'Discard changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                          onClick: {
                            type: 'func',
                            actions: [
                              {
                                type: 'goToPage',
                                link: '/automatic-payment-form',
                              },
                            ],
                          },
                        },
                        sharedProps: ['i18n', 'history'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Licenced Professional Information',
              pageId: 'sITOO1nv6HaTENKokStFW',
              path: '/licenced-professional-information',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'yUo5SmmuDwoGQR4_xwkLC',
                    type: 'input',
                    props: {
                      label: 'Licence Number*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: '5nO9Wi--h3H8Ithbw21mw',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'LXeM8EVq7wp3KtBtcpRC1',
                        type: 'button',
                        props: {
                          label: 'Save and Close',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                          onClick: {
                            type: 'func',
                            actions: [
                              {
                                type: 'goToPage',
                                link: '/automatic-payment',
                              },
                            ],
                          },
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n', 'history'],
                      },
                      {
                        componentId: 'WYJnRLq2Rf0UkrPYaatzG',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Select Contact from Account',
              pageId: 'YVZ_m61JaHuMqhU9SZorN',
              path: '/select-contact-from-account',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'hsOujF7YWcVzy70FOggOb',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Select a contact to attach to this application. If the contact has multiple addresses, you can select which to use in the next step. ',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'M_vk2FWGaBl__QKCuYkFW',
                    type: 'table',
                    props: {
                      size: 'default',
                      selectable: true,
                      clickable: true,
                      columns: [
                        {
                          name: 'field-1-k7358jgq',
                          type: 'string',
                          label: 'Category',
                        },
                        {
                          name: 'field-2-k7358jys',
                          type: 'string',
                          label: 'Type',
                        },
                        {
                          name: 'field-3-k7358kcm',
                          type: 'string',
                          label: 'Name',
                        },
                      ],
                      items: [
                        {
                          _id: 1,
                          'field-1-k7358jgq': 'Associated Contact',
                          'field-2-k7358jys': 'Individual',
                          'field-3-k7358kcm': 'Mohammed Khair',
                        },
                      ],
                      title: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hrEdYEieAarw9lW-zeLOQ',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'hBq-AW1X9-AfWKMlU8kPe',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'nhqH4iUQxyOuw7GOvRVI6',
                        type: 'button',
                        props: {
                          label: 'Discard changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Automatic Payment - 2',
              pageId: 'SVXU7i5Pu5YoYdE4Z5MQZ',
              children: [],
              path: '/automatic-payment---2',
              template: 'custom',
              props: {
                BP8VxBeKWboF3UfdY1AUP: {
                  fields: [
                    {
                      id: 'k6oxdpnn',
                      type: 'input',
                      label: 'Field 1',
                      defaultValue: '',
                      name: 'field_0',
                    },
                    {
                      id: 'k6oxduqv',
                      type: 'input',
                      label: 'Field 2',
                      defaultValue: '',
                      name: 'field_1',
                    },
                  ],
                },
                definitions: [
                  {
                    componentId: 'rQhuKQciPLKzcXTknIsuR',
                    type: 'text',
                    props: {
                      variant: 'h3',
                      content: 'Permit Details',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'U2kOU1PdEyd-MYCgVubcB',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Please enter "Licence" or "Contact", two values are not allowed. ',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'Zx2TbvLRjGQ3c1TgSgHTO',
                    type: 'text',
                    props: {
                      variant: 'h4',
                      content: 'Licence',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'D6vfX43fCgdI5TpDDUQFt',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Licences issued by Abu Dhabi Business Centre - Department of Economic Development.',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: '3JkrKzvizdLAyB9dU3mMb',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        "بوبان بيسترو Boban's Bistro Licence Type: Licence Licence Number: CN-12312345",
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'kapDuGychT1h9Pj4UN0v-',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        componentId: 'nplciSn_ep3Nd3VDk1IJV',
                        type: 'linkCard',
                        props: {
                          title: 'Edit',
                          description: '',
                          icon: null,
                          link: '',
                          id: '',
                          aspectOfLifeType: '',
                          size: 'default',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'JS0ys1joXYXpuNxU0u-ZW',
                        type: 'linkCard',
                        props: {
                          title: 'Remove',
                          description: '',
                          icon: null,
                          link: '',
                          id: '',
                          aspectOfLifeType: '',
                          size: 'default',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'rR4bT4IWc-b9FaLfa3Z77',
                    type: 'text',
                    props: {
                      variant: 'h4',
                      content: 'Contact List',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'YVKbLWKlTaBoQWfI3ePGP',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Government agencies or non-local companies and local companies not licensed from the Abu Dhabi Business Center - Department of Economic Development. To add new contacts, click the Select from Account or Add New button. To add a contact, click the Edit link.',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hbHTyT_fdoxvs4qclp50A',
                    type: 'table',
                    props: {
                      size: 'default',
                      selectable: false,
                      clickable: true,
                      columns: [
                        {
                          name: 'field-2-k730l0h6',
                          type: 'string',
                          label: 'Full Name',
                        },
                        {
                          name: 'field-3-k730l12i',
                          type: 'string',
                          label: 'Business Name',
                        },
                        {
                          name: 'field-3-k730mge9',
                          type: 'string',
                          label: 'Contact Type',
                        },
                        {
                          name: 'field-7-k730oe6a',
                          type: 'string',
                          label: 'Work Phone',
                        },
                        {
                          name: 'field-5-k730ox5b',
                          type: 'string',
                          label: 'Fax',
                        },
                        {
                          name: 'field-6-k730qc86',
                          type: 'string',
                          label: 'Email',
                        },
                        {
                          name: 'field-7-k730qinu',
                          type: 'bool',
                          label: 'Action',
                        },
                      ],
                      items: [
                        {
                          id: 1,
                          'field-2-k6q4iezn': 'Amendment fee',
                          'field-3-k6q4iqal': '50AED',
                        },
                        {
                          id: 2,
                          'field-2-k6q4iezn': 'Publishing fee',
                          'field-3-k6q4iqal': '100AED',
                        },
                      ],
                      title: '',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'l9BX8RoWyCgEl0IEnInGC',
                    type: 'text',
                    props: {
                      variant: 'h3',
                      content: 'Permit Info',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: '6dirNrJhoAztn-rHYE4ts',
                    type: 'grid',
                    props: {
                      columns: 2,
                      space: {
                        marginTop: 'lg',
                      },
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'p1I3T8dxkaCnOJJHEJa9j',
                        type: 'select',
                        props: {
                          placeholder: 'Select',
                          label: 'Advertisement Details*',
                          items: [
                            {
                              id: 'k6q4lr09',
                              label: 'Item 1',
                            },
                            {
                              id: 'k6q4ltxj',
                              label: 'Item 2',
                            },
                          ],
                          value: null,
                          isOpen: false,
                          disabled: false,
                          isStatic: false,
                          multi: false,
                          showSearch: true,
                          validateStatus: null,
                          help: '',
                          size: 'default',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'x9_9O_dXtUJYA1VXQq0Pj',
                        type: 'label',
                        props: {
                          children: null,
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'BSUhnEtIZGH9GTdFzGcGX',
                        type: 'select',
                        props: {
                          placeholder: '',
                          label: 'Advertisement Location*',
                          items: [],
                          value: null,
                          isOpen: false,
                          disabled: false,
                          isStatic: false,
                          multi: false,
                          showSearch: true,
                          validateStatus: null,
                          help: '',
                          size: 'default',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'hYeNOMAOmOMk209VmUdx3',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'CJ1n1G9btYsLK0-TXNFD4',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'Sk96c1wGq8bPYD7eKbzar',
                    type: 'grid',
                    props: {
                      columns: '02',
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'oKUxot4U97-_DZPd-fwnF',
                        type: 'datePicker',
                        props: {
                          i18n: '',
                          disabledDate: '',
                          onOpenChange: '',
                          onChange: '',
                          id: '',
                          disabled: '',
                          open: '',
                          defaultValue: '',
                          value: '',
                          label: 'ADvertisement Start Date*',
                          size: 'default',
                          help: null,
                          validateStatus: '',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'Dc3yhTvLqrNxnB65GU2mf',
                        type: 'datePicker',
                        props: {
                          i18n: '',
                          disabledDate: '',
                          onOpenChange: '',
                          onChange: '',
                          id: '',
                          disabled: '',
                          open: '',
                          defaultValue: '',
                          value: '',
                          label: 'ADvertisement End Date*',
                          size: 'default',
                          help: null,
                          validateStatus: '',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: '4ciT5sUHCjKC_YqBFYLQK',
                        type: 'label',
                        props: {
                          children: '',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'V3j0-C7jDK_XEYE4KIVme',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'xt_BBTzVa2UTrpOrk5taP',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'OsOrIx5QL2wxPPZefWcmb',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'vtDzOz1UEZr-4l6gj3vgz',
                        type: 'input',
                        props: {
                          label: "Customer's Comments",
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'qNuHsr3DuCqA5a-R4_Ixd',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'Fyk_MvwzrXLqGlQci8wWK',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'OFItLKn-kgnGZFgbO01YM',
                        type: 'select',
                        props: {
                          placeholder: 'Select',
                          label: 'PRO Name*',
                          items: [
                            {
                              id: 'k6q561ek',
                              label: 'Item 1',
                            },
                            {
                              id: 'k6q564by',
                              label: 'item 2',
                            },
                          ],
                          value: null,
                          isOpen: false,
                          disabled: false,
                          isStatic: false,
                          multi: false,
                          showSearch: true,
                          validateStatus: null,
                          help: '',
                          size: 'default',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'RWRpvktxOolxq0ruv4c9a',
                        type: 'inputTelephone',
                        props: {
                          i18n: '',
                          help: null,
                          validateStatus: '',
                          label: 'PRO Mobile NUMBER*',
                          'aria-label': 'Telephone input',
                          disabled: false,
                          value: '',
                          code: null,
                          countries: [
                            {
                              id: 'k6q56w0p',
                              name: 'United Aram Emirates',
                              code: '971',
                            },
                            {
                              id: 'k6q572lt',
                              name: 'Armenia',
                              code: '374',
                            },
                          ],
                          size: 'default',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'eYwr9_K0PCyVkkX3Wq48s',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'QUzVrzFTSJAIvLCe9w8C5',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'C1u0fbK00s10eTLVR7Zy-',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: '5CjpmeKrMgVW9uJTKUGp9',
                        type: 'input',
                        props: {
                          label: 'PRO Email *',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: 'email@domain.com',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'I_SyoWkVOEE90NOLczc9q',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'bn3aG2cp_45PoNqFCrkIi',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: 'Sample text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'ao9RW2GzvrCCDEZH_mhBD',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'fbV0L8UGtf1TjuSOCPVOy',
                        type: 'button',
                        props: {
                          label: 'Save and Resume Later',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'iti0OEz0usydFqWQJ-5CC',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              expanded: true,
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
          ],
          expanded: true,
          path: '/automatic-payment-form',
          template: 'custom',
          props: {
            BP8VxBeKWboF3UfdY1AUP: {
              fields: [
                {
                  id: 'k6oxdpnn',
                  type: 'input',
                  label: 'Field 1',
                  defaultValue: '',
                  name: 'field_0',
                },
                {
                  id: 'k6oxduqv',
                  type: 'input',
                  label: 'Field 2',
                  defaultValue: '',
                  name: 'field_1',
                },
              ],
            },
            definitions: [
              {
                componentId: 'rQhuKQciPLKzcXTknIsuR',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Details',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'U2kOU1PdEyd-MYCgVubcB',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Please enter "Licence" or "Contact", two values are not allowed. ',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'Zx2TbvLRjGQ3c1TgSgHTO',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Licence',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'D6vfX43fCgdI5TpDDUQFt',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Licences issued by Abu Dhabi Business Centre - Department of Economic Development.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'XYejeVcX4-avWkVu8mL3D',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '12dj0buQYhpNrt2J3qK7s',
                    type: 'button',
                    props: {
                      label: 'Select from account',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'ChsTfSDtDV-i89F5W55zI',
                    type: 'button',
                    props: {
                      label: 'Enter Number',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'rR4bT4IWc-b9FaLfa3Z77',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Contact List',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'YVKbLWKlTaBoQWfI3ePGP',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Government agencies or non-local companies and local companies not licensed from the Abu Dhabi Business Center - Department of Economic Development. To add new contacts, click the Select from Account or Add New button. To add a contact, click the Edit link.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'hbHTyT_fdoxvs4qclp50A',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-2-k730l0h6',
                      type: 'string',
                      label: 'Full Name',
                    },
                    {
                      name: 'field-3-k730l12i',
                      type: 'string',
                      label: 'Business Name',
                    },
                    {
                      name: 'field-3-k730mge9',
                      type: 'string',
                      label: 'Contact Type',
                    },
                    {
                      name: 'field-7-k730oe6a',
                      type: 'string',
                      label: 'Work Phone',
                    },
                    {
                      name: 'field-5-k730ox5b',
                      type: 'string',
                      label: 'Fax',
                    },
                    {
                      name: 'field-6-k730qc86',
                      type: 'string',
                      label: 'Email',
                    },
                    {
                      name: 'field-7-k730qinu',
                      type: 'bool',
                      label: 'Action',
                    },
                  ],
                  items: [
                    {
                      id: 1,
                      'field-2-k6q4iezn': 'Amendment fee',
                      'field-3-k6q4iqal': '50AED',
                    },
                    {
                      id: 2,
                      'field-2-k6q4iezn': 'Publishing fee',
                      'field-3-k6q4iqal': '100AED',
                    },
                  ],
                  title: '',
                  space: {
                    marginTop: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'l9BX8RoWyCgEl0IEnInGC',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Info',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '6dirNrJhoAztn-rHYE4ts',
                type: 'grid',
                props: {
                  columns: 2,
                  space: {
                    marginTop: 'lg',
                  },
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'p1I3T8dxkaCnOJJHEJa9j',
                    type: 'input',
                    props: {
                      label: 'ADvertisement Details*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'BSUhnEtIZGH9GTdFzGcGX',
                    type: 'select',
                    props: {
                      placeholder: '',
                      label: 'Advertisement Location*',
                      items: [],
                      value: null,
                      isOpen: false,
                      disabled: false,
                      isStatic: false,
                      multi: false,
                      showSearch: true,
                      validateStatus: null,
                      help: '',
                      size: 'default',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hYeNOMAOmOMk209VmUdx3',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'CJ1n1G9btYsLK0-TXNFD4',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'Sk96c1wGq8bPYD7eKbzar',
                type: 'grid',
                props: {
                  columns: '02',
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'oKUxot4U97-_DZPd-fwnF',
                    type: 'datePicker',
                    props: {
                      i18n: '',
                      disabledDate: '',
                      onOpenChange: '',
                      onChange: '',
                      id: '',
                      disabled: '',
                      open: '',
                      defaultValue: '',
                      value: '',
                      label: 'ADvertisement Start Date*',
                      size: 'default',
                      help: null,
                      validateStatus: '',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'Dc3yhTvLqrNxnB65GU2mf',
                    type: 'datePicker',
                    props: {
                      i18n: '',
                      disabledDate: '',
                      onOpenChange: '',
                      onChange: '',
                      id: '',
                      disabled: '',
                      open: '',
                      defaultValue: '',
                      value: '',
                      label: 'ADvertisement End Date*',
                      size: 'default',
                      help: null,
                      validateStatus: '',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: '4ciT5sUHCjKC_YqBFYLQK',
                    type: 'label',
                    props: {
                      children: '',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'V3j0-C7jDK_XEYE4KIVme',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'xt_BBTzVa2UTrpOrk5taP',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'OsOrIx5QL2wxPPZefWcmb',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'vtDzOz1UEZr-4l6gj3vgz',
                    type: 'input',
                    props: {
                      label: "Customer's Comments",
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'qNuHsr3DuCqA5a-R4_Ixd',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'Fyk_MvwzrXLqGlQci8wWK',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'OFItLKn-kgnGZFgbO01YM',
                    type: 'select',
                    props: {
                      placeholder: 'Select',
                      label: 'PRO Name*',
                      items: [
                        {
                          id: 'k6q561ek',
                          label: 'Item 1',
                        },
                        {
                          id: 'k6q564by',
                          label: 'item 2',
                        },
                      ],
                      value: null,
                      isOpen: false,
                      disabled: false,
                      isStatic: false,
                      multi: false,
                      showSearch: true,
                      validateStatus: null,
                      help: '',
                      size: 'default',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'RWRpvktxOolxq0ruv4c9a',
                    type: 'inputTelephone',
                    props: {
                      i18n: '',
                      help: null,
                      validateStatus: '',
                      label: 'PRO Mobile NUMBER*',
                      'aria-label': 'Telephone input',
                      disabled: false,
                      value: '',
                      code: null,
                      countries: [
                        {
                          id: 'k6q56w0p',
                          name: 'United Aram Emirates',
                          code: '971',
                        },
                        {
                          id: 'k6q572lt',
                          name: 'Armenia',
                          code: '374',
                        },
                      ],
                      size: 'default',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'eYwr9_K0PCyVkkX3Wq48s',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'QUzVrzFTSJAIvLCe9w8C5',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'C1u0fbK00s10eTLVR7Zy-',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '5CjpmeKrMgVW9uJTKUGp9',
                    type: 'input',
                    props: {
                      label: 'PRO Email *',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: 'email@domain.com',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'I_SyoWkVOEE90NOLczc9q',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'ao9RW2GzvrCCDEZH_mhBD',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'fbV0L8UGtf1TjuSOCPVOy',
                    type: 'button',
                    props: {
                      label: 'Save and Resume Later',
                      type: 'button',
                      uiType: 'secondary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'iti0OEz0usydFqWQJ-5CC',
                    type: 'button',
                    props: {
                      label: 'Continue',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                columnIndex: 0,
                componentId: 'Ve3J2nyfKcDdimQvBxYRm',
                type: 'text',
                props: {
                  variant: 'h5',
                  content: 'Aspect of Life',
                  space: {
                    marginBottom: '',
                  },
                },
                sharedProps: ['i18n'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Select Permit',
          layout: 'base',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 8 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'Automatic Payment',
          pageId: '4',
          children: [
            {
              title: 'Select Contact from Account',
              pageId: '4_5',
              path: '/select-contact-from-account-1',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'hsOujF7YWcVzy70FOggOb',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Select a contact to attach to this application. If the contact has multiple addresses, you can select which to use in the next step. ',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'M_vk2FWGaBl__QKCuYkFW',
                    type: 'table',
                    props: {
                      size: 'default',
                      selectable: true,
                      clickable: true,
                      columns: [
                        {
                          name: 'field-1-k7358jgq',
                          type: 'string',
                          label: 'Category',
                        },
                        {
                          name: 'field-2-k7358jys',
                          type: 'string',
                          label: 'Type',
                        },
                        {
                          name: 'field-3-k7358kcm',
                          type: 'string',
                          label: 'Name',
                        },
                      ],
                      items: [
                        {
                          _id: 1,
                          'field-1-k7358jgq': 'Associated Contact',
                          'field-2-k7358jys': 'Individual',
                          'field-3-k7358kcm': 'Mohammed Khair',
                        },
                      ],
                      title: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hrEdYEieAarw9lW-zeLOQ',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'hBq-AW1X9-AfWKMlU8kPe',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'nhqH4iUQxyOuw7GOvRVI6',
                        type: 'button',
                        props: {
                          label: 'Discard changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Select Contact from Account',
              pageId: '4_6',
              children: [],
              path: '/select-contact-from-account-2',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'mVO3DK6GC2A0ieCyWXcn-',
                    type: 'text',
                    props: {
                      variant: 'h3',
                      content: "Boban's Bistro Licence CN-12312345",
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hsOujF7YWcVzy70FOggOb',
                    type: 'dropdown',
                    props: {
                      uiType: 'primary',
                      size: 'default',
                      label: 'Type*',
                      isOpen: false,
                      disabled: false,
                      items: [
                        {
                          id: 'k78pgtv8',
                          label: 'Foreign Company',
                        },
                        {
                          id: 'k78pgzq0',
                          label: 'Governmental',
                        },
                        {
                          id: 'k78ph3ur',
                          label: 'Free-Zone',
                        },
                        {
                          id: 'k78ph7ze',
                          label: 'Non-Local',
                        },
                      ],
                      popupAlign: '',
                      popupWidth: null,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hrEdYEieAarw9lW-zeLOQ',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'hBq-AW1X9-AfWKMlU8kPe',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'nhqH4iUQxyOuw7GOvRVI6',
                        type: 'button',
                        props: {
                          label: 'Discard changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Foreign Company Contact Information',
              pageId: '4_7',
              path: '/foreign-company-contact-information',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'N9oI1juo3MAVzQP1L0kE0',
                    type: 'input',
                    props: {
                      label: 'Licence Number*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'SMbuDkXEqc6u-6Aa0SOqm',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'SK4vJpv9d1JlpbBB4_Vfu',
                        type: 'dropdown',
                        props: {
                          uiType: 'primary',
                          size: 'default',
                          label: 'Representative Type*',
                          isOpen: false,
                          disabled: false,
                          items: [
                            {
                              id: 'k7of560e',
                              label: 'Commissioner to sign',
                              disabled: '',
                            },
                            {
                              id: 'k7of5hoe',
                              label: 'Heirs representative',
                              disabled: '',
                            },
                            {
                              id: 'k7of5nun',
                              label: 'Manager',
                              disabled: '',
                            },
                            {
                              id: 'k7of6b7b',
                              label: 'Owner',
                              disabled: '',
                            },
                            {
                              id: 'k7of6gr1',
                              label: 'Partner',
                              disabled: '',
                            },
                            {
                              id: 'k7of6moe',
                              label: 'Sponsor',
                              disabled: '',
                            },
                          ],
                          popupAlign: '',
                          popupWidth: null,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'rWhunUbtcbNdQi1elMm73',
                        type: 'input',
                        props: {
                          label: 'Share Percentage*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'bubDVbY3hhwnQE8QldpeC',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'U8QhxGbj0GA9k6VqVBf9Q',
                    type: 'input',
                    props: {
                      label: 'Business Name (AR)*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'N8xRRh2GR4FosBhJ3z3L8',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'RKAizGcViSUlkrzoaKoPQ',
                    type: 'input',
                    props: {
                      label: 'Business Name (EN)*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'DVhaHKRIV1aSR916ntryR',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'gG-FgOuxV9DdYR7BgPxOD',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: '9p56KQ-8UdkOpXnG4GJf7',
                        type: 'input',
                        props: {
                          label: 'Nationality*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: '3vZJYzwCHM2Zfm7oR-_Ei',
                        type: 'radioGroup',
                        props: {
                          children: '',
                          disabled: false,
                          labelStyle: 'default',
                          uiType: 'default',
                          items: [
                            {
                              id: 'k74s63eu',
                              name: 'ALLGCC',
                              label: 'Yes',
                              tabIndex: 'ALL GCC',
                            },
                            {
                              id: 'k74s6uxh',
                              label: 'No',
                              textAsSingleLine: true,
                            },
                          ],
                          defaultValue: 'AllGCC',
                          align: 'horizontal',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: '9BNb4QcOPDVRKbsOIlFIR',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'pvyKHN4M_nTnmpVw0vDsN',
                        type: 'input',
                        props: {
                          label: 'Email*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'I8Th2tMDSJdhL7uemNaeZ',
                        type: 'input',
                        props: {
                          label: 'Mobile Phone*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'hY1JybXGpUjWnHmrnnf6N',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        componentId: 'Hhbb4E3uug3ho-rCrzRPW',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'GibX7ZdxAhX9SPqBxVafT',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'tertiary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Governmental - Contact Information',
              pageId: '4_8',
              children: [],
              path: '/governmental---contact-information',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'U8QhxGbj0GA9k6VqVBf9Q',
                    type: 'input',
                    props: {
                      label: 'Business Name (AR)',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'RKAizGcViSUlkrzoaKoPQ',
                    type: 'input',
                    props: {
                      label: 'Business Name (EN)',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'SMbuDkXEqc6u-6Aa0SOqm',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'SK4vJpv9d1JlpbBB4_Vfu',
                        type: 'dropdown',
                        props: {
                          uiType: 'primary',
                          size: 'default',
                          label: 'Representative Type*',
                          isOpen: false,
                          disabled: false,
                          items: [
                            {
                              id: 'k7of162s',
                              label: 'Commissioner to sign',
                              disabled: '',
                            },
                            {
                              id: 'k7of1c0r',
                              label: 'Heirs representative',
                              disabled: '',
                            },
                            {
                              id: 'k7of1jjy',
                              label: 'Manager',
                              disabled: '',
                            },
                            {
                              id: 'k7of1sm0',
                              label: 'Owner',
                              disabled: '',
                            },
                            {
                              id: 'k7of1yah',
                              label: 'Partner',
                              disabled: '',
                            },
                            {
                              id: 'k7of24wy',
                              label: 'Sponsor',
                              disabled: '',
                            },
                          ],
                          popupAlign: '',
                          popupWidth: null,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'rWhunUbtcbNdQi1elMm73',
                        type: 'input',
                        props: {
                          label: 'Share Percentage*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'ZfVfVvONOrlwPCurbjH5r',
                    type: 'input',
                    props: {
                      label: 'Nationality*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hY1JybXGpUjWnHmrnnf6N',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        componentId: 'Hhbb4E3uug3ho-rCrzRPW',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'GibX7ZdxAhX9SPqBxVafT',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'tertiary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                    columnIndex: 1,
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Free Zone Contact Information',
              pageId: '4_9',
              children: [],
              path: '/free-zone-contact-information',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'U8QhxGbj0GA9k6VqVBf9Q',
                    type: 'input',
                    props: {
                      label: 'Business Name (AR)*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'RKAizGcViSUlkrzoaKoPQ',
                    type: 'input',
                    props: {
                      label: 'Business Name (EN)*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'SMbuDkXEqc6u-6Aa0SOqm',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'SK4vJpv9d1JlpbBB4_Vfu',
                        type: 'dropdown',
                        props: {
                          uiType: 'primary',
                          size: 'default',
                          label: 'Representative Type*',
                          isOpen: false,
                          disabled: false,
                          items: [
                            {
                              id: 'k7of79p0',
                              label: 'Commissioner to sign',
                              disabled: '',
                            },
                            {
                              id: 'k7of7fh8',
                              label: 'Heirs representative',
                              disabled: '',
                            },
                            {
                              id: 'k7of7p2c',
                              label: 'Manager',
                              disabled: '',
                            },
                            {
                              id: 'k7of7w2h',
                              label: 'Owner',
                              disabled: '',
                            },
                            {
                              id: 'k7of8384',
                              label: 'Partner,',
                              disabled: '',
                            },
                            {
                              id: 'k7of8bc0',
                              label: 'Sponsor',
                              disabled: '',
                            },
                          ],
                          popupAlign: '',
                          popupWidth: null,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'rWhunUbtcbNdQi1elMm73',
                        type: 'input',
                        props: {
                          label: 'Share Percentage*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'gG-FgOuxV9DdYR7BgPxOD',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: '9p56KQ-8UdkOpXnG4GJf7',
                        type: 'input',
                        props: {
                          label: 'Nationality*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: '3vZJYzwCHM2Zfm7oR-_Ei',
                        type: 'input',
                        props: {
                          label: 'Licence Number*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: '9BNb4QcOPDVRKbsOIlFIR',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'pvyKHN4M_nTnmpVw0vDsN',
                        type: 'input',
                        props: {
                          label: 'Email*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'I8Th2tMDSJdhL7uemNaeZ',
                        type: 'input',
                        props: {
                          label: 'Mobile Phone*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'hY1JybXGpUjWnHmrnnf6N',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        componentId: 'Hhbb4E3uug3ho-rCrzRPW',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'GibX7ZdxAhX9SPqBxVafT',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'tertiary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Non-Local Company Contact Information',
              pageId: '4_10',
              children: [],
              path: '/non-local-company-contact-information',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'U8QhxGbj0GA9k6VqVBf9Q',
                    type: 'input',
                    props: {
                      label: 'Business Name (AR)',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'RKAizGcViSUlkrzoaKoPQ',
                    type: 'input',
                    props: {
                      label: 'Business Name (EN)',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'SMbuDkXEqc6u-6Aa0SOqm',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'SK4vJpv9d1JlpbBB4_Vfu',
                        type: 'dropdown',
                        props: {
                          uiType: 'primary',
                          size: 'default',
                          label: 'Representative Type*',
                          isOpen: false,
                          disabled: false,
                          items: [
                            {
                              id: 'k7of94h5',
                              label: 'Commissioner to sign',
                              disabled: '',
                            },
                            {
                              id: 'k7of9dff',
                              label: 'Heirs representative',
                              disabled: '',
                            },
                            {
                              id: 'k7of9jnx',
                              label: 'Manager',
                              disabled: '',
                            },
                            {
                              id: 'k7of9pim',
                              label: 'Owner',
                              disabled: '',
                            },
                            {
                              id: 'k7of9vfz',
                              label: 'Partner',
                              disabled: '',
                            },
                            {
                              id: 'k7ofa0jq',
                              label: 'Sponsor',
                              disabled: '',
                            },
                          ],
                          popupAlign: '',
                          popupWidth: null,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'rWhunUbtcbNdQi1elMm73',
                        type: 'input',
                        props: {
                          label: 'Share Percentage*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'N9oI1juo3MAVzQP1L0kE0',
                    type: 'input',
                    props: {
                      label: 'Licence Number*',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'bubDVbY3hhwnQE8QldpeC',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'Sl5runKw-kwmn5mqVW2LU',
                        type: 'input',
                        props: {
                          label: 'Legal Form*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'xrINbp--dYwFMzX9yhoL5',
                        type: 'input',
                        props: {
                          label: 'Nationality*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'N8xRRh2GR4FosBhJ3z3L8',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'DVhaHKRIV1aSR916ntryR',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'gG-FgOuxV9DdYR7BgPxOD',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: '9p56KQ-8UdkOpXnG4GJf7',
                        type: 'input',
                        props: {
                          label: 'Emirate*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: '3vZJYzwCHM2Zfm7oR-_Ei',
                        type: 'input',
                        props: {
                          label: 'Commercial Licence Number*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: '9BNb4QcOPDVRKbsOIlFIR',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'pvyKHN4M_nTnmpVw0vDsN',
                        type: 'input',
                        props: {
                          label: 'Email*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'I8Th2tMDSJdhL7uemNaeZ',
                        type: 'input',
                        props: {
                          label: 'Mobile Phone*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'hY1JybXGpUjWnHmrnnf6N',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        componentId: 'Hhbb4E3uug3ho-rCrzRPW',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'GibX7ZdxAhX9SPqBxVafT',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'tertiary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
            {
              title: 'Automatic Payment',
              pageId: '4_11',
              children: [],
              path: '/automatic-payment',
              template: 'custom',
              props: {
                BP8VxBeKWboF3UfdY1AUP: {
                  fields: [
                    {
                      id: 'k6oxdpnn',
                      type: 'input',
                      label: 'Field 1',
                      defaultValue: '',
                      name: 'field_0',
                    },
                    {
                      id: 'k6oxduqv',
                      type: 'input',
                      label: 'Field 2',
                      defaultValue: '',
                      name: 'field_1',
                    },
                  ],
                },
                definitions: [
                  {
                    componentId: 'rQhuKQciPLKzcXTknIsuR',
                    type: 'text',
                    props: {
                      variant: 'h3',
                      content: 'Permit Details',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'U2kOU1PdEyd-MYCgVubcB',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Please enter "Licence" or "Contact", two values are not allowed. ',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'Zx2TbvLRjGQ3c1TgSgHTO',
                    type: 'text',
                    props: {
                      variant: 'h4',
                      content: 'Licence',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'D6vfX43fCgdI5TpDDUQFt',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Licences issued by Abu Dhabi Business Centre - Department of Economic Development.',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: '3JkrKzvizdLAyB9dU3mMb',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Remove "Contact" below will allow apply for "Licence"',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'rR4bT4IWc-b9FaLfa3Z77',
                    type: 'text',
                    props: {
                      variant: 'h4',
                      content: 'Contact List',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'YVKbLWKlTaBoQWfI3ePGP',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Government agencies or non-local companies and local companies not licensed from the Abu Dhabi Business Center - Department of Economic Development. To add new contacts, click the Select from Account or Add New button. To add a contact, click the Edit link.',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'cljf4pASdlcuvltqGv01o',
                    type: 'table',
                    props: {
                      size: 'default',
                      selectable: false,
                      clickable: true,
                      columns: [
                        {
                          name: 'field-1-k78n934e',
                          type: 'string',
                          label: 'Full Name',
                        },
                        {
                          name: 'field-2-k78n9cw3',
                          type: 'string',
                          label: 'Business Name',
                        },
                        {
                          name: 'field-3-k78n9l1m',
                          type: 'string',
                          label: 'Contact Type',
                        },
                        {
                          name: 'field-4-k78n9vfb',
                          type: 'string',
                          label: 'Work Phone',
                        },
                        {
                          name: 'field-5-k78na1y2',
                          type: 'string',
                          label: 'Fax',
                        },
                        {
                          name: 'field-6-k78na7u5',
                          type: 'string',
                          label: 'Email',
                        },
                        {
                          name: 'field-7-k78naf0g',
                          type: 'string',
                          label: 'Action',
                        },
                      ],
                      items: [
                        {
                          _id: 1,
                          'field-1-k78n934e': 'Boban',
                          'field-3-k78n9l1m': 'Non-Local Company',
                          'field-6-k78na7u5': 'Boban@bobanbistro.com',
                        },
                      ],
                      title: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'l9BX8RoWyCgEl0IEnInGC',
                    type: 'text',
                    props: {
                      variant: 'h3',
                      content: 'Permit Info',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'Fyk_MvwzrXLqGlQci8wWK',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'OFItLKn-kgnGZFgbO01YM',
                        type: 'select',
                        props: {
                          placeholder: 'Select',
                          label: 'PRO Name*',
                          items: [
                            {
                              id: 'k6q561ek',
                              label: 'Item 1',
                            },
                            {
                              id: 'k6q564by',
                              label: 'item 2',
                            },
                          ],
                          value: null,
                          isOpen: false,
                          disabled: false,
                          isStatic: false,
                          multi: false,
                          showSearch: true,
                          validateStatus: null,
                          help: '',
                          size: 'default',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'RWRpvktxOolxq0ruv4c9a',
                        type: 'inputTelephone',
                        props: {
                          i18n: '',
                          help: null,
                          validateStatus: '',
                          label: 'PRO Mobile NUMBER*',
                          'aria-label': 'Telephone input',
                          disabled: false,
                          value: '',
                          code: null,
                          countries: [
                            {
                              id: 'k6q56w0p',
                              name: 'United Aram Emirates',
                              code: '971',
                            },
                            {
                              id: 'k6q572lt',
                              name: 'Armenia',
                              code: '374',
                            },
                          ],
                          size: 'default',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'eYwr9_K0PCyVkkX3Wq48s',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'QUzVrzFTSJAIvLCe9w8C5',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'Sk96c1wGq8bPYD7eKbzar',
                    type: 'grid',
                    props: {
                      columns: '02',
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'oKUxot4U97-_DZPd-fwnF',
                        type: 'datePicker',
                        props: {
                          i18n: '',
                          disabledDate: '',
                          onOpenChange: '',
                          onChange: '',
                          id: '',
                          disabled: '',
                          open: '',
                          defaultValue: '',
                          value: '',
                          label: 'ADvertisement Start Date*',
                          size: 'default',
                          help: null,
                          validateStatus: '',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'Dc3yhTvLqrNxnB65GU2mf',
                        type: 'datePicker',
                        props: {
                          i18n: '',
                          disabledDate: '',
                          onOpenChange: '',
                          onChange: '',
                          id: '',
                          disabled: '',
                          open: '',
                          defaultValue: '',
                          value: '',
                          label: 'ADvertisement End Date*',
                          size: 'default',
                          help: null,
                          validateStatus: '',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: '4ciT5sUHCjKC_YqBFYLQK',
                        type: 'label',
                        props: {
                          children: '',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'V3j0-C7jDK_XEYE4KIVme',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'xt_BBTzVa2UTrpOrk5taP',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: '6dirNrJhoAztn-rHYE4ts',
                    type: 'grid',
                    props: {
                      columns: 2,
                      space: {
                        marginTop: 'lg',
                      },
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'p1I3T8dxkaCnOJJHEJa9j',
                        type: 'select',
                        props: {
                          placeholder: 'Select',
                          label: 'Advertisement Details*',
                          items: [
                            {
                              id: 'k6q4lr09',
                              label: 'Item 1',
                            },
                            {
                              id: 'k6q4ltxj',
                              label: 'Item 2',
                            },
                          ],
                          value: null,
                          isOpen: false,
                          disabled: false,
                          isStatic: false,
                          multi: false,
                          showSearch: true,
                          validateStatus: null,
                          help: '',
                          size: 'default',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'x9_9O_dXtUJYA1VXQq0Pj',
                        type: 'label',
                        props: {
                          children: null,
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'BSUhnEtIZGH9GTdFzGcGX',
                        type: 'select',
                        props: {
                          placeholder: '',
                          label: 'Advertisement Location*',
                          items: [],
                          value: null,
                          isOpen: false,
                          disabled: false,
                          isStatic: false,
                          multi: false,
                          showSearch: true,
                          validateStatus: null,
                          help: '',
                          size: 'default',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'hYeNOMAOmOMk209VmUdx3',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'CJ1n1G9btYsLK0-TXNFD4',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'C1u0fbK00s10eTLVR7Zy-',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: '5CjpmeKrMgVW9uJTKUGp9',
                        type: 'input',
                        props: {
                          label: 'PRO Email *',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: 'email@domain.com',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'I_SyoWkVOEE90NOLczc9q',
                        type: 'text',
                        props: {
                          variant: 'p',
                          content: '',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'ao9RW2GzvrCCDEZH_mhBD',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        columnIndex: 0,
                        componentId: 'fbV0L8UGtf1TjuSOCPVOy',
                        type: 'button',
                        props: {
                          label: 'Save and Resume Later',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                      {
                        columnIndex: 1,
                        componentId: 'iti0OEz0usydFqWQJ-5CC',
                        type: 'button',
                        props: {
                          label: 'Continue',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              expanded: true,
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
          ],
          expanded: true,
          path: '/automatic-payment-1',
          template: 'custom',
          props: {
            BP8VxBeKWboF3UfdY1AUP: {
              fields: [
                {
                  id: 'k6oxdpnn',
                  type: 'input',
                  label: 'Field 1',
                  defaultValue: '',
                  name: 'field_0',
                },
                {
                  id: 'k6oxduqv',
                  type: 'input',
                  label: 'Field 2',
                  defaultValue: '',
                  name: 'field_1',
                },
              ],
            },
            definitions: [
              {
                componentId: 'rQhuKQciPLKzcXTknIsuR',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Details',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'U2kOU1PdEyd-MYCgVubcB',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Please enter "Licence" or "Contact", two values are not allowed. ',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'Zx2TbvLRjGQ3c1TgSgHTO',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Licence',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'D6vfX43fCgdI5TpDDUQFt',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Licences issued by Abu Dhabi Business Centre - Department of Economic Development.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'XYejeVcX4-avWkVu8mL3D',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '12dj0buQYhpNrt2J3qK7s',
                    type: 'button',
                    props: {
                      label: 'Select from account',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'ChsTfSDtDV-i89F5W55zI',
                    type: 'button',
                    props: {
                      label: 'Enter Number',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'rR4bT4IWc-b9FaLfa3Z77',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Contact List',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'YVKbLWKlTaBoQWfI3ePGP',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Government agencies or non-local companies and local companies not licensed from the Abu Dhabi Business Center - Department of Economic Development. To add new contacts, click the Select from Account or Add New button. To add a contact, click the Edit link.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'hANlDDkp7CeJAlsKQaOEV',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '12dj0buQYhpNrt2J3qK7s',
                    type: 'button',
                    props: {
                      label: 'Select from account',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'ChsTfSDtDV-i89F5W55zI',
                    type: 'button',
                    props: {
                      label: 'Enter Number',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'hbHTyT_fdoxvs4qclp50A',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-2-k730l0h6',
                      type: 'string',
                      label: 'Full Name',
                    },
                    {
                      name: 'field-3-k730l12i',
                      type: 'string',
                      label: 'Business Name',
                    },
                    {
                      name: 'field-3-k730mge9',
                      type: 'string',
                      label: 'Contact Type',
                    },
                    {
                      name: 'field-7-k730oe6a',
                      type: 'string',
                      label: 'Work Phone',
                    },
                    {
                      name: 'field-5-k730ox5b',
                      type: 'string',
                      label: 'Fax',
                    },
                    {
                      name: 'field-6-k730qc86',
                      type: 'string',
                      label: 'Email',
                    },
                    {
                      name: 'field-7-k730qinu',
                      type: 'bool',
                      label: 'Action',
                    },
                  ],
                  items: [
                    {
                      id: 1,
                      'field-2-k6q4iezn': 'Amendment fee',
                      'field-3-k6q4iqal': '50AED',
                    },
                    {
                      id: 2,
                      'field-2-k6q4iezn': 'Publishing fee',
                      'field-3-k6q4iqal': '100AED',
                    },
                  ],
                  title: '',
                  space: {
                    marginTop: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'l9BX8RoWyCgEl0IEnInGC',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Info',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '6dirNrJhoAztn-rHYE4ts',
                type: 'grid',
                props: {
                  columns: 2,
                  space: {
                    marginTop: 'lg',
                  },
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'p1I3T8dxkaCnOJJHEJa9j',
                    type: 'select',
                    props: {
                      placeholder: 'Select',
                      label: 'Advertisement Details*',
                      items: [
                        {
                          id: 'k6q4lr09',
                          label: 'Item 1',
                        },
                        {
                          id: 'k6q4ltxj',
                          label: 'Item 2',
                        },
                      ],
                      value: null,
                      isOpen: false,
                      disabled: false,
                      isStatic: false,
                      multi: false,
                      showSearch: true,
                      validateStatus: null,
                      help: '',
                      size: 'default',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'x9_9O_dXtUJYA1VXQq0Pj',
                    type: 'label',
                    props: {
                      children: null,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'BSUhnEtIZGH9GTdFzGcGX',
                    type: 'select',
                    props: {
                      placeholder: '',
                      label: 'Advertisement Location*',
                      items: [],
                      value: null,
                      isOpen: false,
                      disabled: false,
                      isStatic: false,
                      multi: false,
                      showSearch: true,
                      validateStatus: null,
                      help: '',
                      size: 'default',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'hYeNOMAOmOMk209VmUdx3',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'CJ1n1G9btYsLK0-TXNFD4',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'Sk96c1wGq8bPYD7eKbzar',
                type: 'grid',
                props: {
                  columns: '02',
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'oKUxot4U97-_DZPd-fwnF',
                    type: 'datePicker',
                    props: {
                      i18n: '',
                      disabledDate: '',
                      onOpenChange: '',
                      onChange: '',
                      id: '',
                      disabled: '',
                      open: '',
                      defaultValue: '',
                      value: '',
                      label: 'ADvertisement Start Date*',
                      size: 'default',
                      help: null,
                      validateStatus: '',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'Dc3yhTvLqrNxnB65GU2mf',
                    type: 'datePicker',
                    props: {
                      i18n: '',
                      disabledDate: '',
                      onOpenChange: '',
                      onChange: '',
                      id: '',
                      disabled: '',
                      open: '',
                      defaultValue: '',
                      value: '',
                      label: 'ADvertisement End Date*',
                      size: 'default',
                      help: null,
                      validateStatus: '',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: '4ciT5sUHCjKC_YqBFYLQK',
                    type: 'label',
                    props: {
                      children: '',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'V3j0-C7jDK_XEYE4KIVme',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'xt_BBTzVa2UTrpOrk5taP',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'OsOrIx5QL2wxPPZefWcmb',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'vtDzOz1UEZr-4l6gj3vgz',
                    type: 'input',
                    props: {
                      label: "Customer's Comments",
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'qNuHsr3DuCqA5a-R4_Ixd',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'Fyk_MvwzrXLqGlQci8wWK',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'OFItLKn-kgnGZFgbO01YM',
                    type: 'select',
                    props: {
                      placeholder: 'Select',
                      label: 'PRO Name*',
                      items: [
                        {
                          id: 'k6q561ek',
                          label: 'Item 1',
                        },
                        {
                          id: 'k6q564by',
                          label: 'item 2',
                        },
                      ],
                      value: null,
                      isOpen: false,
                      disabled: false,
                      isStatic: false,
                      multi: false,
                      showSearch: true,
                      validateStatus: null,
                      help: '',
                      size: 'default',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'RWRpvktxOolxq0ruv4c9a',
                    type: 'inputTelephone',
                    props: {
                      i18n: '',
                      help: null,
                      validateStatus: '',
                      label: 'PRO Mobile NUMBER*',
                      'aria-label': 'Telephone input',
                      disabled: false,
                      value: '',
                      code: null,
                      countries: [
                        {
                          id: 'k6q56w0p',
                          name: 'United Aram Emirates',
                          code: '971',
                        },
                        {
                          id: 'k6q572lt',
                          name: 'Armenia',
                          code: '374',
                        },
                      ],
                      size: 'default',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'eYwr9_K0PCyVkkX3Wq48s',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'QUzVrzFTSJAIvLCe9w8C5',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 1,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'C1u0fbK00s10eTLVR7Zy-',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '5CjpmeKrMgVW9uJTKUGp9',
                    type: 'input',
                    props: {
                      label: 'PRO Email *',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: 'email@domain.com',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'I_SyoWkVOEE90NOLczc9q',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    columnIndex: 0,
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'ao9RW2GzvrCCDEZH_mhBD',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'fbV0L8UGtf1TjuSOCPVOy',
                    type: 'button',
                    props: {
                      label: 'Save and Resume Later',
                      type: 'button',
                      uiType: 'secondary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'iti0OEz0usydFqWQJ-5CC',
                    type: 'button',
                    props: {
                      label: 'Continue',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Select Permit',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 9 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'Automatic Payment',
          pageId: '5',
          children: [
            {
              title: 'Licenced Professional Information',
              pageId: '5_6',
              path: '/licenced-professional-information-1',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'MAq26wFwlnJ-TH_-igZ9H',
                    type: 'grid',
                    props: {
                      columns: 3,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: '_v88BzkpE9zQ5vF33As84',
                        type: 'input',
                        props: {
                          label: 'Machine Number*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'JufImDteT_2htgwsyI7Wi',
                        type: 'input',
                        props: {
                          label: 'Machine Address*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'kIKdTUzdP_9qZrDXz6-JS',
                        type: 'input',
                        props: {
                          label: 'Notes',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 2,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'ylRVucXn424Tcrx3hRA36',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: '5nO9Wi--h3H8Ithbw21mw',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'LXeM8EVq7wp3KtBtcpRC1',
                        type: 'button',
                        props: {
                          label: 'Save and Close',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'WYJnRLq2Rf0UkrPYaatzG',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
          ],
          expanded: true,
          path: '/automatic-payment-2',
          template: 'custom',
          props: {
            BP8VxBeKWboF3UfdY1AUP: {
              fields: [
                {
                  id: 'k6oxdpnn',
                  type: 'input',
                  label: 'Field 1',
                  defaultValue: '',
                  name: 'field_0',
                },
                {
                  id: 'k6oxduqv',
                  type: 'input',
                  label: 'Field 2',
                  defaultValue: '',
                  name: 'field_1',
                },
              ],
            },
            definitions: [
              {
                componentId: 'rQhuKQciPLKzcXTknIsuR',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Upload Documents',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'U2kOU1PdEyd-MYCgVubcB',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'The maximum file size is allowed is 10 MB. Only allowed file types to upload (PDF, Images).',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'hANlDDkp7CeJAlsKQaOEV',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '12dj0buQYhpNrt2J3qK7s',
                    type: 'fileUpload',
                    props: {
                      i18n: '',
                      multiple: false,
                      validateStatus: '',
                      help: '',
                      disabled: false,
                      label:
                        'DED - A detailed letter from the company specifying the machines numbers and locations*',
                      accept: [],
                      files: [],
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'ChsTfSDtDV-i89F5W55zI',
                    type: 'fileUpload',
                    props: {
                      i18n: '',
                      multiple: false,
                      validateStatus: '',
                      help: '',
                      disabled: false,
                      label:
                        'DED - The approval of the location where the machines are installed*',
                      accept: [],
                      files: [],
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'l9BX8RoWyCgEl0IEnInGC',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Info',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '4DbzX5dWwjADRsQw__OX3',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: true,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k74pv9rl',
                      type: 'string',
                      label: 'Machine Number',
                    },
                    {
                      name: 'field-2-k74pvhj8',
                      type: 'string',
                      label: 'Machine Address',
                    },
                    {
                      name: 'field-3-k74pvi3k',
                      type: 'string',
                      label: 'Notes',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k74pv9rl': '12345',
                      'field-2-k74pvhj8': 'Abu Dhabi',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: 'e93LMniEUvRMkRAUjVeXE',
                type: 'flexbox',
                props: {
                  flexWrap: true,
                  flexDirection: 'row',
                  justifyContent: 'initial',
                  alignItems: 'flex-start',
                  alignContent: 'stretch',
                },
                layout: 'base',
                children: [
                  {
                    componentId: 'Ng582OIlNFln88SeNKOs3',
                    type: 'button',
                    props: {
                      label: 'Add 1 Row',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'FBX7HoP_re-78pHF5NWA2',
                    type: 'button',
                    props: {
                      label: 'Edit Selected',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'AGcFhQJClZ1vSRTKCwqRc',
                    type: 'button',
                    props: {
                      label: 'Delete Selected',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'ao9RW2GzvrCCDEZH_mhBD',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'fbV0L8UGtf1TjuSOCPVOy',
                    type: 'button',
                    props: {
                      label: 'Save and Resume Later',
                      type: 'button',
                      uiType: 'secondary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'iti0OEz0usydFqWQJ-5CC',
                    type: 'button',
                    props: {
                      label: 'Continue',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Select Permit',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 10 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'Vending Machine',
          pageId: '6',
          children: [
            {
              title: 'Vending Machine',
              pageId: '6_7',
              path: '/vending-machine',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'MAq26wFwlnJ-TH_-igZ9H',
                    type: 'grid',
                    props: {
                      columns: 3,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: '_v88BzkpE9zQ5vF33As84',
                        type: 'input',
                        props: {
                          label: 'Machine Number*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'JufImDteT_2htgwsyI7Wi',
                        type: 'input',
                        props: {
                          label: 'Machine Address*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'kIKdTUzdP_9qZrDXz6-JS',
                        type: 'input',
                        props: {
                          label: 'Notes',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 2,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'ylRVucXn424Tcrx3hRA36',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: '5nO9Wi--h3H8Ithbw21mw',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'LXeM8EVq7wp3KtBtcpRC1',
                        type: 'button',
                        props: {
                          label: 'Save and Close',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'WYJnRLq2Rf0UkrPYaatzG',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
          ],
          expanded: true,
          path: '/vending-machine-1',
          template: 'custom',
          props: {
            BP8VxBeKWboF3UfdY1AUP: {
              fields: [
                {
                  id: 'k6oxdpnn',
                  type: 'input',
                  label: 'Field 1',
                  defaultValue: '',
                  name: 'field_0',
                },
                {
                  id: 'k6oxduqv',
                  type: 'input',
                  label: 'Field 2',
                  defaultValue: '',
                  name: 'field_1',
                },
              ],
            },
            definitions: [
              {
                componentId: 'U2kOU1PdEyd-MYCgVubcB',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'The maximum file size is allowed is 10 MB. Only allowed file types to upload (PDF, Images).',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'hANlDDkp7CeJAlsKQaOEV',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '12dj0buQYhpNrt2J3qK7s',
                    type: 'fileUpload',
                    props: {
                      i18n: '',
                      multiple: false,
                      validateStatus: '',
                      help: '',
                      disabled: false,
                      label:
                        'DED - A detailed letter from the company specifying the machines numbers and locations*',
                      accept: [],
                      files: [],
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'ChsTfSDtDV-i89F5W55zI',
                    type: 'fileUpload',
                    props: {
                      i18n: '',
                      multiple: false,
                      validateStatus: '',
                      help: '',
                      disabled: false,
                      label:
                        'DED - The approval of the location where the machines are installed*',
                      accept: [],
                      files: [],
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'l9BX8RoWyCgEl0IEnInGC',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Info',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '4DbzX5dWwjADRsQw__OX3',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: true,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k74pv9rl',
                      type: 'string',
                      label: 'Machine Number',
                    },
                    {
                      name: 'field-2-k74pvhj8',
                      type: 'string',
                      label: 'Machine Address',
                    },
                    {
                      name: 'field-3-k74pvi3k',
                      type: 'string',
                      label: 'Notes',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k74pv9rl': '12345',
                      'field-2-k74pvhj8': 'Abu Dhabi',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: 'rQhuKQciPLKzcXTknIsuR',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Upload Documents',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'e93LMniEUvRMkRAUjVeXE',
                type: 'flexbox',
                props: {
                  flexWrap: true,
                  flexDirection: 'row',
                  justifyContent: 'initial',
                  alignItems: 'flex-start',
                  alignContent: 'stretch',
                },
                layout: 'base',
                children: [
                  {
                    componentId: 'Ng582OIlNFln88SeNKOs3',
                    type: 'button',
                    props: {
                      label: 'Add 1 Row',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'FBX7HoP_re-78pHF5NWA2',
                    type: 'button',
                    props: {
                      label: 'Edit Selected',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'AGcFhQJClZ1vSRTKCwqRc',
                    type: 'button',
                    props: {
                      label: 'Delete Selected',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'ao9RW2GzvrCCDEZH_mhBD',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'fbV0L8UGtf1TjuSOCPVOy',
                    type: 'button',
                    props: {
                      label: 'Save and Resume Later',
                      type: 'button',
                      uiType: 'secondary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'iti0OEz0usydFqWQJ-5CC',
                    type: 'button',
                    props: {
                      label: 'Continue',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Select Permit',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 11 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'Various Machines',
          pageId: '7',
          children: [
            {
              title: 'Machines',
              pageId: '7_8',
              path: '/machines',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'RCI_5Jlydik7dPDEn1Xtg',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'zCxzUMS8t4O4ZwIA8hcND',
                        type: 'input',
                        props: {
                          label: 'Machine Address*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'HnNcXCTGzZ3h5MQjYhQwI',
                        type: 'input',
                        props: {
                          label: 'Notes',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'ueI78G3zZpgr94hAVJYtJ',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'MAq26wFwlnJ-TH_-igZ9H',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: '_v88BzkpE9zQ5vF33As84',
                        type: 'input',
                        props: {
                          label: 'Machine Number*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'JufImDteT_2htgwsyI7Wi',
                        type: 'dropdown',
                        props: {
                          uiType: 'primary',
                          size: 'default',
                          label: 'Machine Type*',
                          isOpen: false,
                          disabled: false,
                          items: [
                            {
                              id: 'k78vx3qq',
                              label: 'Bubble gum machine',
                            },
                            {
                              id: 'k78vxg04',
                              label: 'Doll lifting machine',
                            },
                            {
                              id: 'k78vxl1h',
                              label: 'Hot drinks machine',
                            },
                            {
                              id: 'k78vxp2p',
                              label: 'Ice makers',
                            },
                            {
                              id: 'k78vxu5e',
                              label: 'Vending Machines',
                            },
                          ],
                          popupAlign: '',
                          popupWidth: null,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'kIKdTUzdP_9qZrDXz6-JS',
                        type: 'input',
                        props: {
                          label: 'Notes',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 2,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'bUVlnlJSp0GT4uuku-9b7',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: '5nO9Wi--h3H8Ithbw21mw',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        componentId: 'LXeM8EVq7wp3KtBtcpRC1',
                        type: 'button',
                        props: {
                          label: 'Save and Close',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'WYJnRLq2Rf0UkrPYaatzG',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                    layout: 'base',
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
          ],
          expanded: true,
          path: '/various-machines',
          template: 'custom',
          props: {
            BP8VxBeKWboF3UfdY1AUP: {
              fields: [
                {
                  id: 'k6oxdpnn',
                  type: 'input',
                  label: 'Field 1',
                  defaultValue: '',
                  name: 'field_0',
                },
                {
                  id: 'k6oxduqv',
                  type: 'input',
                  label: 'Field 2',
                  defaultValue: '',
                  name: 'field_1',
                },
              ],
            },
            definitions: [
              {
                componentId: 'U2kOU1PdEyd-MYCgVubcB',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'The maximum file size is allowed is 10 MB. Only allowed file types to upload (PDF, Images).',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'hANlDDkp7CeJAlsKQaOEV',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '12dj0buQYhpNrt2J3qK7s',
                    type: 'fileUpload',
                    props: {
                      i18n: '',
                      multiple: false,
                      validateStatus: '',
                      help: '',
                      disabled: false,
                      label:
                        'DED - A detailed letter from the company specifying the machines numbers and locations*',
                      accept: [],
                      files: [],
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'ChsTfSDtDV-i89F5W55zI',
                    type: 'fileUpload',
                    props: {
                      i18n: '',
                      multiple: false,
                      validateStatus: '',
                      help: '',
                      disabled: false,
                      label:
                        'DED - The approval of the location where the machines are installed*',
                      accept: [],
                      files: [],
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'l9BX8RoWyCgEl0IEnInGC',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Info',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '4DbzX5dWwjADRsQw__OX3',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: true,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k74pv9rl',
                      type: 'string',
                      label: 'Machine Number',
                    },
                    {
                      name: 'field-2-k74pvhj8',
                      type: 'string',
                      label: 'Machine Type',
                    },
                    {
                      name: 'field-3-k74pvi3k',
                      type: 'string',
                      label: 'Machine Address',
                    },
                    {
                      name: 'field-4-k78vhs6n',
                      type: 'string',
                      label: 'Notes',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k74pv9rl': '12345',
                      'field-2-k74pvhj8': 'Hot Drinks',
                      'field-3-k74pvi3k': 'Abu Dhabi',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: 'rQhuKQciPLKzcXTknIsuR',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Upload Documents',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'e93LMniEUvRMkRAUjVeXE',
                type: 'flexbox',
                props: {
                  flexWrap: true,
                  flexDirection: 'row',
                  justifyContent: 'initial',
                  alignItems: 'flex-start',
                  alignContent: 'stretch',
                },
                layout: 'base',
                children: [
                  {
                    componentId: 'Ng582OIlNFln88SeNKOs3',
                    type: 'button',
                    props: {
                      label: 'Add 1 Row',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'FBX7HoP_re-78pHF5NWA2',
                    type: 'button',
                    props: {
                      label: 'Edit Selected',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'AGcFhQJClZ1vSRTKCwqRc',
                    type: 'button',
                    props: {
                      label: 'Delete Selected',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'ao9RW2GzvrCCDEZH_mhBD',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'fbV0L8UGtf1TjuSOCPVOy',
                    type: 'button',
                    props: {
                      label: 'Save and Resume Later',
                      type: 'button',
                      uiType: 'secondary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'iti0OEz0usydFqWQJ-5CC',
                    type: 'button',
                    props: {
                      label: 'Continue',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Select Permit',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 12 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'ATM Ad',
          pageId: '8',
          children: [
            {
              title: 'ATM Ad',
              pageId: '8_9',
              path: '/atm-ad',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'RCI_5Jlydik7dPDEn1Xtg',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'zCxzUMS8t4O4ZwIA8hcND',
                        type: 'input',
                        props: {
                          label: 'Machine Number*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'HnNcXCTGzZ3h5MQjYhQwI',
                        type: 'input',
                        props: {
                          label: 'Machine Address*',
                          value: '',
                          defaultValue: '',
                          'aria-label': '',
                          validateStatus: '',
                          disabled: false,
                          readonly: false,
                          help: null,
                          placeholder: '',
                          size: 'default',
                          textDirection: null,
                          name: null,
                          type: 'text',
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'ueI78G3zZpgr94hAVJYtJ',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'BUdyrrLCWZXzk7lfZuzzU',
                    type: 'input',
                    props: {
                      label: 'Notes',
                      value: '',
                      defaultValue: '',
                      'aria-label': '',
                      validateStatus: '',
                      disabled: false,
                      readonly: false,
                      help: null,
                      placeholder: '',
                      size: 'default',
                      textDirection: null,
                      name: null,
                      type: 'text',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'bUVlnlJSp0GT4uuku-9b7',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content: '',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: '5nO9Wi--h3H8Ithbw21mw',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    children: [
                      {
                        componentId: 'LXeM8EVq7wp3KtBtcpRC1',
                        type: 'button',
                        props: {
                          label: 'Save and Close',
                          type: 'button',
                          uiType: 'primary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'WYJnRLq2Rf0UkrPYaatzG',
                        type: 'button',
                        props: {
                          label: 'Discard Changes',
                          type: 'button',
                          uiType: 'secondary',
                          disabled: false,
                          'aria-label': 'button',
                          size: 'default',
                          icon: null,
                          alignIcon: 'end',
                          withArrow: false,
                          active: false,
                          hidden: false,
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                    layout: 'base',
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Select Permit',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
          ],
          expanded: true,
          path: '/atm-ad-1',
          template: 'custom',
          props: {
            BP8VxBeKWboF3UfdY1AUP: {
              fields: [
                {
                  id: 'k6oxdpnn',
                  type: 'input',
                  label: 'Field 1',
                  defaultValue: '',
                  name: 'field_0',
                },
                {
                  id: 'k6oxduqv',
                  type: 'input',
                  label: 'Field 2',
                  defaultValue: '',
                  name: 'field_1',
                },
              ],
            },
            definitions: [
              {
                componentId: 'U2kOU1PdEyd-MYCgVubcB',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'The maximum file size is allowed is 10 MB. Only allowed file types to upload (PDF, Images).',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'hANlDDkp7CeJAlsKQaOEV',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: '12dj0buQYhpNrt2J3qK7s',
                    type: 'fileUpload',
                    props: {
                      i18n: '',
                      multiple: false,
                      validateStatus: '',
                      help: '',
                      disabled: false,
                      label:
                        'DED - A detailed letter from the company specifying the machines numbers and locations*',
                      accept: [],
                      files: [],
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'ChsTfSDtDV-i89F5W55zI',
                    type: 'fileUpload',
                    props: {
                      i18n: '',
                      multiple: false,
                      validateStatus: '',
                      help: '',
                      disabled: false,
                      label:
                        'DED - The approval of the location where the machines are installed*',
                      accept: [],
                      files: [],
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'bQ1gJ0wHYS-nATa0Ea7zz',
                type: 'fileUpload',
                props: {
                  i18n: '',
                  multiple: false,
                  validateStatus: '',
                  help: '',
                  disabled: false,
                  label: 'Approval of the Central Bank*',
                  accept: [],
                  files: [],
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'l9BX8RoWyCgEl0IEnInGC',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Permit Info',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '4DbzX5dWwjADRsQw__OX3',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: true,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k74pv9rl',
                      type: 'string',
                      label: 'Machine Number',
                    },
                    {
                      name: 'field-3-k74pvi3k',
                      type: 'string',
                      label: 'Machine Address',
                    },
                    {
                      name: 'field-4-k78vhs6n',
                      type: 'string',
                      label: 'Notes',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k74pv9rl': '12345',
                      'field-2-k74pvhj8': 'Hot Drinks',
                      'field-3-k74pvi3k': 'Abu Dhabi',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: 'rQhuKQciPLKzcXTknIsuR',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Upload Documents',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'e93LMniEUvRMkRAUjVeXE',
                type: 'flexbox',
                props: {
                  flexWrap: true,
                  flexDirection: 'row',
                  justifyContent: 'initial',
                  alignItems: 'flex-start',
                  alignContent: 'stretch',
                },
                layout: 'base',
                children: [
                  {
                    componentId: 'Ng582OIlNFln88SeNKOs3',
                    type: 'button',
                    props: {
                      label: 'Add 1 Row',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'FBX7HoP_re-78pHF5NWA2',
                    type: 'button',
                    props: {
                      label: 'Edit Selected',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'AGcFhQJClZ1vSRTKCwqRc',
                    type: 'button',
                    props: {
                      label: 'Delete Selected',
                      type: 'button',
                      uiType: 'tertiary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                ],
              },
              {
                componentId: 'ao9RW2GzvrCCDEZH_mhBD',
                type: 'grid',
                props: {
                  columns: 2,
                },
                children: [
                  {
                    columnIndex: 0,
                    componentId: 'fbV0L8UGtf1TjuSOCPVOy',
                    type: 'button',
                    props: {
                      label: 'Save and Resume Later',
                      type: 'button',
                      uiType: 'secondary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    columnIndex: 1,
                    componentId: 'iti0OEz0usydFqWQJ-5CC',
                    type: 'button',
                    props: {
                      label: 'Continue',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    sharedProps: ['i18n'],
                  },
                ],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Select Permit',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 13 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        14,
      );

      const pageConfig = [
        {
          title: 'Summary',
          pageId: 'AIJMAmE3yAxlY3ras7c5n',
          children: [],
          path: '/summary',
          template: 'custom',
          props: {
            BP8VxBeKWboF3UfdY1AUP: {
              fields: [
                {
                  id: 'k6oxdpnn',
                  type: 'input',
                  label: 'Field 1',
                  defaultValue: '',
                  name: 'field_0',
                },
                {
                  id: 'k6oxduqv',
                  type: 'input',
                  label: 'Field 2',
                  defaultValue: '',
                  name: 'field_1',
                },
              ],
            },
            definitions: [
              {
                componentId: 'rQhuKQciPLKzcXTknIsuR',
                type: 'text',
                props: {
                  variant: 'h3',
                  content: 'Review',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'U2kOU1PdEyd-MYCgVubcB',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Please review all information below. Click the "Edit" buttons to make changes to sections or "Continue Application" to move on.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'Zx2TbvLRjGQ3c1TgSgHTO',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Licence number CN-2323323',
                  space: {
                    marginBottom: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'rR4bT4IWc-b9FaLfa3Z77',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Contact',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'cljf4pASdlcuvltqGv01o',
                type: 'table',
                props: {
                  size: 'small',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k78n934e',
                      type: 'string',
                      label: 'Full Name',
                    },
                    {
                      name: 'field-3-k78n9l1m',
                      type: 'string',
                      label: 'Contact Type',
                    },
                    {
                      name: 'field-4-k78n9vfb',
                      type: 'string',
                      label: 'Work Phone',
                    },
                    {
                      name: 'field-6-k78na7u5',
                      type: 'string',
                      label: 'Email',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k78n934e': 'Boban',
                      'field-3-k78n9l1m': 'Non-Local Company',
                      'field-6-k78na7u5': 'Boban@bobanbistro.com',
                      'field-4-k78n9vfb': '050232332323',
                    },
                  ],
                  title: '',
                  space: {
                    marginBottom: 'lg',
                    marginTop: '',
                  },
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: '0odRYQKMK9UKTVYFdKCCH',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Selected options',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'gZ-bK-FdTB2IUXOBl-vw2',
                type: 'table',
                props: {
                  size: 'small',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-3-k78n9l1m',
                      type: 'string',
                      label: '',
                    },
                    {
                      name: 'field-4-k78n9vfb',
                      type: 'string',
                      label: ' ',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k78n934e': 'Boban',
                      'field-3-k78n9l1m': 'Advertisement start date',
                      'field-6-k78na7u5': 'Boban@bobanbistro.com',
                      'field-4-k78n9vfb': '23-05-2020',
                    },
                    {
                      _id: 2,
                      'field-3-k78n9l1m': 'Advertisement end data',
                      'field-4-k78n9vfb': '30-05-2020',
                    },
                    {
                      _id: 3,
                      'field-3-k78n9l1m': 'Machine',
                      'field-4-k78n9vfb': 'No.223232, Yas mall',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: 'ZdranNsVIXGbtNR7WwfWJ',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Provided documents',
                  space: {
                    marginTop: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '0aaHh1RgaO1CdV8Ubc2AV',
                type: 'table',
                props: {
                  size: 'small',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k78n934e',
                      type: 'string',
                      label: 'Name',
                    },
                    {
                      name: 'field-2-k78n9cw3',
                      type: 'string',
                      label: 'Type',
                    },
                    {
                      name: 'field-3-k78n9l1m',
                      type: 'string',
                      label: 'Size',
                    },
                    {
                      name: 'field-4-k78n9vfb',
                      type: 'string',
                      label: 'Latest Update',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k78n934e': 'Company approval.pdf',
                      'field-3-k78n9l1m': '750.00 kb',
                      'field-6-k78na7u5': 'Boban@bobanbistro.com',
                      'field-2-k78n9cw3':
                        'A detailed letter from the company specifying the machines numbers and locations',
                      'field-4-k78n9vfb': '16/3/2020',
                    },
                    {
                      _id: 2,
                      'field-1-k78n934e': 'Location approval.pdf',
                      'field-2-k78n9cw3':
                        'The approval of the location where the machines are installed.',
                      'field-3-k78n9l1m': '700.00 kb',
                      'field-4-k78n9vfb': '16/3/2020',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: 'Nu3b_RDMjvhfszu3gEb1l',
                type: 'text',
                props: {
                  variant: 'h4',
                  content: 'Fees',
                  space: {
                    marginTop: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '0rott3pNyflHmvcQh2HgD',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k78n934e',
                      type: 'string',
                      label: 'Fees',
                    },
                    {
                      name: 'field-2-k78n9cw3',
                      type: 'string',
                      label: 'Amount',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k78n934e': 'Vending Machine Advertisement',
                      'field-3-k78n9l1m': '750.00 kb',
                      'field-6-k78na7u5': 'Boban@bobanbistro.com',
                      'field-2-k78n9cw3': 'AED 1,000.00',
                      'field-4-k78n9vfb': '16/3/2020',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: '68s8sZHgLTUl5rZ7tgs8-',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'I do hereby undertake to comply with all the conditions and requirements stipulated in the laws and resolutions regulating the economic activities related to issuing/renewing and licence amendment the commercial licences and all the data included in the application. I also undertake not to practice the commercial activity unless after obtaining the approvals of the relevant authorities. The DED has the right to take all the legal and administrative actions in case of breach of this undertaking.',
                  space: {
                    marginTop: 'lg',
                    marginBottom: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'iti0OEz0usydFqWQJ-5CC',
                type: 'button',
                props: {
                  label: 'Continue',
                  type: 'button',
                  uiType: 'primary',
                  disabled: false,
                  'aria-label': 'button',
                  size: 'default',
                  icon: null,
                  alignIcon: 'end',
                  withArrow: false,
                  active: false,
                  hidden: false,
                  onClick: _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onClick,
                  space: {
                    marginBottom: 'lg',
                  },
                },
                columnIndex: 1,
                parentComponentId: 'ao9RW2GzvrCCDEZH_mhBD',
                sharedProps: ['i18n', 'history', 'actions'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          expanded: true,
          step: 'Select Permit',
          templateId: '76',
          templateName: 'Summary template DEMO',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 14 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onClick',
        function () {
          return f1_onClick;
        },
      );
      async function f1_onClick(props) {
        props.actions.mergeState('newState2');
        props.history.push('/approval-in-progress');
      }

      /***/
    },
    /* 15 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        16,
      );

      const pageConfig = [
        {
          title: 'Approval in progress',
          pageId: '9',
          children: [
            {
              title: 'Application returned',
              pageId: '9_10',
              path: '/application-returned',
              template: 'custom',
              props: {
                definitions: [
                  {
                    componentId: 'GEgCaIm7-GWeDqOnnYEQd',
                    type: 'notice',
                    props: {
                      status: 'failure',
                      icon: null,
                      title: 'Application returned!',
                      tags: [],
                      content: '',
                      buttons: [],
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'tg-wDWTDs9-gJjwnWm2mT',
                    type: 'text',
                    props: {
                      variant: 'h5',
                      content:
                        'Reference Number: 123456 Submitted on Date: February 19 2020',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'GK9AFx5QKL8I2Qmnd5Afq',
                    type: 'text',
                    props: {
                      variant: 'p',
                      content:
                        'Your application has been returned by the DED. Please check the feedback below, and make the required amends and/or add the requested documents before the expiration date.',
                    },
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'kmEYyhehiT3r5PPyCO6Od',
                    type: 'table',
                    props: {
                      size: 'default',
                      selectable: false,
                      clickable: true,
                      columns: [
                        {
                          name: 'field-1-k74qsss3',
                          type: 'string',
                          label: 'Feedback',
                        },
                        {
                          name: 'field-2-k74qsswm',
                          type: 'string',
                          label: 'Date',
                        },
                      ],
                      items: [
                        {
                          _id: 1,
                          'field-1-k74qsss3':
                            'Please include a message with the details of the promotional campaign in Arabic.',
                          'field-2-k74qsswm': '25/12/2020',
                        },
                      ],
                      title: 'Feedback',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'Lonx33xf5Rz7Bi3z5nD82',
                    type: 'text',
                    props: {
                      variant: 'h3',
                      content: 'Add attachments',
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'j3N7wEVB-ju7jGGWuxUTx',
                    type: 'grid',
                    props: {
                      columns: 2,
                    },
                    layout: 'base',
                    children: [
                      {
                        componentId: 'fx_zuR8wwoFAW6S9pKxBq',
                        type: 'fileUpload',
                        props: {
                          i18n: '',
                          multiple: false,
                          validateStatus: '',
                          help: 'name.jpg',
                          disabled: false,
                          label: 'Sample Document 1*',
                          accept: [],
                          files: [],
                        },
                        layout: 'base',
                        columnIndex: 0,
                        sharedProps: ['i18n'],
                      },
                      {
                        componentId: 'u0BxlK8RsAhMfCtJQ5Mge',
                        type: 'fileUpload',
                        props: {
                          i18n: {
                            type: 'func',
                            actions: [],
                          },
                          multiple: false,
                          validateStatus: '',
                          help: '',
                          disabled: false,
                          label: 'Sample Document 2*',
                          accept: [],
                          files: [],
                        },
                        layout: 'base',
                        columnIndex: 1,
                        sharedProps: ['i18n'],
                      },
                    ],
                  },
                  {
                    componentId: 'isQp1P8uRsRfOpzGSpjF_',
                    type: 'button',
                    props: {
                      label: 'Submit',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                      onClick: {
                        type: 'func',
                        actions: [
                          {
                            type: 'goToPage',
                            link: '/application-approved',
                          },
                          {
                            type: 'updateState',
                            stateName: ['newState3'],
                          },
                        ],
                      },
                    },
                    layout: 'base',
                    sharedProps: ['i18n', 'history', 'actions'],
                  },
                ],
                symbols: [
                  {
                    id: 'c4Z8Zav-0aQru7aHcXS3G',
                    name: 'Sidebar',
                    definitions: [
                      {
                        columnIndex: 0,
                        componentId: 'fKKzLmvvLPzs7uvihOSwf',
                        type: 'stepTracker',
                        props: {
                          title: '',
                          steps: '${state.steps_ebebbfacbc}',
                          expandedStepIndexes: [],
                          currentStepIndex: '${state.currStep}',
                          i18n: '',
                          visible:
                            '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                        type: 'relevantEntity',
                        props: {
                          i18n: '',
                          title: 'Relevant entity',
                          logo:
                            'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                          verticalLogo: false,
                          subTitle: 'Department of Economic Development',
                          address:
                            'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                          phones: [],
                          website: 'www.adeconomy.ae',
                          email: 'email@domain.com',
                          officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                          publicServiceHours:
                            'Sunday - Thursday 7:00AM - 3:00PM',
                          space: {
                            marginTop: 'xl',
                          },
                        },
                      },
                      {
                        columnIndex: 0,
                        componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                        type: 'relatedJourneyCard',
                        props: {
                          aspectOfLifeType: 'business-management',
                          icon: null,
                          description:
                            'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                          label: 'Manage your business',
                          title: 'Related journey',
                          space: {
                            marginTop: 'lg',
                          },
                        },
                      },
                    ],
                  },
                  {
                    id: 'hh7K8LKYM8XfcY8wDBHXV',
                    name: 'Hero',
                    definitions: [
                      {
                        componentId: 'VE0v8q2Vojv_KyqFblypq',
                        type: 'hero',
                        props: {
                          backgroundImage:
                            'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                          backgroundBase64Extension: '',
                          internal: true,
                          aspectOfLifeType: '',
                          breadcrumbs: [
                            {
                              label: 'Home',
                              link: '/',
                            },
                          ],
                          subTitle: '',
                          title:
                            'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                        },
                        layout: 'base',
                      },
                    ],
                  },
                ],
              },
              step: 'Receive response',
              state: {
                mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
                mapDispatch: [],
              },
            },
          ],
          expanded: true,
          path: '/approval-in-progress',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: 'GEgCaIm7-GWeDqOnnYEQd',
                type: 'notice',
                props: {
                  status: 'inProgress',
                  icon: null,
                  title: 'Your application approval is in progress.',
                  tags: [],
                  content: '',
                  buttons: [],
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'tg-wDWTDs9-gJjwnWm2mT',
                type: 'text',
                props: {
                  variant: 'h5',
                  content:
                    'Reference Number: 123456 Submitted on Date: February 19 2020',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'GK9AFx5QKL8I2Qmnd5Afq',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Your application is currently being assessed by the DED for approval. Please check back again later for an update.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'UO_tB2GY-vKnejVORCVU7',
                type: 'link',
                props: {
                  href: '',
                  children: null,
                  uiType: 'text',
                  disabled: false,
                  bala3nadhHref: '/www.bala3nadh.abudhabi/',
                  className: '',
                  label: 'Approved',
                  onClick: _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onClick,
                },
                layout: 'base',
                sharedProps: ['i18n', 'history', 'actions'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Receive response',
          templateId: '77',
          templateName: 'Approval in progress DEMO',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 16 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onClick',
        function () {
          return f1_onClick;
        },
      );
      async function f1_onClick(props) {
        props.actions.mergeState('newState3');
        props.history.push('/application-approved');
      }

      /***/
    },
    /* 17 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        18,
      );

      const pageConfig = [
        {
          title: 'Application approved',
          pageId: '9_11',
          children: [],
          expanded: true,
          path: '/application-approved',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: 'YHkW5HL-HZ3HKDK3eCxZ-',
                type: 'notice',
                props: {
                  status: 'success',
                  icon: null,
                  title: 'Application Approved',
                  tags: [],
                  content:
                    'Please find below your payment summary, based on your selection. Click on Pay to proceed with the payment',
                  buttons: [],
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'isQqskV8hd4Bi24u80smy',
                type: 'text',
                props: {
                  variant: 'h2',
                  content: 'Payment',
                  space: {
                    marginTop: 'lg',
                  },
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'sGecBfNTi6NMxBcIFZfbj',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Please find below your payment summary, based on your selection. Click on Pay to proceed with the payment',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'YJ4S2SrL66TMbVFVBmUQx',
                type: 'imageCard',
                props: {
                  i18n: '',
                  category: 'article',
                  aspectOfLifeType: 'social-support',
                  image: '',
                  imageBase64Extension: '',
                  title: 'asdsadas',
                  description: '',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '1Wrj3r5R1Z-vWuZQChyPw',
                type: 'table',
                props: {
                  size: 'default',
                  selectable: false,
                  clickable: true,
                  columns: [
                    {
                      name: 'field-1-k74repdm',
                      type: 'string',
                      label: 'Document',
                    },
                    {
                      name: 'field-2-k74repiz',
                      type: 'string',
                      label: 'Price',
                    },
                  ],
                  items: [
                    {
                      _id: 1,
                      'field-1-k74repdm': 'Automatic Payment Permit',
                      'field-2-k74repiz': 'AED 1,000.00',
                    },
                  ],
                  title: '',
                },
                layout: 'base',
                sharedProps: ['i18n'],
              },
              {
                componentId: '3AW2zr9vWQP4HPoAzFrc_',
                type: 'total',
                props: {
                  unit: 'AED',
                  isValueFirst: false,
                  isButtonVisible: false,
                  onClick: 'nop()',
                  value: 1000,
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'tmY9A0Yu470HVwV-bUNnF',
                type: 'button',
                props: {
                  label: 'Pay',
                  type: 'button',
                  uiType: 'primary',
                  disabled: false,
                  'aria-label': 'button',
                  size: 'default',
                  icon: null,
                  alignIcon: 'end',
                  withArrow: true,
                  active: false,
                  hidden: false,
                  space: {
                    marginTop: 'md',
                  },
                  onClick: _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onClick,
                },
                sharedProps: ['i18n', 'history'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Receive response',
          templateId: '80',
          templateName: 'Payment summary template DEMO',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 18 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onClick',
        function () {
          return f1_onClick;
        },
      );
      async function f1_onClick(props) {
        props.history.push('/payment-in-progress');
      }

      /***/
    },
    /* 19 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        20,
      );

      const pageConfig = [
        {
          title: 'Payment failed',
          pageId: '10_12',
          path: '/payment-failed',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: 'H3plZaw1RvpcXyZanSV-e',
                type: 'notice',
                props: {
                  status: 'failure',
                  icon: null,
                  title: 'Something went wrong',
                  tags: [],
                  content: '',
                  buttons: [],
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'n08G7QR35VTBew-XU_1tz',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Your transaction has been declined, please retry payment.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: '1nPX1EecP-r2mj7xn5GF6',
                type: 'button',
                props: {
                  label: 'Pay',
                  type: 'button',
                  uiType: 'primary',
                  disabled: false,
                  'aria-label': 'button',
                  size: 'default',
                  icon: null,
                  alignIcon: 'end',
                  withArrow: false,
                  active: false,
                  hidden: false,
                  onClick: _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onClick,
                },
                sharedProps: ['i18n', 'history'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Pay and receive permit',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 20 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onClick',
        function () {
          return f1_onClick;
        },
      );
      async function f1_onClick(props) {}

      /***/
    },
    /* 21 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        22,
      );

      const pageConfig = [
        {
          title: 'Payment in progress',
          pageId: '10_11',
          path: '/payment-in-progress',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: 'GEgCaIm7-GWeDqOnnYEQd',
                type: 'notice',
                props: {
                  status: 'inProgress',
                  icon: null,
                  title: 'Payment in progress',
                  tags: [],
                  content: '',
                  buttons: [],
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'tg-wDWTDs9-gJjwnWm2mT',
                type: 'text',
                props: {
                  variant: 'h5',
                  content:
                    'Reference Number: 123456 Submitted on Date: February 19 2020',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'GK9AFx5QKL8I2Qmnd5Afq',
                type: 'text',
                props: {
                  variant: 'p',
                  content: 'Your payment is in progress.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'l0uqGdsnQvKPn-6unouxq',
                type: 'link',
                props: {
                  href: '',
                  children: null,
                  uiType: 'text',
                  disabled: false,
                  bala3nadhHref: '/www.bala3nadh.abudhabi/',
                  className: '',
                  label: 'done',
                  onClick: _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onClick,
                },
                layout: 'base',
                sharedProps: ['i18n', 'history', 'actions'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Pay and receive permit',
          templateId: '82',
          templateName: 'Payment in progress template DEMO',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 22 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onClick',
        function () {
          return f1_onClick;
        },
      );
      async function f1_onClick(props) {
        props.actions.mergeState('newState4');
        props.history.push('/permit-issued');
      }

      /***/
    },
    /* 23 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        24,
      );

      const pageConfig = [
        {
          title: 'Permit issued',
          pageId: 'Wa4GIjIjgH52Ok9PaVaTZ',
          children: [],
          path: '/permit-issued',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: '1Y11soKdKzpHpTJICA-HP',
                type: 'notice',
                props: {
                  status: 'success',
                  icon: null,
                  title: 'Your permit has been issued',
                  tags: [],
                  content: '',
                  buttons: [],
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'hJCF8TtGjyUcS3hSxUYz3',
                type: 'text',
                props: {
                  variant: 'h5',
                  content:
                    'Reference No. 12345678      Submitted on Date: February 19 2020',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'QwAvO-04x3kh0uJDDXmrf',
                type: 'text',
                props: {
                  variant: 'p',
                  content:
                    'Congratulations! Your permit has been issued. You can download your permit by clicking on the button below.paid for. You can download your receipt by clicking on the button below.',
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'Bzf3T3P6vdk4ZuEiPUaen',
                type: 'flexbox',
                props: {
                  flexWrap: true,
                  flexDirection: 'initial',
                  justifyContent: 'initial',
                  alignItems: 'initial',
                  alignContent: 'initial',
                },
                layout: 'base',
                children: [
                  {
                    componentId: '7XdRuYVe_9g52i1PXdFiQ',
                    type: 'button',
                    props: {
                      label: 'Download permit',
                      type: 'button',
                      uiType: 'secondary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                      space: {
                        marginRight: 'sm',
                      },
                      onClick:
                        _functions__WEBPACK_IMPORTED_MODULE_0__.f1_onClick,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                  {
                    componentId: 'U3W6bYEjyi5RVWYYDtLfQ',
                    type: 'button',
                    props: {
                      label: 'Back to my business dashboard',
                      type: 'button',
                      uiType: 'primary',
                      disabled: false,
                      'aria-label': 'button',
                      size: 'default',
                      icon: null,
                      alignIcon: 'end',
                      withArrow: false,
                      active: false,
                      hidden: false,
                    },
                    layout: 'base',
                    sharedProps: ['i18n'],
                  },
                ],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          step: 'Pay and receive permit',
          templateId: '83',
          templateName: 'Result template DEMO',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 24 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_onClick',
        function () {
          return f1_onClick;
        },
      );
      async function f1_onClick(props) {}

      /***/
    },
    /* 25 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'Service Card',
          pageId: 'zyK8O11gE0uB68HlBeqGz',
          path: '/services-1',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: '79-5MeaUQsJ46MBnUSuz5',
                type: 'serviceTemplate',
                props: {
                  title:
                    'Broker Permit on Private Goods for a Particular Company',
                  description:
                    'Through this service, you can request a permission to enter the customs zone, for clearance of the private goods of a particular company and log into Dhabi system.',
                  startLogin: {
                    buttonLabel: 'Start',
                    description: 'Login / Start Service (STICKY)',
                    title: '',
                  },
                  process: {
                    steps: [],
                    title: 'Process',
                  },
                  tables: [
                    {
                      columns: [
                        {
                          id: 'document',
                          title: 'Document',
                        },
                        {
                          align: 'end',
                          id: 'description',
                          title: 'Description',
                        },
                      ],
                      items: [
                        {
                          description: '',
                          document: 'Official Letter',
                          id: 0,
                        },
                        {
                          description: '',
                          document: 'Trade Licence',
                          id: 1,
                        },
                      ],
                      title: 'Required documents',
                    },
                    {
                      columns: [
                        {
                          id: 'title',
                          title: 'Title',
                        },
                        {
                          align: 'end',
                          id: 'amount',
                          title: 'Amount',
                        },
                      ],
                      items: [
                        {
                          title:
                            ' Broker Permit on Private Goods for a Particular Company',
                          amount: 'AED 0',
                          id: 0,
                        },
                      ],
                      title: 'All Fees',
                    },
                  ],
                },
                sharedProps: ['i18n'],
              },
              {
                componentId: 'AxIHCg6-kTaT717O8fXKH',
                type: 'sidebarTemplate',
                props: {
                  label: '',
                  relevantEntityLink: null,
                  process: null,
                  lists: [],
                  relatedJourney: null,
                  relevantEntity: {
                    title: 'General Administration of Customs',
                    address: 'Abu Dhabi, Masdar City',
                    email: 'info@adcustoms.ae',
                    logo:
                      'https://www.bala3nadh.abudhabi/-/media/A3F0B4A76B504F858FEF34FE68E2CE58.ashx',
                    officeHours: 'Sunday - Thursday: 07:00 AM - 03:00 PM',
                    phones: ['+971 2 810 2000'],
                    publicServiceHours: '07:00 am - 03:00 pm',
                    subTitle: '',
                    verticalLogo: true,
                    website:
                      'https://adcustoms.gov.abudhabi/en-us/pages/home.aspx',
                  },
                  relevantEntitiyLink: {
                    label: '',
                  },
                },
                layout: 'sidebar',
                sharedProps: ['i18n'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          layout: 'sidebar',
          step: '',
          templateName: 'Service Card',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 26 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'Service Card',
          pageId: 's_32gDADirJxMBJGXgBri',
          path: '/services',
          template: 'custom',
          props: {
            definitions: [
              {
                componentId: 'zpDyQnaX2lWFY292G2dv5',
                type: 'serviceTemplate',
                props: {},
                sharedProps: ['i18n'],
              },
              {
                componentId: 'Z1GJUzzlKXR1A33eeB-Cd',
                type: 'sidebarTemplate',
                props: {},
                layout: 'sidebar',
                sharedProps: ['i18n'],
              },
            ],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          layout: 'sidebar',
          step: '',
          templateName: 'Service Card',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 27 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const pageConfig = [
        {
          title: 'New Page',
          pageId: 'qTDzq6c0LwlYwXePDws0_',
          path: '/new-page',
          template: 'custom',
          props: {
            definitions: [],
            symbols: [
              {
                id: 'c4Z8Zav-0aQru7aHcXS3G',
                name: 'Sidebar',
                definitions: [
                  {
                    columnIndex: 0,
                    componentId: 'fKKzLmvvLPzs7uvihOSwf',
                    type: 'stepTracker',
                    props: {
                      title: '',
                      steps: '${state.steps_ebebbfacbc}',
                      expandedStepIndexes: [],
                      currentStepIndex: '${state.currStep}',
                      i18n: '',
                      visible:
                        '{"code":"\\n\\nreturn props.state.started === true;\\n\\n"}',
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'xkNOb9BK0eZcunWl_u0Jl',
                    type: 'relevantEntity',
                    props: {
                      i18n: '',
                      title: 'Relevant entity',
                      logo:
                        'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                      verticalLogo: false,
                      subTitle: 'Department of Economic Development',
                      address:
                        'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                      phones: [],
                      website: 'www.adeconomy.ae',
                      email: 'email@domain.com',
                      officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                      space: {
                        marginTop: 'xl',
                      },
                    },
                  },
                  {
                    columnIndex: 0,
                    componentId: 'yE-5s1oO9uhZzJsZWKtNo',
                    type: 'relatedJourneyCard',
                    props: {
                      aspectOfLifeType: 'business-management',
                      icon: null,
                      description:
                        'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                      label: 'Manage your business',
                      title: 'Related journey',
                      space: {
                        marginTop: 'lg',
                      },
                    },
                  },
                ],
              },
              {
                id: 'hh7K8LKYM8XfcY8wDBHXV',
                name: 'Hero',
                definitions: [
                  {
                    componentId: 'VE0v8q2Vojv_KyqFblypq',
                    type: 'hero',
                    props: {
                      backgroundImage:
                        'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                      backgroundBase64Extension: '',
                      internal: true,
                      aspectOfLifeType: '',
                      breadcrumbs: [
                        {
                          label: 'Home',
                          link: '/',
                        },
                      ],
                      subTitle: '',
                      title:
                        'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
                    },
                    layout: 'base',
                  },
                ],
              },
            ],
          },
          layout: 'sidebar',
          state: {
            mapState: ['started', 'steps_ebebbfacbc', 'currStep'],
            mapDispatch: [],
          },
        },
      ];
      /* harmony default export */ __webpack_exports__.default = pageConfig;

      /***/
    },
    /* 28 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */ __webpack_exports__.default = {};

      /***/
    },
    /* 29 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */ __webpack_exports__.default = {};

      /***/
    },
    /* 30 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const symbolConfig = [
        {
          id: 'rIFp7n48yQM_cm-KBwxyW',
          name: 'SSO',
          definitions: [
            {
              componentId: 'A27mSv6SUrGTGWhAxuGA_',
              type: 'text',
              props: {
                variant: 'p',
                content:
                  'You need to be logged in with your SmartPass or UAE Pass to use this service. If you are not registered, you can click on the link to complete the process, which takes only a few minutes.',
              },
              layout: 'base',
            },
            {
              componentId: '9TBER1bhO5EVm3GGJJZJS',
              type: 'flexbox',
              props: {
                flexWrap: true,
                flexDirection: 'initial',
                justifyContent: 'initial',
                alignItems: 'initial',
                alignContent: 'initial',
              },
              layout: 'base',
              children: [
                {
                  componentId: 'HzGWFdjcLUNpDSiaIBElW',
                  type: 'uaePassButton',
                  props: {
                    disabled: false,
                    link: '#',
                    'aria-label': 'UAEPass Button',
                  },
                  layout: 'base',
                },
                {
                  componentId: 'f3uu9Is-Q3-nkq01bi2CU',
                  type: 'smartPassButton',
                  props: {
                    disabled: false,
                    link: '#',
                    'aria-label': 'Smartpass Button',
                  },
                  layout: 'base',
                },
              ],
            },
            {
              componentId: 'Tq5AKALVVjXWwaG-OZn9V',
              type: 'flexbox',
              props: {
                flexWrap: true,
                flexDirection: 'initial',
                justifyContent: 'initial',
                alignItems: 'initial',
                alignContent: 'initial',
              },
              layout: 'base',
              children: [
                {
                  componentId: 'Jxk9_71P2_6PGD--Mk156',
                  type: 'text',
                  props: {
                    variant: 'p',
                    content:
                      'UAE Pass is the National Digital Identity solution for the UAE',
                  },
                  layout: 'base',
                },
                {
                  componentId: '5DGKpkG0moukaBESVeX6q',
                  type: 'text',
                  props: {
                    variant: 'p',
                    content:
                      'SmartPass is your digital credential to access UAE Government services',
                  },
                  layout: 'base',
                },
              ],
            },
          ],
        },
      ];
      /* harmony default export */ __webpack_exports__.default = symbolConfig;

      /***/
    },
    /* 31 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony import */ const _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        32,
      );

      const symbolConfig = [
        {
          id: 'c4Z8Zav-0aQru7aHcXS3G',
          name: 'Sidebar',
          definitions: [
            {
              columnIndex: 0,
              componentId: 'fKKzLmvvLPzs7uvihOSwf',
              type: 'stepTracker',
              props: {
                title: '',
                steps: '${state.steps_ebebbfacbc}',
                expandedStepIndexes: [],
                currentStepIndex: '${state.currStep}',
                i18n: '',
                visible: _functions__WEBPACK_IMPORTED_MODULE_0__.f1_visible,
              },
            },
            {
              columnIndex: 0,
              componentId: 'xkNOb9BK0eZcunWl_u0Jl',
              type: 'relevantEntity',
              props: {
                i18n: '',
                title: 'Relevant entity',
                logo:
                  'https://www.bala3nadh.abudhabi/-/media/Project/bala3nadh/Home/Footer%20Logos/Department%20of%20Economic%20Development',
                verticalLogo: false,
                subTitle: 'Department of Economic Development',
                address:
                  'Baniyas Towers, Al Falah Street - Fatima bint Mubarak St 6, Abu Dhabi',
                phones: [],
                website: 'www.adeconomy.ae',
                email: 'email@domain.com',
                officeHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                publicServiceHours: 'Sunday - Thursday 7:00AM - 3:00PM',
                space: {
                  marginTop: 'xl',
                },
              },
            },
            {
              columnIndex: 0,
              componentId: 'yE-5s1oO9uhZzJsZWKtNo',
              type: 'relatedJourneyCard',
              props: {
                aspectOfLifeType: 'business-management',
                icon: null,
                description:
                  'The Manage Your Business journey contains a consolidated dashboard for business owners and representatives to view and...',
                label: 'Manage your business',
                title: 'Related journey',
                space: {
                  marginTop: 'lg',
                },
              },
            },
          ],
        },
      ];
      /* harmony default export */ __webpack_exports__.default = symbolConfig;

      /***/
    },
    /* 32 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */ __webpack_require__.d(
        __webpack_exports__,
        'f1_visible',
        function () {
          return f1_visible;
        },
      );
      function f1_visible(props) {
        return props.started === true;
      }

      /***/
    },
    /* 33 */
    /***/ function (module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      const symbolConfig = [
        {
          id: 'hh7K8LKYM8XfcY8wDBHXV',
          name: 'Hero',
          definitions: [
            {
              componentId: 'VE0v8q2Vojv_KyqFblypq',
              type: 'hero',
              props: {
                backgroundImage:
                  'https://journeys-stg.bala3nadh.abudhabi/journeys/journey-template/images/hero.jpg',
                backgroundBase64Extension: '',
                internal: true,
                aspectOfLifeType: '',
                breadcrumbs: [
                  {
                    label: 'Home',
                    link: '/',
                  },
                ],
                subTitle: '',
                title:
                  'Request for Issuing Permit for ATM, Payment and Self-Service Machines',
              },
              layout: 'base',
            },
          ],
        },
      ];
      /* harmony default export */ __webpack_exports__.default = symbolConfig;

      /***/
    },
    /** *** */
  ],
).default;
