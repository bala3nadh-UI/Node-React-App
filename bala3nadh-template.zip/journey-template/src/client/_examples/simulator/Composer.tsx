import React, { useCallback, useState, useEffect } from 'react';
import { Store } from 'redux';
import AppComposer, { IVariables } from '@bala3nadh/app-composer';
import { OnceOnlyProvider } from '@bala3nadh/oop/client';
import { CmsProvider } from 'client/services/cms/cmsContext';
import {
  getSmartpassData,
  getMetaData,
  getCMSData,
} from 'client/utils/appData';
import formatJSConfig from 'client/utils/workbench/formatJSConfig';
import { StoreContext } from 'client/services/context';
import baseName from 'client/utils/baseName';
import baseUrl from 'client/utils/baseUrl';

import { fetchWithError } from 'client/services/fetch';
import { BpmClient } from 'client/services/bpm';
import analytics from '@bala3nadh/analytics';
import { nanoid as nanoId } from 'nanoid';
import { mapServiceData } from 'client/utils/workbench/service';
import fetchState from './state';
import templates from 'client/_examples/v5/templates';
import WbLocalisation from 'client/_examples/v5/localisation';
import exportedConfig from './index';
import InternalApi from 'client/services/InternalApi';
import { IS_PREVIEW } from './sharedFunctions/constants';
import { withRouter } from 'react-router-dom';

import '@bala3nadh/ui-lib-v2-styles/common.less';
import '@bala3nadh/ui-lib-v2-styles/colors.less';

import 'client/_examples/v5/override.less';
import './override.less';
import qs from 'query-string';
import withJourney from '../../services/journey/withJourney';
import * as componentsRefStoreService from '../../services/componentsRefStore';
import { ComposerServicesProvider } from '../../services/ComposerServices';
import composerRedirect from '../../services/composerRedirect';

const SERVER_SIDE_HANDLED = [
  '/api/smartpass/login',
  '/api/smartpass/logout',
  '/api/smartpass/demo-login',
  '/api/smartpass/demo-logout',
];

const FETCH_STATE_LONG_INTERVAL = 1000 * 15; // 1 minute

const Composer: React.FC = (props: IVariables) => {
  const { metaTags, metaPages, bala3nadhUrl, bala3nadhWorkbenchUrl } = getCMSData();
  const [store, setStore] = useState<Store | null>(null);

  const [cmsTranslations, setCmsTranslations] = useState<any>({
    en: {},
    ar: {},
  });

  const meta = {
    meta: getMetaData(),
    ...(metaTags || {}),
    ...(metaPages ? { pages: metaPages } : {}),
    en: {},
    ar: {},
  };

  const {
    config: journeyConfig,
    translations: journeyTranslations,
  } = formatJSConfig(
    exportedConfig,
    {
      header: {
        template: 'header',
        breadcrumbs: [
          {
            label: 'home',
            link: '#',
          },
        ],
        state: {
          mapState: ['user', 'locale', 'title', 'breadcrumbs'],
          mapDispatch: ['user', 'locale'],
        },
        props: {},
      },
      footer: {
        template: 'footer',
        state: {
          mapState: ['user'],
        },
      },
    },
    WbLocalisation,
  );

  // const isPreview = props.location.search.includes('preview=1');
  const isPreview = IS_PREVIEW;
  const { userJourneyId } = props.match.params;
  const query = qs.parse(props.location.search);
  const journeyId = query.journeyId;
  const stageId = query.stageId;
  const isJourney = journeyId && userJourneyId;

  journeyTranslations.en = { ...journeyTranslations.en, ...cmsTranslations.en };
  journeyTranslations.ar = { ...journeyTranslations.ar, ...cmsTranslations.ar };

  const onInit = useCallback(
    (value: Store) => {
      setStore(value);
    },
    [setStore],
  );

  useEffect(() => {
    const copyTranslations = { ...cmsTranslations };
    if (journeyConfig.dictionaryCmsId) {
      InternalApi.getCmsPage(journeyConfig.dictionaryCmsId, 'en').then(
        (resp: any) => {
          const { data } = resp;
          data.PageContent.forEach((c: any) => {
            copyTranslations.en[c.ContentJson.Title] =
              c.ContentJson.Description;
          });
          InternalApi.getCmsPage(journeyConfig.dictionaryCmsId, 'ar-ae').then(
            (resp: any) => {
              const { data } = resp;
              console.log(journeyTranslations);
              data.PageContent.forEach((c: any) => {
                copyTranslations.ar[c.ContentJson.Title] =
                  c.ContentJson.Description;
              });
            },
          );
          setCmsTranslations(copyTranslations);
        },
      );
    }
  }, []);

  return (
    <StoreContext.Provider value={store}>
      <OnceOnlyProvider baseUrl={baseUrl}>
        <CmsProvider
          loadFromCms={journeyConfig.loadFromCms}
          pages={journeyConfig.pages}
          symbols={journeyConfig.symbols}
        >
          <ComposerServicesProvider>
            <AppComposer
              customTemplateHooks={[withJourney]}
              config={journeyConfig}
              baseUrl={`${baseName}`}
              user={getSmartpassData()}
              meta={meta}
              translations={journeyTranslations}
              serverHandled={SERVER_SIDE_HANDLED}
              fetchState={fetchState}
              fetchStateInterval={FETCH_STATE_LONG_INTERVAL}
              skipFetchState={[
                ...(journeyConfig.skipFetchState || []),
                '/login',
              ]}
              customTemplates={templates}
              services={{
                bala3nadhWorkbenchUrl,
                bala3nadhUrl,
                fetch: fetchWithError,
                BpmClient,
                analytics,
                refs: componentsRefStoreService,
                ...(isJourney
                  ? { globalContext: { isPreview, userJourneyId, stageId } }
                  : {}),
                utils: {
                  mapServiceData,
                  nanoId,
                },
                onceOnlyHelpers: {
                  baseUrl,
                },
              }}
              onInit={onInit}
            />
          </ComposerServicesProvider>
        </CmsProvider>
      </OnceOnlyProvider>
    </StoreContext.Provider>
  );
};

export default withRouter(composerRedirect(Composer, 'simulator'));
