import bpm from 'client/services/bpm';
import pageQuestionnaire from './pages/Questionnaire';
import pageNotFound from './pages/PageNotFound';
import pageLogin from './pages/Login';
import pageAccountUpgradeRequired from './pages/AccountUpgradeRequired';

import { IVariables } from '@bala3nadh/app-composer';
import dummyHeroSymbol from './symbols/ObMm1QSg3GS23t8rHYIyF';

import { SmartQuestionnaireCmsData } from './templates/SmartQuestionnaire/types';

export const IS_PREVIEW = true;

interface IStep {
  name: string;
  subSteps?: string[];
}

interface IState {
  isSQPreview: boolean;
  questionnaireConfig: IVariables;
  questionnaireAnswers: IVariables;
  questionnairePath: string;
  questionStack: string[];
  previousAnswers: IVariables[];
  heroTitle: string;
  dynamicEntity: IVariables[];
  activeQuestionId: string;
  dynamicDropdownOptions: IVariables;
  validationErrors: IVariables;
  noticePageProps: IVariables;
  processSteps: IStep[];
  stepsStatus: IVariables;
  currentStep: string;
  savedJourneyId: string;
  adlApplicationId: string;
  pageInitStatus: {
    isExecuted: boolean;
    questionnairePath: string;
  };
  guestUserInstanceId: string;
  relatedActionProps: IVariables;
  initCallbackRenderStatus: {
    isExecuted: boolean;
    questionnairePath: string;
  };
  questionnaireCmsStatus: SmartQuestionnaireCmsData;
  disableRedoQuestionnaire: boolean;
  dataSourceProps: {
    isDynamic: false;
    noQuestions?: number;
  };
  hideTracker: boolean;
}

const initialState: IState = {
  isSQPreview: IS_PREVIEW,
  questionnaireConfig: {},
  questionnaireAnswers: {},
  questionnairePath: '',
  questionStack: [],
  previousAnswers: [],
  heroTitle: 'Smart Questionnaire',
  dynamicEntity: [],
  activeQuestionId: '',
  dynamicDropdownOptions: {},
  validationErrors: {},
  noticePageProps: {
    en: {
      status: 'success',
      title: "i18n('noticePage-title')",
      content: "i18n('noticePage-content')",
      additionalButton: false,
    },
    ar: {
      status: 'success',
      title: "i18n('noticePage-title')",
      content: "i18n('noticePage-content')",
      additionalButton: false,
    },
  },
  processSteps: [
    {
      name: 'step-fillQuestionnaire',
    },
    {
      name: 'step-outputPage',
    },
  ],
  stepsStatus: {},
  currentStep: 'step-fillQuestionnaire',
  savedJourneyId: 'standalone',
  adlApplicationId: '',
  pageInitStatus: {
    isExecuted: false,
    questionnairePath: '',
  },
  guestUserInstanceId: '',
  relatedActionProps: {
    cmsFetchStatus: false,
  },
  initCallbackRenderStatus: {
    isExecuted: false,
    questionnairePath: '',
  },
  questionnaireCmsStatus: {
    isFetched: false,
    cmsId: '',
    data: {},
  },
  disableRedoQuestionnaire: false,
  dataSourceProps: {
    isDynamic: false,
  },
  hideTracker: false,
};

const config = {
  version: '1.0.0',
  appName: 'bala3nadh-tool-questionnaire',
  defaults: {
    title: 'bala3nadh',
  },
  getVariables: bpm.getVariables,
  symbols: [...dummyHeroSymbol],
  initialState,
  hero: [
    {
      type: 'symbol',
      props: {
        symbol: 'ObMm1QSg3GS23t8rHYIyF',
      },
      state: {
        mapState: [],
        mapDispatch: [],
      },
    },
  ],
  header: {
    template: 'header',
    props: {
      aspectsOfLifeType: 'business-management',
      breadcrumbs: [],
    },
    state: {
      mapState: ['user', 'locale', 'title', 'breadcrumbs'],
      mapDispatch: ['user', 'locale'],
    },
    // hideForPaths: ['/'],
  },
  footer: {
    template: 'footer',
    state: {
      mapState: ['user'],
    },
    // hideForPaths: ['/'],
  },
  pages: [
    ...pageAccountUpgradeRequired,
    ...pageLogin,
    ...pageNotFound,
    ...pageQuestionnaire,
  ],
};

export default config;
