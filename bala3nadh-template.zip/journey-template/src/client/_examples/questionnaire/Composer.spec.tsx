import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { Viewport, ViewportProvider } from '@bala3nadh/ui-lib-v2-viewport';
import { MemoryRouter } from 'react-router';
import Composer from './Composer';
import { IVariables } from '@bala3nadh/app-composer';

jest.mock('client/utils/appData', () => ({
  getCMSData: jest.fn(() => {
    return {
      navigationItems: {
        en: [],
        ar: [],
      },
    };
  }),
  getSmartpassData: jest.fn(),
  getMetaData: jest.fn(),
  getJourneyContext: jest.fn(),
}));

describe('config/v5/Composer', () => {
  let defaultProps: IVariables;

  beforeAll(() => {
    window.matchMedia =
      window.matchMedia ||
      function () {
        return {
          matches: false,
          addListener() {},
          removeListener() {},
        };
      };
  });

  beforeEach(() => {
    defaultProps = {
      fromProcessState: {},
    };
  });

  it('renders', () => {
    render(
      <MemoryRouter>
        <ViewportProvider>
          <Viewport sm md lg xl>
            <Composer />
          </Viewport>
        </ViewportProvider>
      </MemoryRouter>,
    );
  });
});
