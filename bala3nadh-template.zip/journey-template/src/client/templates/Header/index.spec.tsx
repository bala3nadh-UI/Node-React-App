import React, { Suspense } from 'react';
import { render, cleanup } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import '@testing-library/jest-dom/extend-expect';
import { Viewport, ViewportProvider } from '@bala3nadh/ui-lib-v2-viewport';
import {
  HeaderTemplate as Header,
  onSearch,
  getSearchUrl,
  onLanguageChange,
  RenderDefinition,
} from './index';

jest.mock('client/utils/appData', () => ({
  getCMSData: jest.fn(() => {
    return {
      journeyInfo: {
        en: {
          headerInfo: {
            logo: {
              desktopLogoPath: 'desktopLogoPath',
              mobileLogoPath: 'mobileLogoPath',
            },
            burgerMenuLinks: [
              {
                sectionName: 'sectionName',
                links: [
                  {
                    title: 'Title',
                    link: '/link',
                  },
                ],
              },
            ],
            profileMenuLinks: null,
            dashboardMenuLinks: null,
            registerLink: {
              label: 'label',
              link: '/link',
            },
            loggedOutUserIconPath: '/loggedOutUserIconPath',
            logoutLabel: '',
            welcomeMessage: 'welcomeMessage',
            uaePassImage: 'uaePassImage',
            smartPassImage: 'smartPassImage',
          },
        },
      },
    };
  }),
}));

describe('client/templates/Header', () => {
  let props: any;

  beforeEach(() => {
    props = {
      locale: 'en',
      i18n: jest.fn(i => i),
      actions: {
        locale: {
          switch: jest.fn(),
        },
        hero: {
          update: jest.fn(),
        },
        breadcrumbs: {
          update: jest.fn(),
        },
      },
      breadcrumbs: [
        {
          label: 'label',
          link: 'http://example.com',
        },
      ],
      history: {
        push: jest.fn(),
      },
      location: {
        pathname: '/en/aspects-of-life/category',
      },
      match: {},
      loggedIn: false,
      title: 'title',
    };
  });

  afterEach(cleanup);

  test('renders login', () => {
    props.location.pathname = '/ar-AE/aspects-of-life/category';
    props.locale = 'ar-AE';

    const { getByText } = render(
      <MemoryRouter>
        <ViewportProvider>
          <Viewport sm md lg xl>
            <Header {...props} />
          </Viewport>
        </ViewportProvider>
      </MemoryRouter>,
    );

    expect(getByText('Log in')).toBeInTheDocument();
  });

  it('renders RenderDefinition', () => {
    render(
      <MemoryRouter>
        <Suspense fallback={<div />}>
          <RenderDefinition />
        </Suspense>
      </MemoryRouter>,
    );
  });

  test('renders login without hero', () => {
    props.hero = false;
    const location: any = new URL('https://www.example.com');
    location.assign = jest.fn();
    location.replace = jest.fn();
    location.reload = jest.fn();
    location.search = '?ket=value';

    delete window.location;
    window.location = location;
    const { getByText } = render(
      <MemoryRouter>
        <ViewportProvider>
          <Viewport sm md lg xl>
            <Header {...props} />
          </Viewport>
        </ViewportProvider>
      </MemoryRouter>,
    );

    expect(getByText('Log in')).toBeInTheDocument();
  });

  test('onSearch function', () => {
    expect(onSearch('text')).toBe(undefined);
  });

  test('onLanguageChange function with ar/en lang', () => {
    const returnedFn = onLanguageChange(props);

    props.locale = 'ar';
    expect(returnedFn()).toBe(undefined);

    props.locale = 'en';
    expect(returnedFn()).toBe(undefined);
  });

  test('getSearchUrl function with ar lang', () => {
    props.locale = 'ar';

    expect(getSearchUrl(props)).toBe(
      'https://www.example.com/pub/search/autosuggest?term=$[searchTerm]&count=5&lang=ar-AE',
    );
  });

  test('renders loggedIn and unknown lang', () => {
    props.loggedIn = true;
    props.user = {
      'First Name EN': 'User',
      'Last Name EN': 'User2',
      Photo: 'photo-link',
    };
    props.location.pathname = '/ar/aspects-of-life/category';
    render(
      <MemoryRouter>
        <ViewportProvider>
          <Viewport sm md lg xl>
            <Header {...props} />
          </Viewport>
        </ViewportProvider>
      </MemoryRouter>,
    );
  });
});
