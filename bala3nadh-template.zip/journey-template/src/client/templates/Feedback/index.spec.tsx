import React from 'react';
import { shallow } from 'enzyme';
import GlobalCsatFeedback from '@bala3nadh/ui-lib-v2-global-csat-feedback';
import { fetchWithError } from 'client/services/fetch';
import Feedback from './index';

jest.mock('client/services/fetch');

describe('Feedback', () => {
  it('should render component', () => {
    const component = shallow(<Feedback i18n={() => ({})} bala3nadhUrl="" />);
    expect(component).toMatchSnapshot();
  });

  it('should render success state', async () => {
    const component = shallow(<Feedback i18n={() => ({})} bala3nadhUrl="" />);
    (fetchWithError as jest.Mock).mockReturnValue(
      jest.fn().mockResolvedValue({
        success: true,
      }),
    );
    const onSubmit =
      component.find(GlobalCsatFeedback).prop('onSubmit') || (() => {});
    await onSubmit('positive', {}, { data: {}, status: '', statusCode: 201 });
    expect(component).toMatchSnapshot();
  });

  it('should render error state', async () => {
    const component = shallow(<Feedback i18n={() => ({})} bala3nadhUrl="" />);
    (fetchWithError as jest.Mock).mockReturnValue(
      jest.fn().mockResolvedValue({
        success: false,
      }),
    );
    const onSubmit =
      component.find(GlobalCsatFeedback).prop('onSubmit') || (() => {});
    await onSubmit('positive', {}, { data: {}, status: '', statusCode: 201 });
    expect(component).toMatchSnapshot();
  });

  it('should render error state', async () => {
    const component = shallow(<Feedback i18n={() => ({})} bala3nadhUrl="" />);
    (fetchWithError as jest.Mock).mockReturnValue(
      jest.fn().mockRejectedValue({}),
    );
    const onSubmit =
      component.find(GlobalCsatFeedback).prop('onSubmit') || (() => {});
    await onSubmit('positive', {}, { data: {}, status: '', statusCode: 201 });
    expect(component).toMatchSnapshot();
  });
});
