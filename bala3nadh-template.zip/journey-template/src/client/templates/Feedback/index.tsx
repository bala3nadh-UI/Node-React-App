import React, { useCallback, useState } from 'react';

import GlobalCsatFeedback, {
  EmotionType,
} from '@bala3nadh/ui-lib-v2-global-csat-feedback';

import { fetchWithError } from 'client/services/fetch';
import { DoorLock, MailRounded } from '@bala3nadh/ui-lib-v2-icons/all-icons';

interface FeedbackOptions {
  ease: number;
  quality: number;
  performance: number;
  comment: string;
}

interface FeedbackProps {
  i18n: any;
  bala3nadhUrl: string;
}

function Feedback(props: FeedbackProps) {
  const [status, setStatus] = useState<
    'idle' | 'active' | 'pending' | 'success' | 'error'
  >('idle');
  const handleSubmit = useCallback(
    async (
      smileyType: EmotionType,
      options: { [key: string]: string | number },
    ) => {
      const usedOptions = (options as unknown) as FeedbackOptions;

      setStatus('pending');

      try {
        const result = await fetchWithError(() => {
          setStatus('error');
        })('/pub/feedback/feedbacks', 'POST', {
          surveyType: 'general',
          smileyType,
          comments: usedOptions.comment,
          ratings: {
            ease: usedOptions.ease,
            quality: usedOptions.quality,
            performance: usedOptions.performance,
          },
          pageUrl: window.location.href,
        });

        if (result.success) {
          setStatus('success');
        }
      } catch (e) {
        setStatus('error');
      }
    },
    [],
  );
  const langParam = window.localStorage.locale === 'en' ? 'en' : 'ar-ae';
  const floatingButtonstArr = [
    {
      icon: MailRounded,
      href: `${props.bala3nadhUrl}/${langParam}/mylocker/TalkToUs`,
      text: props.i18n('talk_to_us'),
    },
    {
      icon: DoorLock,
      href: `${props.bala3nadhUrl}/${langParam}/mylocker`,
      text: props.i18n('my_locker'),
    },
  ];

  return (
    <GlobalCsatFeedback
      onSubmit={handleSubmit}
      i18n={props.i18n}
      status={status}
      autoOpen={false}
      floatingButtons={[...(floatingButtonstArr || [])].map((link: any) => ({
        text: link.text,
        href: link.href,
        icon: link.icon,
      }))}
    />
  );
}

export default Feedback;
