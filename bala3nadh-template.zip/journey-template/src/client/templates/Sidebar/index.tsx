import { connect } from 'react-redux';
import { IVariables } from '@bala3nadh/app-composer';
import Sidebar from './Sidebar.component';

export default connect((state: IVariables) => ({
  steps: state.steps || [],
}))(Sidebar);
