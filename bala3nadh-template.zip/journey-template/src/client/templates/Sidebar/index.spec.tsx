import React, { Suspense } from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import configureMockStore from 'redux-mock-store';
import { MemoryRouter } from 'react-router';
import { render, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { Viewport, ViewportProvider } from '@bala3nadh/ui-lib-v2-viewport';
import Sidebar, { IStep } from './Sidebar.component';
import SidebarContainer from './index';

const mockStore = configureMockStore([]);

const steps: IStep[] = [
  { name: 'trade_name', subSteps: ['submit_name', 'waiting_approval'] },
  {
    name: 'trade_licence',
    subSteps: ['submit_licence', 'waiting_approval', 'result'],
  },
  {
    name: 'trade_licence',
    subSteps: [],
  },
];

describe('client/templates/Sidebar', () => {
  let props: any;
  let store: any;

  beforeEach(() => {
    props = {
      locale: 'en',
      i18n: jest.fn(i => i),
      currentStep: 'trade_name',
      currentSubStep: 'submit_licence',
      stepsStatus: {
        trade_name: 'trade_name',
        'trade_name.submit_licence': 'trade_name.submit_licence',
      },
      steps,
    };

    store = mockStore({ steps });
  });

  afterEach(cleanup);

  it('renders SidebarContainer', () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <Suspense fallback={<div />}>
            <ViewportProvider>
              <Viewport sm md lg xl>
                <SidebarContainer {...props} />
              </Viewport>
            </ViewportProvider>
          </Suspense>
        </MemoryRouter>
      </Provider>,
    );
  });

  it('renders the wrapper component', () => {
    const wrapper = mount(
      <Provider store={store}>
        <MemoryRouter>
          <ViewportProvider>
            <Viewport sm md lg xl>
              <SidebarContainer {...props} />
            </Viewport>
          </ViewportProvider>
        </MemoryRouter>
      </Provider>,
    );

    expect(wrapper.find(SidebarContainer).length).toBeTruthy();
    const container = wrapper.find(SidebarContainer);
    expect(container.find(Sidebar).length).toBeTruthy();
    expect(container.find(Sidebar).props().steps).toBeTruthy();
  });

  test('renders', () => {
    const { getByText } = render(
      <MemoryRouter>
        <ViewportProvider>
          <Viewport sm md lg xl>
            <Sidebar {...props} />
          </Viewport>
        </ViewportProvider>
      </MemoryRouter>,
    );

    expect(getByText('trade_name')).toBeInTheDocument(); // TODO: Check
  });
});
