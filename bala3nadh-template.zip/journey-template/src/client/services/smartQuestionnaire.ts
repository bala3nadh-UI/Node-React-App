import { IVariables } from '@bala3nadh/app-composer';
import fetch from './fetch';

const fetchSmartQuestionnaireConfig = (
  questionnairePath: string,
  isPreview: boolean,
  userJourneyId: string,
) => {
  return fetch(`/pub/smart-questionnaire/fetchConfig`, 'POST', {
    questionnairePath,
    isPreview,
    userJourneyId,
  });
};

const updateSmartQuestionnaireDraft = (
  questionnairePath: string,
  isPreview: boolean,
  userJourneyId: string,
  draftData: IVariables,
  guestUserInstanceId: string,
  isDynamicSQ: boolean,
  dynamicSQConfig: IVariables,
) => {
  return fetch('/pub/smart-questionnaire/updateDraft', 'POST', {
    questionnairePath,
    isPreview,
    userJourneyId,
    draftData,
    guestUserInstanceId,
    isDynamicSQ,
    dynamicSQConfig,
  });
};

const deleteSmartQuestionnaireDraft = (
  questionnairePath: string,
  isPreview: boolean,
  userJourneyId: string,
  guestUserInstanceId: string,
) => {
  return fetch('/pub/smart-questionnaire/deleteDraft', 'POST', {
    questionnairePath,
    isPreview,
    userJourneyId,
    guestUserInstanceId,
  });
};

const createSimulatorInstance = (
  simulatorPath: string,
  userJourneyId: string,
  isPreview: boolean,
  questionnaireResponses: IVariables,
  questionnairePath: string,
  data: IVariables,
) => {
  return fetch('/pub/simulator-engine/createSimulatorInstance', 'POST', {
    simulatorPath,
    userJourneyId,
    isPreview,
    questionnaireResponses,
    questionnairePath,
    data,
  });
};

const startQuestionnaire = (adlockerRequest: IVariables) => {
  return fetch('/pub/smart-questionnaire/startQuestionnaire', 'POST', {
    ...adlockerRequest,
  });
};

const cancelQuestionnaire = (adlockerRequest: IVariables) => {
  return fetch('/pub/smart-questionnaire/cancelQuestionnaire', 'POST', {
    ...adlockerRequest,
  });
};

const completeQuestionnaire = (adlockerRequest: IVariables) => {
  return fetch('/pub/smart-questionnaire/completeQuestionnaire', 'POST', {
    ...adlockerRequest,
  });
};

const fetchCmsDetails = (cmsId: string, requiresEntityDetails?: boolean) => {
  return fetch('/pub/smart-questionnaire/fetchCmsDetails', 'POST', {
    cmsId,
    requiresEntityDetails,
  });
};

const fetchQuestionById = (
  questionId: string,
  path: string,
  responses: IVariables,
  stack: string[],
) => {
  return fetch('/pub/smart-questionnaire/fetchQuestionById', 'POST', {
    questionId,
    path,
    responses,
    stack,
  });
};

export {
  fetchSmartQuestionnaireConfig,
  updateSmartQuestionnaireDraft,
  deleteSmartQuestionnaireDraft,
  createSimulatorInstance,
  startQuestionnaire,
  cancelQuestionnaire,
  completeQuestionnaire,
  fetchCmsDetails,
  fetchQuestionById,
};
