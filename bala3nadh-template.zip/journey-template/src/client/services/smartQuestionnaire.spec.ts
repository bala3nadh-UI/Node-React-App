import fetch from 'client/services/fetch';
import {
  fetchSmartQuestionnaireConfig,
  updateSmartQuestionnaireDraft,
  deleteSmartQuestionnaireDraft,
  createSimulatorInstance,
  startQuestionnaire,
  completeQuestionnaire,
  fetchCmsDetails,
} from './smartQuestionnaire';

jest.mock('client/services/fetch');

describe('services/smartQuestionnaire', () => {
  let mockFetch: any;
  beforeAll(() => {
    mockFetch = fetch;
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });
  });

  describe('fetchSmartQuestionnaireConfig', () => {
    it('should be a function', () => {
      expect(fetchSmartQuestionnaireConfig).toBeInstanceOf(Function);
    });

    it('should call properly', () => {
      fetchSmartQuestionnaireConfig('path', true, 'standalone');
      expect(mockFetch).toHaveBeenCalledWith(
        '/pub/smart-questionnaire/fetchConfig',
        'POST',
        {
          questionnairePath: 'path',
          isPreview: true,
          userJourneyId: 'standalone',
        },
      );
    });
  });

  describe('updateSmartQuestionnaireDraft', () => {
    it('should be a function', () => {
      expect(updateSmartQuestionnaireDraft).toBeInstanceOf(Function);
    });

    it('should call properly', () => {
      updateSmartQuestionnaireDraft(
        'path',
        true,
        'standalone',
        { foo: 'bar' },
        '',
        false,
        {},
      );
      expect(mockFetch).toHaveBeenCalledWith(
        '/pub/smart-questionnaire/updateDraft',
        'POST',
        {
          questionnairePath: 'path',
          isPreview: true,
          userJourneyId: 'standalone',
          draftData: {
            foo: 'bar',
          },
          guestUserInstanceId: '',
          isDynamicSQ: false,
          dynamicSQConfig: {},
        },
      );
    });
  });

  describe('deleteSmartQuestionnaireDraft', () => {
    it('should be a function', () => {
      expect(deleteSmartQuestionnaireDraft).toBeInstanceOf(Function);
    });

    it('should call properly', () => {
      deleteSmartQuestionnaireDraft('path', true, 'standalone', '');
      expect(mockFetch).toHaveBeenCalledWith(
        '/pub/smart-questionnaire/deleteDraft',
        'POST',
        {
          questionnairePath: 'path',
          isPreview: true,
          userJourneyId: 'standalone',
          guestUserInstanceId: '',
        },
      );
    });
  });

  describe('createSimulatorInstance', () => {
    it('should be a function', () => {
      expect(createSimulatorInstance).toBeInstanceOf(Function);
    });

    it('should call properly', () => {
      createSimulatorInstance(
        '/simulator-path',
        'mockUserJourneyId',
        true,
        { foo: 'bar' },
        '/questionnaire-path',
        [],
      );
      expect(mockFetch).toHaveBeenCalledWith(
        '/pub/simulator-engine/createSimulatorInstance',
        'POST',
        {
          simulatorPath: '/simulator-path',
          userJourneyId: 'mockUserJourneyId',
          isPreview: true,
          questionnaireResponses: {
            foo: 'bar',
          },
          questionnairePath: '/questionnaire-path',
          data: [],
        },
      );
    });
  });

  describe('startQuestionnaire', () => {
    it('should be a function', () => {
      expect(startQuestionnaire).toBeInstanceOf(Function);
    });

    it('should call properly', () => {
      startQuestionnaire({
        foo: 'bar',
      });
      expect(mockFetch).toHaveBeenCalledWith(
        '/pub/smart-questionnaire/startQuestionnaire',
        'POST',
        {
          foo: 'bar',
        },
      );
    });
  });

  describe('completeQuestionnaire', () => {
    it('should be a function', () => {
      expect(completeQuestionnaire).toBeInstanceOf(Function);
    });

    it('should call properly', () => {
      completeQuestionnaire({
        foo: 'bar',
      });
      expect(mockFetch).toHaveBeenCalledWith(
        '/pub/smart-questionnaire/completeQuestionnaire',
        'POST',
        {
          foo: 'bar',
        },
      );
    });
  });

  describe('fetchCmsDetails', () => {
    it('should be a function', () => {
      expect(fetchCmsDetails).toBeInstanceOf(Function);
    });

    it('should call properly', () => {
      fetchCmsDetails('cmsId');
      expect(mockFetch).toHaveBeenCalledWith(
        '/pub/smart-questionnaire/fetchCmsDetails',
        'POST',
        {
          cmsId: 'cmsId',
        },
      );
    });
  });
});
