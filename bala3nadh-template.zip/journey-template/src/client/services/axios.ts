import axios, { AxiosRequestConfig } from 'axios';
import baseUrl from '../utils/baseUrl';

const configuredAxios = async (incomingConfig: AxiosRequestConfig) => {
  const config = incomingConfig;
  const method: string = config.method?.toUpperCase() as string;
  config.headers = config.headers || {};
  config.url = `${baseUrl}${config.url}`;
  if (['POST', 'PUT'].includes(method)) {
    const token = (document.querySelector(
      'meta[name="csrf-token"]',
    ) as HTMLInputElement).getAttribute('content');
    config.headers['csrf-token'] = token;
  }
  return axios(config);
};

export default configuredAxios;
