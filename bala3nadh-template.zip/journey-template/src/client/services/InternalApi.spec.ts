import fetch from 'client/services/fetch';
import InternalApi from './InternalApi';

jest.mock('client/services/fetch');

describe('InternalApi', () => {
  let mockFetch: any;

  beforeAll(() => {
    mockFetch = fetch;
  });

  describe('sendErrorLogs', () => {
    it('should be instance of function', () =>
      expect(InternalApi.sendErrorLogs).toBeInstanceOf(Function));

    it('should call api with post method with correct params', () => {
      mockFetch.mockImplementation(() => {
        return Promise.resolve({});
      });

      const data = {
        some: 'error',
      };

      InternalApi.sendErrorLogs(data);

      expect(mockFetch).toHaveBeenCalledWith('/error-logging', 'POST', {
        data,
      });
    });
  });

  describe('getServiceByPath', () => {
    it('should be instance of function', () =>
      expect(InternalApi.getServiceByPath).toBeInstanceOf(Function));

    it('should call api with get method with correct params', () => {
      mockFetch.mockImplementation(() => {
        return Promise.resolve({});
      });

      const servicePath = '/servicePath';

      InternalApi.getServiceByPath(servicePath);

      expect(mockFetch).toHaveBeenCalledWith(
        `/pub/service/gsp-path/${servicePath}`,
      );
    });
  });
});
