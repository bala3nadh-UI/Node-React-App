import configuredAxios from './axios';

describe('axios', () => {
  it('should return configured axios entity', () => {
    const axios = configuredAxios({});
    expect(axios).toBeTruthy();
  });
});
