import React, { useEffect } from 'react';
import { useComposerServices } from '../ComposerServices';
import InternalApi from '../InternalApi';
import getUserJourneyService from './journey';

const withJourney = (BaseComponent: any, isPageBody: boolean = false) => {
  let Wrapped;
  if (isPageBody) {
    Wrapped = (props: any) => {
      const { globalContext, appId } = props;
      const composerServiceContext = useComposerServices();
      useEffect(() => {
        if (globalContext) {
          const { userJourneyId, isPreview, stageId } = globalContext;
          if (appId) {
            InternalApi.getUserJourneyContext(appId, userJourneyId, isPreview)
              .then(res => {
                const globalContextData = res.data;
                const globalContextUtils = getUserJourneyService(
                  appId,
                  stageId,
                  userJourneyId,
                  globalContextData,
                  isPreview,
                );
                composerServiceContext.actions.setJourneyService(
                  globalContextUtils,
                );
              })
              .catch(() => {
                const globalContextUtils = getUserJourneyService(
                  appId,
                  stageId,
                  userJourneyId,
                  { accessMetadata: { read: [], write: [] }, data: {} },
                  isPreview,
                );
                composerServiceContext.actions.setJourneyService(
                  globalContextUtils,
                );
              });
          } else {
            const globalContextUtils = getUserJourneyService(
              appId,
              stageId,
              userJourneyId,
              { accessMetadata: { read: [], write: [] }, data: {} },
              isPreview,
            );
            composerServiceContext.actions.setJourneyService(
              globalContextUtils,
            );
          }
        }
      }, [appId]);

      if (!composerServiceContext.state.journeyService && globalContext)
        return <></>;
      return (
        <BaseComponent
          {...props}
          {...composerServiceContext.state.journeyService}
        />
      );
    };
  } else {
    Wrapped = (props: any) => {
      const composerServiceContext = useComposerServices();
      return (
        <BaseComponent
          {...props}
          {...composerServiceContext.state.journeyService}
        />
      );
    };
  }
  return Wrapped;
};

export default withJourney;
