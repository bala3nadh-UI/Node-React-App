/* eslint-disable no-console */
import { getJourneyData } from 'client/utils/appData';
import getUserJourneyService from './journey';

jest.mock('client/services/fetch');
jest.mock('client/utils/appData');

describe('getUserJourneyService', () => {
  jest.spyOn(global.console, 'log');

  let mockJourneyData: any;

  beforeEach(() => {
    mockJourneyData = getJourneyData;
  });

  it('should return journey service', () => {
    // @ts-ignore
    mockJourneyData.mockImplementationOnce(() => ({
      journeyId: 'test-journey',
      settings: {
        name: 'abc',
      },
      stages: [
        {
          id: 'abcd',
        },
        {
          id: 'efgh',
        },
      ],
    }));
    const result = getUserJourneyService(
      'test',
      'abcd',
      '1234',
      { accessMetadata: { write: ['test'] }, data: { test: '123' } },
      true,
    );

    expect(result.journey.settings).toEqual({
      name: 'abc',
    });
  });

  it('update function should handle not mapped variables', () => {
    // @ts-ignore
    mockJourneyData.mockImplementationOnce(() => ({
      journeyId: 'test-journey',
      settings: {
        name: 'abc',
      },
      stages: [
        {
          id: 'abcd',
        },
        {
          id: 'efgh',
        },
      ],
    }));
    const result = getUserJourneyService(
      'test',
      'abcd',
      '1234',
      { accessMetadata: { write: ['test'] }, data: { test: '123' } },
      true,
    );
    result.globalContext.update({ test: 123, info: 123 });
    result.globalContext.update({ test: 123 });
    expect(console.log).toHaveBeenCalled();
  });
});
