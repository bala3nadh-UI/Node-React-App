import fetch from 'client/services/fetch';
import { getJourneyData } from 'client/utils/appData';
/* global GLOBAL_CONTEXT */
const baseServiceUrl = `/api/proxy/ms-call/${GLOBAL_CONTEXT}/context`;

export default function getUserJourneyService(
  itemId: string,
  stageId: string,
  userJourneyId: string,
  journeyContextData: any,
  isPreview: boolean,
) {
  const journeyData = getJourneyData();
  const { data: globalContextData, accessMetadata } = journeyContextData;
  async function update(data: any) {
    const clonedData = { ...data };
    const eliminatedAttributes: string[] = [];
    Object.keys(data).forEach(key => {
      if (!accessMetadata.write.includes(key)) {
        eliminatedAttributes.push(key);
        delete clonedData[key];
      }
    }, {});
    if (eliminatedAttributes.length)
      // eslint-disable-next-line no-console
      console.log(
        `Eliminating ${eliminatedAttributes.join(
          ',',
        )} as it is not mapped to the current app`,
      );
    const result = await fetch(
      `${baseServiceUrl}/${itemId}/${userJourneyId}`,
      'PUT',
      {
        body: clonedData,
        headers: {
          userId: '{{user.User Unique Identifier}}',
          isPreview,
        },
      },
    );
    return result;
  }

  return {
    globalContext: itemId
      ? {
          update,
          ...globalContextData,
        }
      : {},
    journey: {
      dashboardUrl: `${window.location.origin}/journeys/${journeyData.journeyId}/dashboard/${userJourneyId}`,
      instanceId: userJourneyId,
      settings: journeyData.settings,
      stages: journeyData.stages,
      currentStage: journeyData.stages
        ? journeyData.stages.find((item: any) => item.id === stageId)
        : {},
      currentStageOrder: journeyData.stages
        ? journeyData.stages.findIndex((item: any) => item.id === stageId)
        : {},
    },
  };
}
