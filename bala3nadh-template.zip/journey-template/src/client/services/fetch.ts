/* globals APP_NESTED_PATH */

import { IVariables } from '@bala3nadh/app-composer';
import baseFetch from 'universal-fetch';
import baseUrl from '../utils/baseUrl';
import history from '../utils/history';

interface IFetchConfig {
  method: string;
  mode: string;
  credentials: string;
  headers: IVariables;
}

const defaults: IFetchConfig = {
  method: 'POST', // handy with GraphQL backends
  mode: 'same-origin',
  credentials: 'same-origin',
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
  },
};

function callUpdateError(
  updateError: any,
  errorTranslationKey: string | boolean,
) {
  window.scrollTo({
    top: 0,
    left: 0,
    behavior: 'smooth',
  });
  updateError(errorTranslationKey);
}

function prepareConfig(incomingMethod: string, data: object | boolean) {
  const method = incomingMethod.toUpperCase();
  const config = {
    ...defaults,
    method,
    body: {},
  };

  if (method === 'POST' || method === 'PUT') {
    const token = (document.querySelector(
      'meta[name="csrf-token"]',
    ) as HTMLInputElement).getAttribute('content');
    config.headers = {
      ...config.headers,
      'csrf-token': token,
    };
  }

  let urlParams = '';
  if (data && method !== 'GET') {
    config.body = JSON.stringify(data);
  } else if (data && method === 'GET') {
    const dataString = JSON.stringify(data);
    urlParams = `?data=${encodeURIComponent(dataString)}`;
    delete config.body;
  } else {
    delete config.body;
  }

  return {
    config,
    urlParams,
  };
}

export type ChangeHandler = (data: {
  state: object;
  actions: object;
  bpm: object;
  history: object;
  path: string;
}) => void;

// /**
//  * @param {string} url
//  * @param {string} method
//  * @param {Object} data
//  * @returns {Promise<any | never>}
//  */
export const fetchWithError = (
  updateError: any = () => {},
  setOnStateChange: (func: ChangeHandler | boolean) => void = () => {},
) => async (
  url: string,
  method: string = 'GET',
  data: object | boolean = false,
  errorTranslationKey: string | boolean = true, // use true for default key
  throwError: boolean = true,
  onStateChange: ChangeHandler | boolean = false,
  loginRedirectLink?: string,
) => {
  // eslint-disable-next-line no-param-reassign
  const { config, urlParams } = prepareConfig(method, data);

  setOnStateChange(onStateChange);
  try {
    let response;

    if (url.includes('https://') || url.includes('http://'))
      response = await baseFetch(`${url}${urlParams}`, config);
    else response = await baseFetch(`${baseUrl}${url}${urlParams}`, config);
    if (
      response.status === 401 &&
      !history.location.pathname.includes('/login')
    ) {
      const redirectURL = loginRedirectLink
        ? `${APP_NESTED_PATH}/${loginRedirectLink}`
        : `${APP_NESTED_PATH}/login?redirectUrl=${history.location.pathname}`;

      history.push(
        // eslint-disable-next-line
        redirectURL,
      );
      window.location.reload();
    } else if (
      response.status &&
      response.status.toString().indexOf('2') !== 0
    ) {
      callUpdateError(updateError, errorTranslationKey);
    }

    const payload = response.json();
    return payload;
  } catch (e) {
    console.info(e);
    callUpdateError(updateError, errorTranslationKey);
    if (throwError) throw e;
  }

  return false;
};

const fetch = fetchWithError();

export default fetch;
