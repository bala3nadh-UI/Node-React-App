import React, {
  useContext,
  createContext,
  ReactNode,
  useState,
  useEffect,
} from 'react';

const CommentsContext = createContext<any>({});

function CommentsProvider(props: { children: ReactNode }) {
  const [comments, setComments] = useState([]);
  const [pageId, setPageId] = useState(null);

  useEffect(() => {
    if (pageId) {
      window.parent.postMessage({ type: 'imAlive', pageId }, '*');
    }
    window.addEventListener('message', e => {
      if (e.data.type === 'commentsFromJB') {
        const commentsForJT = e.data.comments.map((item: any) => ({
          componentId: item.componentId,
          resolved: !!item.resolved,
        }));
        setComments(commentsForJT);
      }
    });
  }, [pageId]);

  return (
    <CommentsContext.Provider
      value={{
        comments,
        setComments,
        pageId,
        setPageId,
      }}
    >
      {props.children}
    </CommentsContext.Provider>
  );
}

const useCommentsContext = () => {
  return useContext(CommentsContext);
};

export { CommentsProvider, useCommentsContext };
