import fetch from './fetch';
/* global GLOBAL_CONTEXT */
const sendErrorLogs = (data: { [name: string]: any }) =>
  fetch('/error-logging', 'POST', { data });

const getServiceById = (id: string) => {
  return fetch(`/pub/service/${id}`);
};

const getServiceByPath = (path: string) => {
  return fetch(`/pub/service/gsp-path/${path}`);
};

const getCmsPage = (pageId?: string, lang?: string) => {
  return fetch(`/api/cms/getCmsPage/${pageId}/${lang}`);
};

const saveDraft = (applicationId: string, id: string, data: any) => {
  return fetch(`/api/draft/save/${applicationId}/${id}`, 'POST', data);
};

const getDraft = (applicationId: string, id: string) => {
  return fetch(`/api/draft/load/${applicationId}/${id}`);
};

const getUserJourneyContext = (
  itemId: string,
  userJourneyId: string,
  isPreview: boolean,
) => {
  const config = {
    headers: {
      userId: '{{user.User Unique Identifier}}',
      isPreview,
    },
  };
  return fetch(
    `/api/proxy/ms-call/${GLOBAL_CONTEXT}/context/${itemId}/${userJourneyId}?data=${JSON.stringify(
      config,
    )}`,
  );
};

export default {
  sendErrorLogs,
  getServiceById,
  getServiceByPath,
  getCmsPage,
  getUserJourneyContext,
  getDraft,
  saveDraft,
};
