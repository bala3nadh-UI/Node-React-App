import React from 'react';
import qs from 'query-string';
import baseUrl from 'client/utils/baseUrl';

const withComposerRedirect = (
  BaseComponent: any,
  type: string = 'services',
) => {
  const Wrapped = (props: any) => {
    const query = qs.parse(props.location.search);
    let { journeyContext } = query;
    if (journeyContext) {
      delete query.journeyContext;
      journeyContext = decodeURIComponent(journeyContext); // decoding the url, may be have ? for preview flag or others
      const journeyContextParsedUrl = qs.parseUrl(journeyContext);
      let newQuery = qs.stringify({
        ...query,
        ...journeyContextParsedUrl.query,
      });

      let newPath = '';
      if (type === 'services') {
        newQuery = `?${newQuery}`;
        newPath =
          baseUrl +
          journeyContextParsedUrl.url +
          props.location.pathname +
          newQuery;
      } else if (type === 'questionnaire' || type === 'simulator') {
        const journeyId = journeyContextParsedUrl.url.split('/')[2];
        const stageId = journeyContextParsedUrl.url.split('/')[3];
        const userJourneyId = journeyContextParsedUrl.url.split('/')[4];
        newQuery = newQuery
          ? `?${newQuery}&journeyId=${journeyId}&stageId=${stageId}`
          : `?journeyId=${journeyId}&stageId=${stageId}`;
        newPath = `${
          baseUrl + props.location.pathname
        }/${userJourneyId}${newQuery}`;
      } else {
        newQuery = `?${newQuery}`;
        newPath =
          baseUrl +
          journeyContextParsedUrl.url +
          props.location.pathname +
          newQuery;
      }
      window.location.replace(newPath);
      return <></>;
    }
    return <BaseComponent {...props} />;
  };

  return Wrapped;
};

export default withComposerRedirect;
