import React from 'react';
import withComposerRedirect from '.';

describe('withComposerRedirect', () => {
  beforeAll(() => {
    Object.defineProperty(window, 'location', {
      value: {
        href: 'http://localhost/a/b',
        origin: 'http://localhost',
        assign: jest.fn(),
        replace: jest.fn(),
      },
      writable: true,
    });
  });
  it('should not redirect to any', () => {
    const component = <>test</>;
    withComposerRedirect(component)({
      location: {
        search: '?test=1',
      },
    });
    expect(window.location.replace).not.toHaveBeenCalled();
  });

  it('should redirect to journey url for services', () => {
    const component = <div>test</div>;
    withComposerRedirect(component)({
      location: {
        search: '?test=1&journeyContext="/j/11/111/333?preview=1"',
      },
    });
    expect(window.location.replace).toHaveBeenCalled();
  });

  it('should redirect to journey url for questionnaire', () => {
    const component = <div>test</div>;
    withComposerRedirect(
      component,
      'questionnaire',
    )({
      location: {
        pathname: '/questionnaire/test-questionnaire',
        search: '?test=1&journeyContext="/j/11/111/333?preview=1"',
      },
    });
    expect(window.location.replace).toHaveBeenCalled();
  });

  it('should redirect to journey url for other', () => {
    const component = <div>test</div>;
    withComposerRedirect(
      component,
      'abcd',
    )({
      location: {
        pathname: '/questionnaire/test-questionnaire',
        search: '?test=1&journeyContext="/j/11/111/333?preview=1"',
      },
    });
    expect(window.location.replace).toHaveBeenCalled();
  });
});
