import React from 'react';
import { mount } from 'enzyme';
import { act } from 'react-dom/test-utils';
import { render } from '@testing-library/react';
import { CmsProvider, useCmsContext, reducer } from './cmsContext';
import fetch from '../fetch';

jest.mock('client/services/fetch');

describe('cmsContext', () => {
  const entityWithCms = {
    id: 'test',
    pageId: 'test',
    cms: {
      pageCmsId: 'test',
      content: {
        test: {
          cmsId: 'test',
        },
      },
    },
  };
  let mockFetch: any;

  beforeAll(() => {
    mockFetch = fetch;
  });

  const entityWithoutCms = {
    id: 'test',
    pageId: 'test',
  };

  describe('mount', () => {
    let state: any;
    let action: any;

    beforeEach(() => {
      state = null;
    });

    it('loads initial state', () => {
      action = { type: 'FETCH_INIT' };

      const initialFetch = reducer(state, action);
      expect(initialFetch).toBeTruthy();
    });

    it('loads success state', () => {
      action = { type: 'FETCH_SUCCESS' };

      const initialFetch = reducer(state, action);
      expect(initialFetch).toBeTruthy();
    });

    it('loads failure state', () => {
      action = { type: 'FETCH_FAILURE' };

      const initialFetch = reducer(state, action);
      expect(initialFetch).toBeTruthy();
    });

    it('loads default state', () => {
      action = { type: '' };

      reducer(state, action);
    });

    it('mounts with no loadFromCms provided', () => {
      const TestComponent = () => {
        const cms = useCmsContext();

        cms.actions.fetchCmsData('test', 'test', 'en').then();
        cms.actions.fetchCmsData('test', 'test', 'ar').then();

        return <div>{JSON.stringify(cms)}</div>;
      };

      mockFetch.mockImplementation(() => {
        return Promise.resolve({
          data: {
            PageContent: [
              {
                ContentJson: {
                  Title: 'test',
                  Description: 'test',
                },
              },
            ],
          },
        });
      });

      act(() => {
        render(
          <CmsProvider
            pages={[entityWithCms, entityWithoutCms]}
            symbols={[entityWithCms, entityWithoutCms]}
          >
            <TestComponent />
          </CmsProvider>,
        );

        expect(mockFetch).toHaveBeenCalledWith('/api/cms/getCmsPage/test/en');
        expect(mockFetch).toHaveBeenCalledWith('/api/cms/getCmsPage/test/ar');
      });
    });

    it('mounts with loadFromCms=false', () => {
      const TestComponent = () => {
        const cms = useCmsContext();

        return <div>{JSON.stringify(cms)}</div>;
      };

      const wrapper = mount(
        <CmsProvider
          pages={[entityWithCms, entityWithoutCms]}
          symbols={[entityWithCms, entityWithoutCms]}
        >
          <TestComponent />
        </CmsProvider>,
      );

      expect(wrapper.exists()).toBeTruthy();
    });

    it('reducer', () => {
      const TestComponent = () => {
        const cms = useCmsContext();

        return <div>{JSON.stringify(cms)}</div>;
      };

      const wrapper = mount(
        <CmsProvider
          pages={[entityWithCms, entityWithoutCms]}
          symbols={[entityWithCms, entityWithoutCms]}
        >
          <TestComponent />
        </CmsProvider>,
      );

      expect(wrapper.exists()).toBeTruthy();
    });
  });
});
