import React, {
  useReducer,
  useContext,
  createContext,
  ReactNode,
  useState,
  useCallback,
} from 'react';
import InternalApi from '../InternalApi';

type IPage = {
  pageId: string;
  cms?: {
    content: any;
    pageCmsId: any;
  };
};

type ISymbol = {
  id: string;
  cms?: {
    content: any;
    pageCmsId: any;
  };
};

export type CmsContextProps = {
  state: any;
  actions: {
    getEntityData(...args: any[]): void;
    fetchCmsData(...args: any[]): Promise<any>;
  };
};

type CmsProviderProps = {
  loadFromCms?: boolean;
  pages: IPage[];
  symbols: ISymbol[];
  children: ReactNode;
};

const CMS_ITEM_KEYS = [
  'locale',
  'aria-label',
  'content',
  'target',
  'text',
  'items',
  'title',
  'subtitle',
  'description',
  'message',
  'label',
  'link',
  'linkTarget',
  'price',
  'currency',
  'helpMessage',
];

export const reducer = (state: any, action: any) => {
  switch (action.type) {
    case 'FETCH_INIT':
      return {
        ...state,
        isLoading: true,
        isError: false,
      };
    case 'FETCH_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        data: action.payload,
      };
    case 'FETCH_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
      };
    default:
      return state;
  }
};

const CmsContext = createContext<CmsContextProps>({
  state: {
    data: [],
    loadFromCms: true,
  },
  onceOnlyData: {},
} as any);

function CmsProvider(props: CmsProviderProps) {
  const [state] = useReducer(reducer, {
    isLoading: false,
    isError: false,
    data: [],
    loadFromCms: props.loadFromCms || true,
  });

  const [cmsData, setCmsData] = useState<Record<string, IPage | ISymbol>>({
    ...props.pages
      .filter(page => !!page.cms)
      .reduce((acc, page) => {
        return {
          ...acc,
          [page.pageId]: page.cms,
        };
      }, {}),
    ...props.symbols
      .filter(symbol => !!symbol.cms)
      .reduce((acc, symbol) => {
        return {
          ...acc,
          [symbol.id]: symbol.cms,
        };
      }, {}),
  });

  const fetchCmsData = useCallback(
    (stateId, cmsId, lang) => {
      return new Promise(resolve => {
        InternalApi.getCmsPage(cmsId, lang).then(resp => {
          const { data } = resp;
          const stateCopy = { ...cmsData };
          if (data) {
            data.PageContent?.forEach((c: any) => {
              // @ts-ignore
              if (!stateCopy[stateId].content[c.ContentJson.Title].values) {
                // @ts-ignore
                stateCopy[stateId].content[c.ContentJson.Title].values = {};
              }
              // @ts-ignore
              stateCopy[stateId].content[c.ContentJson.Title].values[
                lang === 'en' ? 'en' : 'ar'
              ] = c.ContentJson.Description;
            });
          }
          setCmsData(stateCopy);
          resolve(stateCopy);
        });
      });
    },
    [cmsData, setCmsData],
  );

  const getEntityData = useCallback(
    (id: string) => {
      return cmsData[id];
    },
    [cmsData],
  );

  return (
    <CmsContext.Provider
      value={{
        state: {
          ...state,
          cmsData,
          loadFromCms: props.loadFromCms || true,
        },
        actions: {
          getEntityData,
          fetchCmsData,
        },
      }}
    >
      {props.children}
    </CmsContext.Provider>
  );
}

const useCmsContext = () => {
  return useContext(CmsContext);
};

export { CmsProvider, useCmsContext, CMS_ITEM_KEYS };
