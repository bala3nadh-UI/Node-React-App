import React, { useEffect } from 'react';
import DraftService from '.';
import { useComposerServices } from '../ComposerServices';

const withDraft = (BaseComponent: any, isPageBody: boolean = false) => {
  let Wrapped;
  if (isPageBody) {
    Wrapped = (props: any) => {
      const { appId } = props;
      const composerServiceContext = useComposerServices();

      useEffect(() => {
        const draftServiceObject = new DraftService(appId);
        composerServiceContext.actions.setDraftService(draftServiceObject);
      }, [appId]);
      if (!composerServiceContext.state.draftService) return <></>;
      return (
        <BaseComponent
          {...props}
          utils={{
            ...props.utils,
            draft: composerServiceContext.state.draftService,
          }}
        />
      );
    };
  } else {
    Wrapped = (props: any) => {
      const composerServiceContext = useComposerServices();
      return (
        <BaseComponent
          {...props}
          utils={{
            ...props.utils,
            draft: composerServiceContext.state.draftService,
          }}
        />
      );
    };
  }
  return Wrapped;
};

export default withDraft;
