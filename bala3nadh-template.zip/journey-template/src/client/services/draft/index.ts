import internalApi from '../InternalApi';

class Draft {
  applicationId: string;

  constructor(applicationId: string) {
    this.applicationId = applicationId;
  }

  async load(id: string) {
    return internalApi.getDraft(this.applicationId, id);
  }

  async save(id: string, data: any) {
    return internalApi.saveDraft(this.applicationId, id, data);
  }
}

export default Draft;
