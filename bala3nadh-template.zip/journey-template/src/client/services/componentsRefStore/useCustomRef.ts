import { useEffect } from 'react';
import * as componentRefStore from '.';

export type CustomRef = {
  enabled: boolean;
  name: string;
};

const useCustomRef = (customRef: CustomRef, refObject: any) => {
  useEffect(() => {
    if (customRef?.enabled && !componentRefStore.isExist(customRef.name)) {
      componentRefStore.add(customRef.name, refObject);
    }
    return () => {
      componentRefStore.remove(customRef?.name);
    };
  }, [customRef]);
};

export default useCustomRef;
