const componentRefStore: any = {};

export const add = (key: string, value: any) => {
  componentRefStore[key] = value;
};
export const remove = (key: string) => {
  delete componentRefStore[key];
};

export const isExist = (key: string) => !!componentRefStore[key];

export const get = (key: string) => componentRefStore[key];
