/* eslint-disable no-param-reassign */
import { updateFetchStateInterval, IVariables } from '@bala3nadh/app-composer';
import fetch, { ChangeHandler } from 'client/services/fetch';
import { PROCESS_NAME_WORKBENCH } from 'client/_examples/v5/constants';
import { History } from 'history';

const FETCH_STATE_SHORT_INTERVAL = 1000 * 3;

class Bpm {
  processDefinitionId: string;

  processUrlKey: string;

  history?: History;

  constructor(config?: IVariables, history?: History) {
    const options = config || {};

    this.processDefinitionId = options.processDefinitionId;
    this.processUrlKey = options.processUrlKey;

    this.history = history;
  }

  state(name: string, instanceId: string, pub: boolean = false) {
    return fetch(
      `/${pub ? 'pub' : 'api'}/proxy/bpm/${name}/${instanceId}/state`,
    );
  }

  getVariables(
    instanceId: string,
    processState: IVariables,
    pub: boolean = false,
  ) {
    if (!processState.processName) {
      return console.error(
        `Please provide processName in your fromProcessState object instanceId: ${instanceId} processState: ${JSON.stringify(
          processState,
        )} `,
      );
    }

    return fetch(
      `/${pub ? 'pub' : 'api'}/proxy/bpm/${
        processState.processName
      }/${instanceId}/variables`,
      'POST',
      {
        variables: processState.variables,
      },
    );
  }

  start(
    name: string,
    data: object,
    pub: boolean = false,
    errorTranslationKey: string | boolean = true,
    throwError: boolean = true,
    onStateChange: ChangeHandler | boolean = false,
  ) {
    updateFetchStateInterval(FETCH_STATE_SHORT_INTERVAL);
    return fetch(
      `/${pub ? 'pub' : 'api'}/proxy/bpm/${name}/start`,
      'POST',
      data,
      errorTranslationKey,
      throwError,
      onStateChange,
    );
  }

  startProcess(
    data: any = {},
    pub: boolean = false,
    errorTranslationKey: string | boolean = true,
    throwError: boolean = true,
    onStateChange: ChangeHandler | boolean = false,
  ) {
    if (!this.processDefinitionId) {
      throw new Error('Missing process definition id');
    }
    updateFetchStateInterval(FETCH_STATE_SHORT_INTERVAL);
    return fetch(
      `/${pub ? 'pub' : 'api'}/proxy/bpm/${PROCESS_NAME_WORKBENCH}/start/${
        this.processDefinitionId
      }`,
      'POST',
      {
        state: this.history?.location.pathname,
        ...data,
      },
      errorTranslationKey,
      throwError,
      onStateChange,
    );
  }

  startProcessWithValidation(
    data = {},
    pub: boolean = false,
    errorTranslationKey: string | boolean = true,
    throwError: boolean = true,
    onStateChange: ChangeHandler | boolean = false,
  ) {
    if (!this.processDefinitionId) {
      throw new Error('Missing process definition id');
    }

    updateFetchStateInterval(FETCH_STATE_SHORT_INTERVAL);

    return fetch(
      `/${pub ? 'pub' : 'api'}/proxy/${
        this.processUrlKey
      }/bpm/${PROCESS_NAME_WORKBENCH}/start/${this.processDefinitionId}`,
      'POST',
      {
        ...data,
        processDefinitionId: this.processDefinitionId,
        state: this.history?.location.pathname,
      },
      errorTranslationKey,
      throwError,
      onStateChange,
    );
  }

  message(
    name: string,
    data: object,
    pub: boolean = false,
    errorTranslationKey: string | boolean = true,
    throwError: boolean = true,
    onStateChange: ChangeHandler | boolean = false,
  ) {
    updateFetchStateInterval(FETCH_STATE_SHORT_INTERVAL);
    return fetch(
      `/${pub ? 'pub' : 'api'}/proxy/bpm/${name}/message`,
      'POST',
      data,
      errorTranslationKey,
      throwError,
      onStateChange,
    );
  }

  sendMessage(
    data: object,
    pub: boolean = false,
    errorTranslationKey: string | boolean = true,
    throwError: boolean = true,
    onStateChange: ChangeHandler | boolean = false,
  ) {
    updateFetchStateInterval(FETCH_STATE_SHORT_INTERVAL);
    return fetch(
      `/${pub ? 'pub' : 'api'}/proxy/bpm/${PROCESS_NAME_WORKBENCH}/message/${
        this.processDefinitionId
      }`,
      'POST',
      data,
      errorTranslationKey,
      throwError,
      onStateChange,
    );
  }

  redirectTo(
    name: string,
    data: object,
    pub: boolean = false,
    errorTranslationKey: string | boolean = true,
    throwError: boolean = true,
    onStateChange: ChangeHandler | boolean = false,
  ) {
    updateFetchStateInterval(FETCH_STATE_SHORT_INTERVAL);
    return fetch(
      `/${pub ? 'pub' : 'api'}/proxy/bpm/${name}/redirect`,
      'POST',
      data,
      errorTranslationKey,
      throwError,
      onStateChange,
    );
  }

  sendRedirectTo(
    instanceId: string,
    data: object,
    pub: boolean = false,
    errorTranslationKey: string | boolean = true,
    throwError: boolean = true,
    onStateChange: ChangeHandler | boolean = false,
  ) {
    updateFetchStateInterval(FETCH_STATE_SHORT_INTERVAL);

    return fetch(
      `/${
        pub ? 'pub' : 'api'
      }/proxy/bpm/${PROCESS_NAME_WORKBENCH}/${instanceId}/redirect`,
      'POST',
      data,
      errorTranslationKey,
      throwError,
      onStateChange,
    );
  }
}

export { Bpm as BpmClient };

export default new Bpm({});
