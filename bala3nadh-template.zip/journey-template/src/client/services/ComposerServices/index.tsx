import React, { useContext, createContext, useState } from 'react';

const ComposerServicesContext = createContext<any>({
  state: {},
  actions: {},
});

function ComposerServicesProvider(props: any) {
  const [journeyService, setJourneyService] = useState();
  const [draftService, setDraftService] = useState();

  return (
    <ComposerServicesContext.Provider
      value={{
        state: {
          journeyService,
          draftService,
        },
        actions: {
          setJourneyService,
          setDraftService,
        },
      }}
    >
      {props.children}
    </ComposerServicesContext.Provider>
  );
}

const useComposerServices = () => {
  return useContext(ComposerServicesContext);
};

export { ComposerServicesProvider, useComposerServices };
