import fetch from 'client/services/fetch';
import bpm, { BpmClient } from 'client/services/bpm';

jest.mock('client/services/fetch');

jest.mock('client/utils/appData', () => ({
  getCMSData: jest.fn(() => {
    return {
      navigationItems: {
        en: [],
        ar: [],
      },
    };
  }),
  getSmartpassData: jest.fn(),
  getMetaData: jest.fn(),
  getJourneyContext: jest.fn(),
}));

describe('services/bpm', () => {
  let mockFetch: any;
  let mockHistory: any;

  beforeAll(() => {
    mockFetch = fetch;
    mockHistory = {
      location: {
        pathname: '/pathname',
      },
    };
  });

  it('should call state with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.state('licence', 'instance_id');

    expect(mockFetch).toHaveBeenCalledWith(
      `/api/proxy/bpm/licence/instance_id/state`,
    );
  });

  it('should call state pub with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.state('licence', 'instance_id', true);

    expect(mockFetch).toHaveBeenCalledWith(
      `/pub/proxy/bpm/licence/instance_id/state`,
    );
  });

  it('should call start with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.start('licence', {
      key: 'value',
    });

    expect(mockFetch).toHaveBeenCalledWith(
      `/api/proxy/bpm/licence/start`,
      'POST',
      {
        key: 'value',
      },
      true,
      true,
      false,
    );
  });

  it('should call start pub with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.start(
      'licence',
      {
        key: 'value',
      },
      true,
      true,
      true,
      false,
    );

    expect(mockFetch).toHaveBeenCalledWith(
      `/pub/proxy/bpm/licence/start`,
      'POST',
      {
        key: 'value',
      },
      true,
      true,
      false,
    );
  });

  it('should call startProcess pub with correct params', async () => {
    const bpmClient = new BpmClient(
      {
        processDefinitionId: 'processDefinitionId',
      },
      mockHistory,
    );

    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpmClient.startProcess(
      {
        key: 'value',
      },
      true,
    );

    expect(mockFetch).toHaveBeenCalledWith(
      `/pub/proxy/bpm/workbench/start/processDefinitionId`,
      'POST',
      {
        key: 'value',
        state: '/pathname',
      },
      true,
      true,
      false,
    );
  });

  it('should call startProcessWithValidation without params', async () => {
    const bpmClient = new BpmClient(
      {
        processDefinitionId: 'processDefinitionId',
      },
      mockHistory,
    );

    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpmClient.startProcessWithValidation(
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
    );
  });

  it('should call startProcess api with correct params', async () => {
    const bpmClient = new BpmClient(
      {
        processDefinitionId: 'processDefinitionId',
      },
      mockHistory,
    );

    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpmClient.startProcess();

    expect(mockFetch).toHaveBeenCalledWith(
      `/api/proxy/bpm/workbench/start/processDefinitionId`,
      'POST',
      {
        state: '/pathname',
      },
      true,
      true,
      false,
    );
  });

  it('should call startProcess with correct params when history is missing', async () => {
    const bpmClient = new BpmClient({
      processDefinitionId: 'processDefinitionId',
    });

    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpmClient.startProcess();

    expect(mockFetch).toHaveBeenCalledWith(
      `/api/proxy/bpm/workbench/start/processDefinitionId`,
      'POST',
      {
        state: undefined,
      },
      true,
      true,
      false,
    );
  });

  it('should throw error startProcess when processDefinitionId is missing', async () => {
    expect.assertions(1);

    try {
      const bpmClient = new BpmClient();

      await bpmClient.startProcess();
    } catch (e) {
      expect(e.message).toBe('Missing process definition id');
    }
  });

  it('should call message with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.message('licence', {
      key: 'value',
    });

    expect(mockFetch).toHaveBeenCalledWith(
      `/api/proxy/bpm/licence/message`,
      'POST',
      {
        key: 'value',
      },
      true,
      true,
      false,
    );
  });

  it('should call sendMessage with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.sendMessage(
      { data: 'data' },
      undefined,
      undefined,
      undefined,
      undefined,
    );
  });

  it('should call message pub with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.message(
      'licence',
      {
        key: 'value',
      },
      true,
    );

    expect(mockFetch).toHaveBeenCalledWith(
      `/pub/proxy/bpm/licence/message`,
      'POST',
      {
        key: 'value',
      },
      true,
      true,
      false,
    );
  });

  it('should call redirectTo with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.redirectTo('licence', {
      key: 'value',
    });

    expect(mockFetch).toHaveBeenCalledWith(
      `/api/proxy/bpm/licence/redirect`,
      'POST',
      {
        key: 'value',
      },
      true,
      true,
      false,
    );
  });

  it('should call redirectTo pub with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.redirectTo(
      'licence',
      {
        key: 'value',
      },
      true,
    );

    expect(mockFetch).toHaveBeenCalledWith(
      `/pub/proxy/bpm/licence/redirect`,
      'POST',
      {
        key: 'value',
      },
      true,
      true,
      false,
    );
  });

  it('should call getVariables with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.getVariables('1111', {
      processName: 'licence',
      variables: {
        key: 'value',
      },
    });

    expect(mockFetch).toHaveBeenCalledWith(
      `/api/proxy/bpm/licence/1111/variables`,
      'POST',
      {
        variables: {
          key: 'value',
        },
      },
    );

    await bpm.getVariables(
      '1111',
      {
        processName: 'licence',
        variables: {
          key: 'value',
        },
      },
      true,
    );

    expect(mockFetch).toHaveBeenCalledWith(
      `/pub/proxy/bpm/licence/1111/variables`,
      'POST',
      {
        variables: {
          key: 'value',
        },
      },
    );

    bpm.getVariables(
      '1111',
      {
        variables: {
          key: 'value',
        },
      },
      true,
    );
  });

  it('should call sendRedirectTo with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.sendRedirectTo('instanceId', {
      key: 'value',
    });

    expect(mockFetch).toHaveBeenCalledWith(
      `/api/proxy/bpm/workbench/instanceId/redirect`,
      'POST',
      {
        key: 'value',
      },
      true,
      true,
      false,
    );
  });

  it('should call sendRedirectTo pub with correct params', async () => {
    mockFetch.mockImplementation(() => {
      return Promise.resolve({
        json: () => {
          return Promise.resolve({
            message: 'ok',
          });
        },
      });
    });

    await bpm.sendRedirectTo(
      'instanceId',
      {
        key: 'value',
      },
      true,
    );

    expect(mockFetch).toHaveBeenCalledWith(
      `/pub/proxy/bpm/workbench/instanceId/redirect`,
      'POST',
      {
        key: 'value',
      },
      true,
      true,
      false,
    );
  });
});
