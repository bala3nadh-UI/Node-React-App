/* eslint-disable complexity */
/* eslint-disable no-restricted-globals */
import { IVariables } from '@bala3nadh/app-composer';
import { getValueByCode } from '@bala3nadh/oop/client';
import {
  includes,
  isString,
  isDate,
  isArray,
  isObjectLike,
  isFunction,
  noop,
} from 'lodash';
import get from 'client/utils/workbench/get';
import deepMap from 'client/utils/workbench/deepMap';
import { CMS_ITEM_KEYS } from 'client/services/cms/cmsContext';

const regexSharedFunction = /callShared\('([a-zA-Z_\-$][0-9a-zA-Z_|\-$.]*)'\)/i;
const regexOnceOnly = /onceOnly\('([a-zA-Z_\-$][0-9a-zA-Z_\-$.]*)'\)/i;
const regexOnlyZeroInDecimal = /^(?!00)\d+\.0{1,}$/g;
export const regexState = /\${([a-zA-Z_$][0-9a-zA-Z_$.]*)}/g;

export function JSONSafeParse(json: any) {
  let parsed;

  try {
    parsed = JSON.parse(json);
  } catch (e) {
    parsed = json;
  }

  return parsed;
}

const IGNORED_FUNCTIONS = [
  'visible',
  'btnSubmitClick',
  'btnCancelClick',
  'btnBackClick',
  'btnSubmitDisabled',
  'isRequiredFunc',
  'isVisibleFunc',
  'isDisabledFunc',
  'isValidFunc',
  'btnBackVisibleFunc',
];

const isIgnoredFunction = (name: string) =>
  IGNORED_FUNCTIONS.some(item => name.includes(item));

const formatSharedFunctions = (result: any, props: IVariables) => {
  return deepMap(result, (item: any, _: string, itemParent: any) => {
    if (isString(item) && item.match(regexSharedFunction)) {
      const [, funcMatch]: any = item.match(regexSharedFunction);
      const [funcName, funcParams] = funcMatch.split('|');

      if (funcParams) {
        const func = get(props, `sharedFunctions.${funcName}`, noop).bind(
          null,
          get(itemParent, funcParams),
        );
        func.wbFuncName = funcName;
        return func;
      }
      return get(props, `sharedFunctions.${funcName}`, noop);
    }

    return item;
  });
};

const formatState = (
  definitions: IVariables[],
  props: IVariables,
  cmsPageData?: any,
) => {
  /**
   * Replace with state values
   */
  const stateFull = deepMap(definitions, (baseValue: any, key: string) => {
    let value = baseValue;

    if (
      includes(CMS_ITEM_KEYS, key) &&
      cmsPageData &&
      cmsPageData.content[value] &&
      cmsPageData.content[value].values
    ) {
      value = cmsPageData.content[value].values[props.locale];
    }

    if (isString(value)) {
      let parseDate = false;
      let result: any = value.replace(
        regexState,
        (matchedText: string, k: string): any => {
          const stateValue = get(props, `${k.replace('state.', '')}`);

          if (isDate(stateValue)) {
            parseDate = true;
            return stateValue;
          }
          // @ts-ignore
          if (typeof stateValue === 'string' && isNaN(stateValue)) {
            return stateValue;
          }
          return JSON.stringify(stateValue);
        },
      );

      if (parseDate) {
        return new Date(result);
      }

      /**
       * Handle once Only
       */
      if (value.match(regexOnceOnly)) {
        return value.replace(
          regexOnceOnly,
          (matchedText: string, match: string) =>
            getValueByCode(match, props.onceOnly, props.locale),
        );
      }

      if (value.match(regexOnlyZeroInDecimal)) {
        return value;
      }

      result = JSONSafeParse(result);

      // if (typeof result === 'number') {
      //   result = String(result);
      // }

      /**
       * Replace callShared with real functions
       */
      if (isArray(result) || isObjectLike(result)) {
        return formatSharedFunctions(result, props);
      }

      return result;
    }

    return value;
  });

  /**
   * Add props into functions
   */
  return deepMap(stateFull, (value: any) => {
    if (isFunction(value)) {
      const funcName = value.name || (value as any).wbFuncName || '';
      if (!isIgnoredFunction(funcName) && funcName.length > 0) {
        if (funcName.includes('call_')) {
          return value(props);
        }
        return () => {
          value(props);
        };
      }
    }
    return value;
  });
};

export default formatState;
