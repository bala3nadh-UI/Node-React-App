/* eslint-disable no-restricted-globals */
import {
  has,
  isString,
  isObjectLike,
  isFunction,
  isEmpty,
  isDate,
} from 'lodash';
import { IVariables } from '@bala3nadh/app-composer';
import baseUrl from 'client/utils/baseUrl';
import deepMap from 'client/utils/workbench/deepMap';
import get from './get';

const regexI18n = /i18n\('([a-zA-Z_\-$][0-9a-zA-Z_\-$.]*)'\)/g;
const regexParentProps = /{{parentProps\((\d),(.*)\)}}/g;
const regexSymbolProps = /symbolProps\('([a-zA-Z_\-$][0-9a-zA-Z_\-$.]*)'\)/i;

function JSONSafeParse(json: any) {
  let parsed;

  try {
    parsed = JSON.parse(json);
  } catch (e) {
    parsed = json;
  }

  return parsed;
}

const getImageProps = (passedProps: IVariables) => {
  const tempProps = { ...passedProps };

  Object.keys(tempProps).forEach((key: any) => {
    const prop = tempProps[key];
    if (
      isObjectLike(prop) &&
      has(prop, 'type') &&
      has(prop, 'fileId') &&
      prop.type === 'file/image'
    ) {
      tempProps[key] = `${baseUrl}/api/file/${prop.fileId}`;
    }
  });

  return tempProps;
};

const getDateProps = (passedProps: IVariables, definitionType: string) => {
  const tempProps = { ...passedProps };
  if (definitionType === 'datePicker') {
    Object.keys(tempProps).forEach((key: any) => {
      const prop = tempProps[key];
      if (
        key === 'value' ||
        key === 'defaultValue' ||
        key === 'min' ||
        key === 'max'
      ) {
        if (prop && Date.parse(prop)) tempProps[key] = new Date(prop);
        else tempProps[key] = null;
      }
    });
  }
  return tempProps;
};

const SKIP_DATE_CONVERSION_COMPONENTS = ['newsListingItem', 'table', 'table2'];

const getCustomComponentProps = (
  props: any,
  definitionProps: IVariables,
  definitionType: string,
) => {
  const getParentProps = (parentDepth: string = '1') => {
    let parsedDepth = parseInt(parentDepth, 10);
    let parentProps = props.getParentProps();
    parsedDepth -= 1;
    while (parentProps.getParentProps && parsedDepth > -1) {
      parsedDepth -= 1;
      parentProps = parentProps.getParentProps();
    }
    if (!parentProps) console.error(`No parent at ${parentDepth} level`);
    return parentProps;
  };
  const additionalProps = {
    getParentProps,
  };
  // eslint-disable-next-line complexity
  const componentProps = deepMap(definitionProps, (value: any, key: string) => {
    if (isString(value) && value.match(regexI18n)) {
      return value.replace(
        regexI18n,
        (matched, k) => props.i18n && props.i18n(k),
      );
    }

    if (isString(value) && value.match(regexParentProps)) {
      let parseDate = false;
      const result: any = value.replace(
        regexParentProps,
        (matched, parentDepth, varPath): any => {
          const parentProps = getParentProps(parentDepth);
          const propsValue = get(parentProps || {}, varPath, matched);
          if (isDate(propsValue)) {
            parseDate = true;
            return propsValue;
          }
          // @ts-ignore
          if (typeof propsValue === 'string' && isNaN(propsValue)) {
            return propsValue;
          }
          return JSON.stringify(propsValue);
        },
      );
      if (parseDate) {
        return new Date(result);
      }
      return JSONSafeParse(result);
    }

    if (
      !isEmpty(definitionProps.symbolProps) &&
      isString(value) &&
      value.match(regexSymbolProps)
    ) {
      const [, path] = value.match(regexSymbolProps) || [];
      const symbolPropsValue = get(definitionProps.symbolProps, path, path);
      if (
        isString(path) &&
        path.toLowerCase().indexOf('date') >= 0 &&
        Date.parse(symbolPropsValue) &&
        !SKIP_DATE_CONVERSION_COMPONENTS.includes(definitionType)
      )
        return new Date(symbolPropsValue);
      return symbolPropsValue;
    }

    if (
      isString(key) &&
      key.toLowerCase().indexOf('date') >= 0 &&
      Date.parse(value) &&
      !SKIP_DATE_CONVERSION_COMPONENTS.includes(definitionType)
    ) {
      return new Date(value);
    }

    if (definitionProps.symbolProps && isFunction(value)) {
      if (definitionProps.nestedSymbolProps?.length > 1) {
        // support old compatibility as we were supporting just two level of symbols
        const symbolsProps = definitionProps.nestedSymbolProps.slice(0, 2);
        return (...args: any[]) =>
          value(...symbolsProps, ...args, additionalProps);
        //
      }
      return (...args: any[]) =>
        value(definitionProps.symbolProps, ...args, additionalProps);
      // value.bind(obj, definitionProps.symbolProps);
    }
    if (isFunction(value)) {
      return (...args: any[]) => value(...args, additionalProps);
    }

    return value;
  });
  return getImageProps(getDateProps(componentProps, definitionType));
};

export { getCustomComponentProps };
