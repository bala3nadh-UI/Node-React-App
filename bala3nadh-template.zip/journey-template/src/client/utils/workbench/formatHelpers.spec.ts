import { IVariables } from '@bala3nadh/app-composer';
import { getCustomComponentProps } from './formatHelpers';

describe('client/utils/workbench/formatHelpers', () => {
  describe('getCustomComponentProps', () => {
    let definitionProps: any;
    let definitionType: string;

    it('is function', () =>
      expect(getCustomComponentProps).toBeInstanceOf(Function));

    it('should format', () => {
      definitionType = 'image';
      definitionProps = {
        symbolProps: {},
        localizedString: "Localized string: i18n('test')",
        onClick: (p: any) => {
          console.info('props', p);
        },
        call_onClick: (p: any) => {
          return () => {
            console.info('props', p);
          };
        },
        image: {
          type: 'file/image',
          fileId: 'fileId',
        },
      };
      const componentProps: IVariables = getCustomComponentProps(
        { i18n: jest.fn(i => i) },
        definitionProps,
        definitionType,
      );

      expect(componentProps.localizedString).toEqual('Localized string: test');
      expect(componentProps.image).toEqual('/api/file/fileId');
    });

    it('should format datepicker with proper props', () => {
      definitionType = 'datePicker';
      definitionProps = {
        value: '2020-01-15',
        defaultValue: '2020-01-25',
        min: '2020-01-01',
        max: '2020-01-30',
      };
      const componentProps: IVariables = getCustomComponentProps(
        jest.fn(i => i),
        definitionProps,
        definitionType,
      );
      expect(componentProps.value).toEqual(new Date('2020-01-15'));
      expect(componentProps.defaultValue).toEqual(new Date('2020-01-25'));
      expect(componentProps.min).toEqual(new Date('2020-01-01'));
      expect(componentProps.max).toEqual(new Date('2020-01-30'));
    });

    it('should format with symbolprops', () => {
      definitionType = 'image';
      definitionProps = {
        symbolProps: { test: 'test' },
        localizedString: "Localized string: i18n('test')",
        onClick: (p: any) => {
          console.info('props', p);
        },
        call_onClick: (p: any) => {
          return () => {
            console.info('props', p);
          };
        },
        image: {
          type: 'file/image',
          fileId: 'fileId',
        },
      };
      const componentProps: IVariables = getCustomComponentProps(
        { i18n: jest.fn(i => i) },
        definitionProps,
        definitionType,
      );

      expect(componentProps.localizedString).toEqual('Localized string: test');
      expect(componentProps.image).toEqual('/api/file/fileId');
    });
  });
});
