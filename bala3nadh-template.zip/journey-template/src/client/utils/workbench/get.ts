import { noop } from 'lodash';

function get(obj: any, path: string, defaultValue?: any) {
  const travel = (regexp: RegExp) =>
    String.prototype.split
      .call(path, regexp)
      .filter(Boolean)
      .reduce(
        (res, key) => (res !== null && res !== undefined ? res[key] : res),
        obj,
      );
  const result = travel(/[,[\]]+?/) || travel(/[,[\].]+?/);
  if (result === undefined || result === obj) {
    if (defaultValue === noop)
      console.error('ERROR: Cannot find the function', path);
    return defaultValue;
  }

  return result;
}

export default get;
