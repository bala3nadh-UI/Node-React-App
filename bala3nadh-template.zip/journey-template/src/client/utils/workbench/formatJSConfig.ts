import { IVariables } from '@bala3nadh/app-composer';

// eslint-disable-next-line complexity
const formatJSConfig = (
  config: IVariables,
  defaultConfig?: IVariables,
  translations?: IVariables,
) => {
  const data: any = config || {};
  const { pages = [], version, dictionary } = data;

  const newConfig = {
    ...(defaultConfig || {}),
    ...data,

    version: version || Math.round(Math.random() * 100000),
  };
  const getCompiledSymbol = (targetSymbol: any) => {
    if (typeof targetSymbol === 'string') {
      return newConfig.symbols.find(
        (symbol: any) => symbol.id === targetSymbol,
      );
    }
    return newConfig.symbols.find(
      (symbol: any) => symbol.id === targetSymbol.id,
    );
  };
  if (
    newConfig.header &&
    newConfig.header.props &&
    Object.prototype.hasOwnProperty.call(newConfig, 'hero')
  ) {
    if (newConfig.hero !== false) {
      let sharedFunctions: any = {};
      const hero = newConfig.hero[0];
      const heroSymbol = newConfig.symbols.find(
        (symbol: any) => symbol.id === hero.props.symbol,
      ); // eslint-disable-next-line array-callback-return
      (newConfig.pages || []).map((page: any) => {
        if (page.props?.sharedFunctions)
          sharedFunctions = {
            ...sharedFunctions,
            ...page.props.sharedFunctions,
          };
      });
      newConfig.header.props.hero = heroSymbol.definitions;
      newConfig.header.props.sharedFunctions = sharedFunctions;
      newConfig.header.state = {
        mapState: [
          ...(hero?.state?.mapState || []),
          'user',
          'locale',
          'title',
          'breadcrumbs',
        ],
        mapDispatch: [
          ...(newConfig.hero[0]?.state?.mapDispatch || []),
          'user',
          'locale',
        ],
      };
      newConfig.header.props.getSymbolById = (id: string) =>
        newConfig.symbols.find((i: any) => i.id === id);
      delete newConfig.hero;
    } else {
      newConfig.header.props.hero = false;
    }
  }

  let newPages = [...pages];

  if (
    Object.prototype.hasOwnProperty.call(newConfig, 'sidebar') &&
    newConfig.sidebar !== false
  ) {
    newConfig.sidebar = newConfig.sidebar.map((el: any) => ({
      ...el,
      layout: 'sidebar',
    }));
    newPages = newPages.map((page: any) => ({
      ...page,
      props: {
        ...page.props,
        definitions: [...(page.props.definitions || []), ...newConfig.sidebar],
      },
      // eslint-disable-next-line no-nested-ternary
      layout: page.layout
        ? page.layout
        : !newConfig.sidebarLeft
        ? 'sidebar'
        : 'sidebarLeft',
    }));
  }

  newPages = newPages.map((page: any) => ({
    ...page,
    props: {
      ...page.props,
      symbols: page.props.symbols?.map(getCompiledSymbol),
    },
  }));
  return {
    config: { ...newConfig, pages: newPages },
    translations: {
      en: { ...translations?.en, ...dictionary?.en },
      ar: { ...translations?.ar, ...dictionary?.ar },
    },
  };
};

export default formatJSConfig;
