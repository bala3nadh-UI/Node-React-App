import { IVariables } from '@bala3nadh/app-composer';

const mapServiceData = (service: IVariables, i18n: any): IVariables => {
  const serviceData = service.serviceCodeData;

  const heroContent = {
    title: serviceData.Mainservice,
  };

  const baseContent = {
    title: serviceData.Name,
    description: serviceData.Description,
    process: {
      steps: serviceData.ProcessSteps.Collection.map((i: IVariables) => ({
        description: i.Value || '',
        label: i.Title,
      })),
      title: i18n('process'),
    },
    tables: [
      {
        columns: [
          {
            id: 'document',
            title: 'Document',
          },
          {
            align: 'end',
            id: 'description',
            title: 'Description',
          },
        ],
        items: serviceData.Documents.Collection.map(
          (i: IVariables, k: number) => ({
            description: i.SpecialConsideration,
            document: i.Name,
            id: k + 1,
          }),
        ),
        title: i18n('requiredDocuments'),
      },

      ...serviceData.FeesGroups.Collection.map((feeGroup: IVariables) => ({
        columns: [
          {
            id: 'title',
            title: 'Title',
          },
          {
            align: 'end',
            id: 'amount',
            title: 'Amount',
          },
        ],
        items: feeGroup.feesItems.map((i: IVariables, k: number) => ({
          title: i.feesTitle,
          amount: `${i.feesCurrency} ${i.feesValue}`,
          id: k + 1,
        })),
        title: feeGroup.groupName,
      })),
    ],
  };

  const logoId = serviceData.ServicesEntities.ServiceEntity.Logo.match(
    /[A-Z|0-9|-]+/g,
  )[0];

  const baseWorkingTime = {
    label: serviceData.ServicesEntities.ServiceEntity.OfficeHours.match(
      /: .+[,|،]?/g,
    )[0]
      .replace(': ', '')
      .replace(',', '')
      .replace('،', ''),
    start: serviceData.ServicesEntities.ServiceEntity.OfficeHours.match(
      /[0-9]{2}:[0-9]{2}/g,
    )[0],
    end: serviceData.ServicesEntities.ServiceEntity.OfficeHours.match(
      /[0-9]{2}:[0-9]{2}/g,
    )[1],
    closed: false,
  };

  return {
    hero: heroContent,
    base: baseContent,
    sidebar: {
      label: '',
      relevantEntityLink: null,
      lists: [],
      relatedJourney: null,
      relevantEntity: {
        entities: [
          {
            id: 1,
            logo: `https://www.bala3nadh.abudhabi/-/media/${logoId.replace(
              /-/g,
              '',
            )}.ashx`,
            phones: [serviceData.ServicesEntities.ServiceEntity.Phone],
            email: serviceData.ServicesEntities.ServiceEntity.Email,
            address: serviceData.ServicesEntities.ServiceEntity.Address,
            officeHours: {
              status: 'default',
              workingHours: {
                sunday: {
                  ...baseWorkingTime,
                },
                monday: {
                  ...baseWorkingTime,
                },
                tuesday: {
                  ...baseWorkingTime,
                },
                wednesday: {
                  ...baseWorkingTime,
                },
                thursday: {
                  ...baseWorkingTime,
                },
                friday: {
                  closed: true,
                },
                saturday: {
                  closed: true,
                },
              },
            },
            publicServiceHours: { status: '24/7' },
            subTitle: '',
            verticalLogo: false,
            website: serviceData.ServicesEntities.ServiceEntity.Url,
          },
        ],
        title: serviceData.ServicesEntities.ServiceEntity.Name,
      },
      relevantEntitiyLink: {
        label: '',
      },
    },
  };
};

export { mapServiceData };
