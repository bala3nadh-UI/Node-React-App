import BaseLayout from '@bala3nadh/ui-lib-v2-base-layout';
import SidebarLayout from '@bala3nadh/ui-lib-v2-sidebar-layout';
import journeyDashboardLayout from 'client/components/workbench/main/layout/JourneyDashboardLayout';
import { IVariables } from '@bala3nadh/app-composer';

const dlsLayouts: IVariables = {
  base: BaseLayout,
  sidebar: SidebarLayout,
  sidebarLeft: SidebarLayout,
  journeyDashboard: journeyDashboardLayout,
};

export { dlsLayouts };
