import formatState from './formatState';

describe('formatState', () => {
  let props: any;
  // let definitions: any;
  let mockDefinitions: any;

  const mockDateExample = new Date();

  beforeEach(() => {
    props = {
      locale: 'en',
      testKey: 'Test Value',
      dob: mockDateExample,
      items: [
        {
          id: 1,
          label: 'Item 1',
          onChange: `callShared('helpers.call_onChange|id')`,
          onSelect: `callShared('helpers.call_onSelect')`,
        },
      ],
      sharedFunctions: {
        helpers: {
          call_onChange: jest.fn(),
          call_onSelect: jest.fn(),
        },
      },
      onceOnly: {
        name: 'John',
        surname: {
          en: 'Doe',
          ar: 'Doe ar',
        },
      },
    };

    mockDefinitions = [
      /**
       * Test simple state
       */
      {
        componentId: 'componentId1',
        type: 'text',
        props: {
          variant: 'h1',
          // eslint-disable-next-line no-template-curly-in-string
          content: '${testKey}',
        },
      },
      /**
       * Test form functions
       */
      {
        componentId: 'componentId2',
        type: 'form',
        props: {
          btnBackVisibleFunc: () => true,
          btnSubmitClick: () => {},
        },
      },
      /**
       * Test date in state
       */
      {
        componentId: 'componentId3',
        type: 'text',
        props: {
          variant: 'h1',
          // eslint-disable-next-line no-template-curly-in-string
          content: '${dob}',
        },
      },
      /**
       * Test callShared
       */
      {
        componentId: 'componentId4',
        type: 'text',
        props: {
          variant: 'h1',
          // eslint-disable-next-line no-template-curly-in-string
          content: '${items}',
        },
      },
      /**
       * Test callShared
       */
      {
        componentId: 'componentId4',
        type: 'text',
        props: {
          variant: 'h1',
          // eslint-disable-next-line no-template-curly-in-string
          content: "onceOnly('name')",
          text: "onceOnly('surname')",
        },
      },
      {
        componentId: 'componentId5',
        type: 'text',
        props: {
          variant: 'h1',
          content: '4000.00',
        },
      },
    ];
  });

  it('is function', () => expect(formatState).toBeInstanceOf(Function));

  it('should success', () => {
    const definitions = formatState(mockDefinitions, props);

    expect(definitions[0].props.content).toEqual(props.testKey);
    expect(definitions[2].props.content.toString()).toEqual(
      props.dob.toString(),
    );

    expect(definitions[4].props.content).toEqual('undefined');
    expect(definitions[4].props.text).toEqual('undefined');
  });
});
