import baseUrl from 'client/utils/baseUrl';

describe('baseUrl', () => {
  it('is empty string', () => expect(baseUrl).toBe(''));
});
