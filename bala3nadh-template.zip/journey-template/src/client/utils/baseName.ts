import baseUrl from 'client/utils/baseUrl';

let baseName = baseUrl;

/**
 * Get N-th occurrence position within string
 * @param  {string} string
 * @param  {string} subString
 * @param  {number} index
 * @returns {number}
 */
export function getPosition(string: string, subString: string, index: number) {
  return string.split(subString, index).join(subString).length;
}

export function Init() {
  const matched = window.location.pathname.match(/.*\/v\d\/\w*/g);
  if (matched) baseName = matched[0];
}

Init();
const base = baseName;
export default base;
