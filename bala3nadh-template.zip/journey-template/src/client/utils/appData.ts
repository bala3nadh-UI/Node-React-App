import cookie from 'react-cookies';
import window from 'client/utils/window';

type DataValue = {
  smartpassData?: any;
  demoLogin?: any;
  cms?: any;
  meta?: any;
  featureFlags?: string;
  user?: any;
  journeyData?: any;
  camunda?: any;
};

export const getData = () => {
  let dataValue: DataValue = {};

  try {
    const staticData = document.querySelector('script#staticData[type=json]');
    if (window && staticData) {
      dataValue = JSON.parse(staticData.innerHTML);
    }
  } catch (e) {
    console.error('Error on fetching App data', e);
  }
  return dataValue;
};

const data = getData();

export const isLoggedIn = (): boolean =>
  !!data.smartpassData && Object.keys(data.smartpassData).length > 0;

export const getSmartpassData = (): any => data.smartpassData;
export const getJourneyData = (): any => data.journeyData || {};

export const isDemoLoggedIn = (): boolean => data.demoLogin;

export const getCMSData = (): any => data.cms;

export const getMetaData = (): any => data.meta;

export const getCamundaData = (): any => data.camunda;

export const getLogUuid = (): string => cookie.load('logUuid') || '';

const saveNationality = () => {
  if (isLoggedIn() && data.smartpassData['Nationality EN']) {
    cookie.save('C_Nationality', data.smartpassData['Nationality EN'], {
      path: '/',
    });
  } else {
    cookie.remove('C_Nationality', {
      path: '/',
    });
  }
};

saveNationality();

export default data;
