import history from 'client/utils/history';

describe('history', () => {
  it('is an object', () => expect(history).toBeInstanceOf(Object));
});
