import React, { Suspense } from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import App, {
  ComposerExported,
  ComposerV5Preview,
  ComposerLicensePOC,
  ComposerCustomContent,
  ComposerDashboard,
  ComposerExportedBundle,
} from './App';

jest.mock('client/utils/appData', () => ({
  getCMSData: jest.fn(() => {
    return {
      navigationItems: {
        en: [],
        ar: [],
      },
    };
  }),
  getSmartpassData: jest.fn(),
  getMetaData: jest.fn(),
}));

describe('<App />', () => {
  it('renders', () => {
    const wrapper = shallow(<App />);
    expect(wrapper.exists()).toBeTruthy();
  });

  it('renders ComposerExported', () => {
    render(
      <MemoryRouter>
        <Suspense fallback={<div />}>
          <ComposerExported />
        </Suspense>
      </MemoryRouter>,
    );
  });

  it('renders ComposerV5Preview', () => {
    render(
      <MemoryRouter>
        <Suspense fallback={<div />}>
          <ComposerV5Preview />
        </Suspense>
      </MemoryRouter>,
    );
  });

  it('renders ComposerLicensePOC', () => {
    render(
      <MemoryRouter>
        <Suspense fallback={<div />}>
          <ComposerLicensePOC />
        </Suspense>
      </MemoryRouter>,
    );
  });

  it('renders ComposerCustomContent', () => {
    render(
      <MemoryRouter>
        <Suspense fallback={<div />}>
          <ComposerCustomContent />
        </Suspense>
      </MemoryRouter>,
    );
  });

  it('renders ComposerDashboard', () => {
    render(
      <MemoryRouter>
        <Suspense fallback={<div />}>
          <ComposerDashboard />
        </Suspense>
      </MemoryRouter>,
    );
  });

  it('renders ComposerExportedBundle', () => {
    render(
      <MemoryRouter>
        <Suspense fallback={<div />}>
          <ComposerExportedBundle />
        </Suspense>
      </MemoryRouter>,
    );
  });
});
