import React from 'react';
import { mount } from 'enzyme';

import Html from 'server/Html';

const requireProps = {
  title: 'some title',
  description: 'some description',
  app: {},
  url: 'some url',
  styles: [],
  scripts: [],
  staticUrl: '',
  analyticsConfig: {
    key: '',
    host: '',
  },
};

describe('Html', () => {
  it('renders', () => {
    expect(mount(<Html {...requireProps} />)).toMatchSnapshot();
  });

  it('renders with scripts and styles', () => {
    const scripts = ['a.css', 'b.css', 'c.js', 'd.js'];
    const styles = [
      {
        id: 'x',
        cssText: 'x content',
      },
      {
        id: 'y',
        cssText: 'y content',
      },
    ];
    const mode = ['mode1'];

    expect(
      mount(
        <Html
          {...requireProps}
          scripts={scripts}
          styles={styles}
          mode={mode}
        />,
      ),
    ).toMatchSnapshot();
  });
});
