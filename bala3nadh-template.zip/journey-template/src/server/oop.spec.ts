import oop from '@bala3nadh/oop/server';

jest.mock('@bala3nadh/oop/server');
jest.mock('server/services/ajaxClient', () => jest.fn());
jest.mock('server/utils/logger', () => ({
  getService: () => ({
    error: jest.fn(),
  }),
}));
jest.mock('config', () => ({
  oop: {
    host: 'host',
    endpoints: {
      record: '/record',
      serviceFields: '/serviceFields',
      serviceFieldsData: '/serviceFieldsData',
      profileItems: '/profileItems',
    },
  },
  onwani: {
    host: 'onwaniHost',
    endpoints: {
      onwaniSearch: 'onwaniSearch',
    },
  },
}));

describe('oop', () => {
  let initialApiGatewayHeader: any;
  let initialApiGatewayKey: any;

  beforeEach(() => {
    initialApiGatewayHeader = process.env.API_GATEWAY_HEADER;
    initialApiGatewayKey = process.env.API_GATEWAY_KEY;
  });

  afterEach(() => {
    process.env.API_GATEWAY_HEADER = initialApiGatewayHeader;
    process.env.API_GATEWAY_KEY = initialApiGatewayKey;
  });

  it('should call oop() with correct params', () => {
    process.env.API_GATEWAY_HEADER = 'apiGatewayHeader';
    process.env.API_GATEWAY_KEY = 'apiGatewayKey';

    jest.isolateModules(() => {
      require('./oop'); // eslint-disable-line global-require
    });

    expect(oop).toHaveBeenCalledWith({
      host: 'host',
      ajaxClient: expect.anything(),
      logger: {
        error: expect.anything(),
      },
      gateway: {
        header: 'apiGatewayHeader',
        key: 'apiGatewayKey',
      },
      endpoints: {
        record: '/record',
        serviceFields: '/serviceFields',
        serviceFieldsData: '/serviceFieldsData',
        profileItems: '/profileItems',
      },
      onwani: {
        host: 'onwaniHost',
        endpoints: {
          onwaniSearch: 'onwaniSearch',
        },
      },
    });
  });

  it('should call oop() with correct params if variables is undefined', () => {
    process.env.API_GATEWAY_HEADER = '';
    process.env.API_GATEWAY_KEY = '';

    jest.isolateModules(() => {
      require('./oop'); // eslint-disable-line global-require
    });

    expect(oop).toHaveBeenCalledWith(
      expect.objectContaining({
        gateway: {
          header: '',
          key: '',
        },
      }),
    );
  });
});
