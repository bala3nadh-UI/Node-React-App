import { hookLoader, createHandler } from 'istanbul-middleware';
import bodyParser from 'body-parser';
import compression from 'compression';
import config from 'config';
import helmetConfig from 'config/helmetConfig';
import cookieParser from 'cookie-parser';
import express, { NextFunction, Response } from 'express';
import os from 'os';
import helmet from 'helmet';
import path from 'path';
import csrf from 'csurf';

import internalApi from 'server/api/internal';
import publicApi from 'server/api/public';
import initialRender from 'server/middlewares/initialRender';
import logUuid from 'server/middlewares/logUuid';
import Bala3nadhSessionFactory from 'server/session-store';
import cms from 'server/cms';
import getSSR from 'server/middlewares/ssr';
import smartpass from 'server/smartpass';
import bala3nadhLogger, { getMiddleware } from 'server/utils/logger';
import adpayRedirectHandler from 'server/services/adpayRedirectHandler';
import expressUseragent from 'express-useragent';
import attachJourneyData from 'server/middlewares/attachJourneyData';
import adpayRedirectHandlerV2 from './services/adpayRedirectHandlerV2';

const now = new Date();
const rootApp = express();
const redirectApp = express();
const app = express();
const logger = bala3nadhLogger.getService();
const csrfProtection = csrf();

rootApp.disable('x-powered-by');
app.disable('x-powered-by');
redirectApp.disable('x-powered-by');

if (process.env.STAGING === 'true') {
  hookLoader(__dirname);
  app.use('/coverage', createHandler());
}

app.use(getMiddleware());
app.use(expressUseragent.express());

// attach requestId to response
app.use((req, res, next) => {
  res.locals.requestId = req.id;
  next();
});
// logger.info(`Configs for ${config.projectName}`, {
//   config,
//   env: process.env,
// });

rootApp.get(/\/static\/ui-lib/, (req, res) => {
  if (req.method === 'GET' && req.hostname.match(/localhost/)) {
    res.redirect(`${config.staticUrl}${req.path.replace(config.basePath, '')}`);
  }
});

rootApp.use(config.basePath, app);
redirectApp.get(`*`, (req: Express.Request, res: Response) => {
  res.redirect(config.basePath);
});
rootApp.use(redirectApp);

//
// Tell any CSS tooling (such as Material UI) to use all vendor prefixes if the
// user agent is not known.
// -----------------------------------------------------------------------------
try {
  global.navigator = global.navigator || {};
  global.navigator.userAgent = global.navigator.userAgent || 'all';
} catch (e) {
  logger.error('Some navigator setting issue', { err: e });
}
//
// Register Node.js middleware
// -----------------------------------------------------------------------------
app.use((req, res, next) => {
  // https://jira.digitalx1.io/jira/browse/TQA-928
  req.headers['user-agent'] = `${req.headers['user-agent']}`.substr(0, 150);
  next();
});
app.use(compression());

app.use(express.static(path.resolve(__dirname, 'public')));

app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true, limit: '20mb' }));
app.use(
  /^(?!.*(\/api\/proxy\/|\/pub\/proxy\/).*).*/,
  bodyParser.json({
    limit: '20480kb',
  }),
);

app.post(
  /^\/api\/.*\/payment-gateway-response-redirect.*/,
  adpayRedirectHandler,
);

app.post(
  /^\/api\/.*\/payment-gateway-response-redirect-v2.*/,
  adpayRedirectHandlerV2,
);

// redirect payment gateway to solve same site cookies issue in Google Chrome
app.post(/^\/api\/.*\/payment-gateway-response.*/, (req, res) => {
  res.redirect(`${config.basePath}${req.url}?paymentId=${req.body.paymentid}`);
});
app.post(/^\/api\/.*\/pg-response.*/, (req, res) => {
  res.redirect(`${config.basePath}${req.url}?paymentId=${req.body.paymentid}`);
});

//
// Authentication
// -----------------------------------------------------------------------------

app.set('trust proxy', config.behindProxy || undefined);

/* global GIT_SHORT */
const name = `${process.env.SESSION_STORE_PREFIX}_${GIT_SHORT}_sid`;
const ONE_AND_HALF_HOUR = 90 * 60 * 1000;
app.use(
  Bala3nadhSessionFactory.getSessionMiddleware({
    name,
    secret: config.sesSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: ONE_AND_HALF_HOUR,
      secure: config.overHttps,
      httpOnly: true,
    },
  }),
);

app.use(
  Bala3nadhSessionFactory.getSessionFixationMiddleware({ everyRequest: false }),
);

app.use(logUuid);

app.use(helmet(helmetConfig));

/**
 * Application Routes
 */

// csrfProtection for all POSTs
// except /pub/*
// except api/smartpass
// except api/cms
app.post(
  /^\/(?!((pub\/|login\/callback)|(api\/smartpass)|(api\/cms))).*/,
  csrfProtection,
  (req, res, next) => {
    req.log.debug('POST on API under CSRF protection');
    next();
  },
);

// csrfProtection for all PUTs
app.put('*', csrfProtection, (req, res, next) => {
  req.log.debug('PUT on API under CSRF protection');
  next();
});

const tags = process.env.HEALTH_TAGS || 'unknown revision';
const date = `${now.toLocaleTimeString()} ${now.toLocaleDateString()}`;
// eslint-disable-next-line consistent-return
app.get(`/health`, async (req, res) => {
  if (req.session) {
    req.session.ping_test = 'true';
    req.session.save(function callback(err) {
      if (!err) {
        return res.json({
          status: 'OK',
          tags,
          date,
          hostname: os.hostname(),
        });
      }
      return res.status(400).json({
        status: 'FAIL',
        tags,
        date,
        hostname: os.hostname(),
      });
    });
  } else {
    return res.status(400).json({
      status: 'FAIL',
      tags,
      date,
      hostname: os.hostname(),
    });
  }
});

app.get(
  '/graceful-shutdown-test',
  (req: express.Request, res: express.Response) => {
    setTimeout(() => {
      res.send('~20000ms');
    }, 20000);
  },
);

/**
 * Register API middleware
 */
// Rest APIz
app.use('/api', smartpass.middlewares.sessionExtender, internalApi);

// public facing api for push updates
app.use('/pub', publicApi);

// page initial rendering

app.get(
  '*',
  smartpass.middlewares.auth,
  csrfProtection,
  cms.middlewares.data,
  cms.middlewares.info,
  getSSR(),
  attachJourneyData,
  initialRender,
);
app.use((err: any, req: Express.Request, res: Response, next: NextFunction) => {
  if (err.message.includes('Unknown user')) {
    req.log.error('Auth error handler', { err, req });
    return res.send(401);
  }
  return next(err);
});

app.use((err: any, req: Express.Request, res: Response, next: NextFunction) => {
  req.log.error('General error handler', { err, req });
  try {
    if (err.statusCode) {
      res.status(err.statusCode).send({
        success: false,
        error: {
          message: err.message,
        },
      });
      return;
    }

    next();
  } catch (handlerError) {
    logger.error('Unhandled error:', {
      err,
      handlerError,
    });
  }
});

process.on('unhandledRejection', (reason: any, promise: any) => {
  logger.error('Unhandled Rejection at:', {
    err: reason ? reason.stack || reason : promise,
  });
});

export default rootApp;

if (module && module.exports) {
  module.exports.rootApp = rootApp;
}
