import OOPService from '@bala3nadh/oop/server';

import ajaxClient from 'server/services/ajaxClient';
import bala3nadhLogger from 'server/utils/logger';

import config from 'config';

const logger = bala3nadhLogger.getService();

export default OOPService({
  host: config.oop.host,
  ajaxClient,
  logger,
  gateway: {
    header: process.env.API_GATEWAY_HEADER || '',
    key: process.env.API_GATEWAY_KEY || '',
  },
  endpoints: config.oop.endpoints as any,
  useMockUser: config.oop.useMockUser,
  onwani: {
    host: config.onwani.host,
    endpoints: {
      onwaniSearch: config.onwani.endpoints.onwaniSearch,
    },
  },
});
