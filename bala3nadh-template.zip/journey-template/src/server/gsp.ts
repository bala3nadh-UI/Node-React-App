import GSPService from '@bala3nadh/gsp';

import ajaxClient from 'server/services/ajaxClient';
import bala3nadhLogger from 'server/utils/logger';

import gspConfig from 'server/config/gsp.json';

import config from 'config';

const logger = bala3nadhLogger.getService();

export default GSPService({
  service: ajaxClient,
  logger,
  gateway: {
    header: process.env.API_GATEWAY_HEADER || '',
    key: process.env.API_GATEWAY_KEY || '',
  },
  services: {
    url: `${config.gsp.host}${config.gsp.services.endpoint}`,
    path: config.gsp.baseCacheDir,
    config: gspConfig,
  },
});
