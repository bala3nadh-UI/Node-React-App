import Bala3nadhLogger from '@bala3nadh/logger';

jest.mock('@bala3nadh/logger', () =>
  jest.fn(() => ({
    getMiddleware: jest.fn(),
  })),
);
jest.mock('config', () => ({
  projectName: 'projectName',
  log: {
    level: 'level',
    directory: 'directory',
    types: ['type'],
  },
}));

describe('logger', () => {
  let mockLogger: any;

  it('should call Bala3nadhLogger() and getMiddleware() with correct params', () => {
    // eslint-disable-next-line global-require
    mockLogger = require('./logger');

    mockLogger.getMiddleware();

    expect(Bala3nadhLogger).toHaveBeenCalledWith({
      projectName: 'projectName',
      log: {
        level: 'level',
        directory: 'directory',
        types: ['type'],
      },
    });
    expect(mockLogger.default.getMiddleware).toHaveBeenCalled();
  });
});
