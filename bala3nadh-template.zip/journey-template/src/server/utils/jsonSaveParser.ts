export default (item: any) => {
  try {
    return JSON.parse(item);
  } catch (error) {
    return item;
  }
};
