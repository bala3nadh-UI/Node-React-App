import jsonSaveParser from './jsonSaveParser';

describe('jsonSaveParser.ts', () => {
  it('should parse JSON', () => {
    // eslint-disable-next-line global-require
    expect(jsonSaveParser('{}')).toMatchObject({});
  });

  it('should return input string if invalid', () => {
    // eslint-disable-next-line global-require
    expect(jsonSaveParser('{')).toEqual('{');
  });
});
