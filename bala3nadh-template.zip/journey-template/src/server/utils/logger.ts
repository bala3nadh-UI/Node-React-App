import Bala3nadhLogger from '@bala3nadh/logger';
import config from 'config';

const { projectName, log } = config;

const bala3nadhLogger = Bala3nadhLogger({ projectName, log });

/**
 * @returns {Function}
 */
export const getMiddleware = () => bala3nadhLogger.getMiddleware();

export default bala3nadhLogger;
