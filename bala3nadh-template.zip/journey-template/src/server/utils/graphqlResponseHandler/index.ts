/* eslint-disable no-underscore-dangle */
/**
 *
 * @param {ioResponse} graphqlResponse
 * @returns {Object}
 */
export default function graphqlResponseHandler(graphqlResponse: any) {
  try {
    const objectKeys = Object.keys(graphqlResponse);
    if (objectKeys[0]) {
      const result = graphqlResponse[objectKeys[0]];
      delete result.__typename;
      return result;
    }
    return null;
  } catch (e) {
    return null;
  }
}
