import graphqlResponseHandler from './index';

describe('graphqlResponseHandler', () => {
  let res: any = {
    product: {},
  };
  it('should return the first element', () => {
    const result = graphqlResponseHandler(res);
    expect(result).toEqual({});
  });

  it('should return null', () => {
    res = {};
    const result = graphqlResponseHandler(res);
    expect(result).toBeNull();
  });

  it('should return null', () => {
    res = null;
    const result = graphqlResponseHandler(res);
    expect(result).toBeNull();
  });
});
