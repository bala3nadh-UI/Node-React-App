import deepMap from './deepMap';

describe('server/utils/deepMap', () => {
  beforeEach(() => {});

  const mapFn = (value: any) => {
    return `Updated ${value}`;
  };

  it('is function', () => expect(deepMap).toBeInstanceOf(Function));

  it('should format', () => {
    const obj = {
      stringField: 'String Field',
      arrayField: [
        {
          stringArrayItem: 'String in obj',
        },
      ],
    };

    const formatted = deepMap(obj, mapFn);

    expect(formatted).toEqual({
      stringField: 'Updated String Field',
      arrayField: [
        {
          stringArrayItem: 'Updated String in obj',
        },
      ],
    });
  });

  it('uses cache', () => {
    const obj = { foo: 'bar' };

    const cache = new Map();
    cache.set(obj, { foo: 'Cached bar' });

    const formatted = deepMap(obj, mapFn, null, null, cache);

    expect(formatted).toEqual({ foo: 'Cached bar' });
  });
});
