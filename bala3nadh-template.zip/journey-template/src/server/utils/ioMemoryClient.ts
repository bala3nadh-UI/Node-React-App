import Bala3nadhIoClientBuilder from '@bala3nadh/io-client';
import config from 'config';
import bala3nadhLogger from 'server/utils/logger';
import authConfig from 'config/authConfig';

export const ioMemoryClient = Bala3nadhIoClientBuilder({
  name: config.projectName,
  logger: bala3nadhLogger.getService(),
  host: config.io.memory!,
  headers: {
    [authConfig.apiGateway.header]: authConfig.apiGateway.key,
  },
});
