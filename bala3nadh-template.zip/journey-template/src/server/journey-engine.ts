// eslint-disable-next-line import/no-extraneous-dependencies
import journeyEnginePackage from '@bala3nadh/journey-engine';
import config from 'config';
import ajaxClient from 'server/services/ajaxClient';
import bala3nadhLogger from 'server/utils/logger';
import { ioMemoryClient } from 'server/utils/ioMemoryClient';
import { ioDbClient } from 'server/services/io/ioClient';

const logger = bala3nadhLogger.getService();

const journeyEngine = journeyEnginePackage({
  projectName: config.projectName,
  appNestedPath: config.basePath,
  service: ajaxClient,
  bala3nadhUrl: config.cms.bala3nadhUrl,
  logger,
  ioClient: ioDbClient,
  ioMemoryClient,
  cms: {
    host: config.cms.host,
    journeyItemsEndpoint: config.cms.journeyItems.endpoint,
    apiGateway: {
      header: process.env.API_GATEWAY_HEADER,
      key: process.env.API_GATEWAY_KEY,
    },
  },
  journeyTracker: {
    host: config.journeyTracker.host,
    endpoints: {
      upsert: config.journeyTracker.endpoints.upsert,
      getList: config.journeyTracker.endpoints.getList,
      getJourneyInstance: config.journeyTracker.endpoints.getJourneyInstance,
    },
    mock: false,
    apiGateway: {
      header: process.env.API_GATEWAY_HEADER,
      key: process.env.API_GATEWAY_KEY,
    },
  },
  applicationTracker: {
    host: config.applicationTracker.host,
    endpoints: {
      getApplicationList:
        config.applicationTracker.endpoints.getApplicationList,
    },
    mock: false,
    apiGateway: {
      header: process.env.API_GATEWAY_HEADER,
      key: process.env.API_GATEWAY_KEY,
    },
  },
  globalContext: {
    host: `${config.serviceApiBaseUrl}/${config.globalContext.endpoint}`,
    endpoint: '/context',
    apiGateway: {
      header: process.env.API_GATEWAY_HEADER,
      key: process.env.API_GATEWAY_KEY,
    },
  },
  eligibilityEngine: {
    host: `${config.eligibilityEngine.host}`,
    endpoints: {
      checkEligibilityWithCriteria: `${config.eligibilityEngine.endpoints.checkEligibilityWithCriteria}`,
    },
    apiGateway: {
      header: process.env.API_GATEWAY_HEADER,
      key: process.env.API_GATEWAY_KEY,
    },
  },
});

export default journeyEngine;
