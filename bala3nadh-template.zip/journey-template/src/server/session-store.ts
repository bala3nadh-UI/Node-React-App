import Bala3nadhSessionFactory, { SessionStoreOptions } from '@bala3nadh/session';
import sessionStoreConfig from 'config/sessionStoreConfig';
import authConfig from 'config/authConfig';
import bala3nadhLogger from 'server/utils/logger';
import { ioMemoryClient } from 'server/utils/ioMemoryClient';

const options: SessionStoreOptions = {
  ...sessionStoreConfig,
  authHeaders: authConfig,
};

Bala3nadhSessionFactory.initSessionStore(
  options,
  bala3nadhLogger.getService(),
  ioMemoryClient,
);

export default Bala3nadhSessionFactory;
