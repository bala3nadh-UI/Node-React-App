const onStartDev = require('./onStartDev');
const onStartProd = require('./onStartProd');

module.exports = {
  onStartDev,
  onStartProd,
};
