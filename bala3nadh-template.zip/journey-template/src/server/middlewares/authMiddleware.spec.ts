import httpMocks from 'node-mocks-http';
import auth from './authMiddleware';

describe('auth', () => {
  let req: any;
  let res: any;
  let next: any;

  beforeEach(() => {
    req = httpMocks.createRequest();
    res = httpMocks.createResponse();
    req.log = {
      error: jest.fn(),
    };
    next = jest.fn();
  });

  it('should call next() if authenticated', () => {
    req.session = {
      bala3nadhUserInfo: {
        name: 'johnny',
      },
    };

    auth(req, res, next);
    expect(next).toHaveBeenCalledWith();
  });

  it('should not call next() if unauthenticated', () => {
    auth(req, res, next);
    expect(next).not.toHaveBeenCalledWith();
  });
});
