import { Request, Response, NextFunction } from 'express';
import { getConfigByJourneyId } from 'server/services/io/journeyConfig';

const regex = /\/j\/([\w-]*)\/([\w-]*)\/([\w-]{1,})/g; //  /j/:journeyId/:stageId/:userJourneyId
export default async (req: Request, res: Response, next: NextFunction) => {
  /*
  Fixes issue mentioned below -
  https://stackoverflow.com/questions/3811890/javascript-regular-expression-fails-every-other-time-it-is-called
  */
  regex.lastIndex = 0;
  const matched = regex.exec(req.path);
  let journeyId;
  if (
    (req.path.indexOf('questionnaire') > -1 ||
      req.path.indexOf('simulator') > -1) &&
    req.query.journeyId
  ) {
    journeyId = req.query.journeyId as string;
  } else if (matched) {
    journeyId = matched[1];
  }
  if (journeyId) {
    const preview = req.originalUrl.includes('preview=1');
    req.log.info('Fetching journey info ==>');
    const journeyData = await getConfigByJourneyId(req, journeyId, preview);
    req.log.info('Fetching journey data ==>', journeyData);
    (req as any).journeyData = {
      journeyId,
      settings: journeyData?.settings,
      stages: journeyData?.stages?.map((stage: any) => ({
        ...stage,
        items: undefined,
      })),
    };
    next();
  } else {
    next();
  }
};
