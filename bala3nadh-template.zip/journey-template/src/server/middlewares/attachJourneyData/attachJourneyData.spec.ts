import httpMocks from 'node-mocks-http';
import * as ioModule from 'server/services/io/journeyConfig';
import attachJourneyData from '.';

jest.mock('server/services/io/journeyConfig');

describe('attachJourneyData', () => {
  let req: any;
  let res: any;
  let next: any;
  const io: any = ioModule;

  beforeEach(() => {
    req = httpMocks.createRequest();
    res = {
      header: jest.fn(),
      set: jest.fn(),
      send: jest.fn(),
      json: jest.fn(),
    };
    next = jest.fn();

    req.log = {
      error: jest.fn(),
      info: jest.fn(),
    };
  });

  it('should include journey context', async () => {
    req.path = '/test/j/1/47/ssss/something';
    io.getConfigByJourneyId.mockResolvedValueOnce({
      id: 1,
      userId: '1',
    });

    await attachJourneyData(req, res, next);
    expect(next).toHaveBeenCalled();
  });

  it('should include journey context for questionnaire', async () => {
    req.path = '/questionnaire/j/1/47/ssss/something';
    req.query = {
      journeyId: 'journey',
      stageId: 'abcd',
    };
    // @ts-ignore
    io.getConfigByJourneyId.mockResolvedValueOnce({
      id: 1,
      userId: '1',
      settings: {},
      stages: [
        {
          id: '1234',
        },
      ],
    });

    await attachJourneyData(req, res, next);
    expect(next).toHaveBeenCalled();
  });

  it('should include journey context for simulator', async () => {
    req.path = '/simulator/j/1/47/ssss/something';
    req.query = {
      journeyId: 'journey',
      stageId: 'abcd',
    };
    // @ts-ignore
    io.getConfigByJourneyId.mockResolvedValueOnce({
      id: 1,
      userId: '1',
      settings: {},
      stages: [
        {
          id: '1234',
        },
      ],
    });

    await attachJourneyData(req, res, next);
    expect(next).toHaveBeenCalled();
  });

  it('should not include journey context', async () => {
    io.getConfigByJourneyId.mockResolvedValueOnce({
      id: 1,
      userId: '1',
    });
    await attachJourneyData(req, res, next);
    expect(next).toHaveBeenCalled();
  });
});
