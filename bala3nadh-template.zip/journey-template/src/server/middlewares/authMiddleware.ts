import { Request, Response, NextFunction } from 'express';
import { createErrorResponse } from 'server/utils/response-utils';

interface RequestWithSession extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

export default (req: RequestWithSession, res: Response, next: NextFunction) => {
  const isAuthorized = req.session && req.session.bala3nadhUserInfo;

  if (!isAuthorized) {
    return createErrorResponse(req, res, 'Unauthorized', {});
  }
  return next();
};
