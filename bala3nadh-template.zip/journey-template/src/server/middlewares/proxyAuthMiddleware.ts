import { NextFunction, Request, Response } from 'express';
import { createErrorResponse } from 'server/utils/response-utils';
import proxyConfig from 'server/config/proxyConfig';
import url from 'url';
import { isObject } from 'lodash';

const route = require('path-match')({
  sensitive: false,
  strict: false,
  end: false,
});

interface ProxyAuthMiddlewarerRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

const pathMatch = (req: Request, res: Response, paths: any[], path: string) => {
  return paths.some((item: any) => {
    let allowedPath: any = item;
    res.locals.proxyRequestSchema = null;

    if (isObject(allowedPath)) {
      allowedPath = item.path;
      res.locals.proxyRequestSchema = item.validation;
    }
    if (item.method && req.method.toLowerCase() !== item.method.toLowerCase()) {
      allowedPath = '-1';
    }
    const match = route(allowedPath);
    const params = match(path);
    return !!params;
  });
};

const getPath = (originalUrl: string): string => {
  const { pathname } = url.parse(originalUrl);
  return pathname ? pathname.substring(pathname.indexOf('proxy') + 5) : '';
};

const proxyAuthMiddleware = (type: string) => {
  return (
    req: ProxyAuthMiddlewarerRequest,
    res: Response,
    next: NextFunction,
  ) => {
    const path = getPath(req.originalUrl);

    if (type === 'public' && pathMatch(req, res, proxyConfig.public, path)) {
      return next();
    }

    if (type === 'protected') {
      const isAuthorized = req.session && req.session.bala3nadhUserInfo;
      // @ts-ignore
      const isSOP3 = isAuthorized && req.session.bala3nadhUserInfo.Type === 'SOP3';

      if (
        isSOP3 &&
        pathMatch(
          req,
          res,
          [...proxyConfig.verified, ...proxyConfig.loggedIn],
          path,
        )
      ) {
        return next();
      }

      if (isAuthorized && pathMatch(req, res, proxyConfig.loggedIn, path)) {
        return next();
      }
    }

    return createErrorResponse(req, res, 'Unauthorized', {}, 401);
  };
};

export default proxyAuthMiddleware;
