import { Request, Response, NextFunction } from 'express';

export const sanitizeContent = (value: string): string => {
  return value.replace(/[^\w- ]/g, '');
};

export function recursiveSanitizer(obj: any) {
  const object = obj;
  if (!object) {
    return;
  }
  if (typeof object === 'object') {
    if (Array.isArray(object)) {
      object.forEach((item: any) => recursiveSanitizer(item));
    } else if (object instanceof Date) {
      // do nothing
    } else {
      Object.keys(object).forEach((key: string) => {
        if (typeof object[key] === 'object') {
          recursiveSanitizer(object[key]);
        } else if (typeof object[key] === 'string') {
          object[key] = sanitizeContent(object[key]);
        }
      });
    }
  }
}

export default function requestSanitizer(
  request: Request,
  response: Response,
  next: NextFunction,
) {
  recursiveSanitizer(request.body);
  next();
}
