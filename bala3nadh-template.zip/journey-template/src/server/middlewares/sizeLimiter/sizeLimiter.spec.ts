import httpMocks from 'node-mocks-http';
import { createErrorResponse } from 'server/utils/response-utils';
import sizeLimiter from '.';

jest.mock('server/utils/response-utils');
describe('sizeLimiter', () => {
  let req: any;
  let res: any;
  let next: any;

  beforeEach(() => {
    req = httpMocks.createRequest();
    res = httpMocks.createResponse();
    next = jest.fn();
  });
  test('should not pass', () => {
    req.body = {
      test: 'sssssssss',
    };
    sizeLimiter(1, 'test')(req, res, next);
    expect(createErrorResponse).toHaveBeenCalled();
  });
  test('it should pass', () => {
    req.body = {};
    sizeLimiter(10, 'test')(req, res, next);
    expect(next).toHaveBeenCalled();
  });
});
