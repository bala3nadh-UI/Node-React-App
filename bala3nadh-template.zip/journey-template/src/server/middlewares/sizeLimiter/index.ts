import { Request, Response, NextFunction } from 'express';
import sizeof from 'object-sizeof';
import { createErrorResponse } from 'server/utils/response-utils';

export default (sizeLimit: number, message: string) => (
  request: Request,
  response: Response,
  next: NextFunction,
) => {
  const size = sizeof(request.body);
  if (sizeLimit >= size) return next();
  return createErrorResponse(request, response, message, {}, 500);
};
