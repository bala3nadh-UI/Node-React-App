import { Request, Response, NextFunction } from 'express';
import { customAlphabet } from 'nanoid';

const alphabet = '0123456789abcdefghijklmnopqrstuvwxyz';

const LONG_AGE = 60 * 60 * 24 * 365 * 1000;

export default (req: Request, res: Response, next: NextFunction) => {
  const nanoid = customAlphabet(alphabet, 10);
  const logUuid = req.cookies.logUuid || nanoid();

  if (!req.cookies.logUuid) {
    res.cookie('logUuid', logUuid, { maxAge: LONG_AGE });
  }

  req.logUuid = logUuid;

  next();
};
