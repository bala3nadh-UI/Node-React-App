import { Request } from 'express';
import ioClient from 'server/services/io/ioClient';
import queries from './queries';

/**
 * application by reservedPath
 * @param {Request} req
 * @param {number} reservedPath
 * @returns {Promise}
 */
export const getApplicationByReservedPath = async (
  req: Request,
  reservedPath: string,
) => {
  const payload = await ioClient.query(
    {
      query: queries.applicationByReservedPath,
      variables: {
        reservedPath,
      },
    },
    req,
  );

  return payload.application;
};

export default {
  getApplicationByReservedPath,
};
