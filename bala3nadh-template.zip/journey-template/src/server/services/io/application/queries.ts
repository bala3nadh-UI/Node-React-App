import gql from 'graphql-tag';

const applicationByReservedPath = gql`
  query applicationByReservedPath($reservedPath: String!) {
    application: applicationByReservedPath(reservedPath: $reservedPath) {
      id
      bundleId
    }
  }
`;

export default {
  applicationByReservedPath,
};
