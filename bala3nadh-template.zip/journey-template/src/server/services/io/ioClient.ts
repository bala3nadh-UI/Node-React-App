import IoClient from '@bala3nadh/io-client';
import config from 'config';
import authConfig from 'config/authConfig';
import bala3nadhLogger from 'server/utils/logger';

const logger = bala3nadhLogger.getService();

export default IoClient({
  name: config.projectName,
  logger,
  host: `${config.ioTools.host}${config.ioTools.apolloEndpoint}`,
  headers: {
    [authConfig.apiGateway.header]: authConfig.apiGateway.key,
  },
});

export const ioDbClient = IoClient({
  name: config.projectName,
  logger,
  host: `${config.io.db}`,
  headers: {
    [authConfig.apiGateway.header]: authConfig.apiGateway.key,
  },
});
