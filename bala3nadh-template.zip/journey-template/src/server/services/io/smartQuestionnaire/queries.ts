import gql from 'graphql-tag';

const fetchSmartQuestionnaireConfigByFilter = gql`
  query latestConfigByFilter($filter: ConfigFilterInput!) {
    latestQuestionnaireConfigByFilter(filter: $filter) {
      id
      wbProjectId
      questionnaireName
      questionnairePath
      config
      questions
      createdAt
      updatedAt
    }
  }
`;

const fetchSmartQuestionnaireInstanceByFilter = gql`
  query latestQuestionnaireInstanceByFilter($filter: InstanceFilterInput!) {
    latestQuestionnaireInstanceByFilter(filter: $filter) {
      id
      userJourneyId
      userId
      questionnaireDeploymentId
      questionnaireStatus
      questionnaireResponses
      questionnairePath
      createdAt
      updatedAt
      isPreview
    }
  }
`;

export default {
  fetchSmartQuestionnaireConfigByFilter,
  fetchSmartQuestionnaireInstanceByFilter,
};
