import httpMocks from 'node-mocks-http';
import { ioDbClient } from 'server/services/io/ioClient';
import * as ioServices from './index';

jest.mock('server/services/io/ioClient');

describe('Smart Questionnaire IO Services', () => {
  let req: any;
  let mockIoClient: any;
  beforeEach(() => {
    mockIoClient = ioDbClient;
    req = httpMocks.createRequest();
  });

  describe('getQuestionnaireConfigByFilter', () => {
    it('should handle success', async () => {
      mockIoClient.query.mockReturnValueOnce({
        latestQuestionnaireConfigByFilter: 'mockSuccessfulData',
      });

      const data = await ioServices.getQuestionnaireConfigByFilter(req, {});

      expect(data).toBe('mockSuccessfulData');
    });
  });

  describe('getQuestionnaireInstanceByFilter', () => {
    it('should handle success', async () => {
      mockIoClient.query.mockReturnValueOnce({
        latestQuestionnaireInstanceByFilter: 'mockSuccessfulData',
      });

      const data = await ioServices.getQuestionnaireInstanceByFilter(req, {});

      expect(data).toBe('mockSuccessfulData');
    });
  });

  describe('createQuestionnaireInstance', () => {
    it('should handle success', async () => {
      mockIoClient.mutate.mockReturnValueOnce({
        createSmartQuestionnaireInstance: 'mockSuccessfulData',
      });

      const data = await ioServices.createQuestionnaireInstance(req, {});

      expect(data).toBe('mockSuccessfulData');
    });
  });

  describe('updateQuestionnaireInstance', () => {
    it('should handle success', async () => {
      mockIoClient.mutate.mockReturnValueOnce({
        updateSmartQuestionnaireInstanceById: 'mockSuccessfulData',
      });

      const data = await ioServices.updateQuestionnaireInstance(
        req,
        'mockId',
        {},
      );

      expect(data).toBe('mockSuccessfulData');
    });
  });

  describe('deleteQuestionnaireInstance', () => {
    it('should handle success', async () => {
      mockIoClient.mutate.mockReturnValueOnce({
        deleteSmartQuestionnaireInstanceById: 'mockSuccessfulData',
      });

      const data = await ioServices.deleteQuestionnaireInstance(req, 'mockId');

      expect(data).toBe('mockSuccessfulData');
    });
  });
});
