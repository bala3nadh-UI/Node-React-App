import gql from 'graphql-tag';

const createSmartQuestionnaireInstance = gql`
  mutation createSmartQuestionnaireInstance($data: InstanceDataInput!) {
    createSmartQuestionnaireInstance(data: $data) {
      id
      userJourneyId
      userId
      questionnaireDeploymentId
      questionnaireStatus
      questionnaireResponses
      questionnairePath
      isPreview
    }
  }
`;

const updateSmartQuestionnaireInstanceById = gql`
  mutation updateSmartQuestionnaireInstanceById(
    $id: ID!
    $data: InstanceDataInput!
  ) {
    updateSmartQuestionnaireInstanceById(id: $id, data: $data) {
      userJourneyId
      userId
      questionnaireDeploymentId
      questionnaireStatus
      questionnaireResponses
      questionnairePath
      isPreview
    }
  }
`;

const deleteSmartQuestionnaireInstanceById = gql`
  mutation deleteInstance($id: ID!, $permanently: Boolean) {
    deleteSmartQuestionnaireInstanceById(id: $id, permanently: $permanently)
  }
`;

export default {
  createSmartQuestionnaireInstance,
  updateSmartQuestionnaireInstanceById,
  deleteSmartQuestionnaireInstanceById,
};
