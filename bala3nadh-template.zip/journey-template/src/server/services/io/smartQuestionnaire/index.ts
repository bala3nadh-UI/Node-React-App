import { Request } from 'express';
import { IVariables } from '@bala3nadh/app-composer';
import { ioDbClient } from 'server/services/io/ioClient';
import queries from './queries';
import mutations from './mutations';

export const getQuestionnaireConfigByFilter = async (
  req: Request,
  filter: IVariables,
) => {
  const payload = await ioDbClient.query(
    {
      query: queries.fetchSmartQuestionnaireConfigByFilter,
      variables: {
        filter,
      },
    },
    req,
  );

  return payload.latestQuestionnaireConfigByFilter;
};

export const getQuestionnaireInstanceByFilter = async (
  req: Request,
  filter: IVariables,
) => {
  const payload = await ioDbClient.query(
    {
      query: queries.fetchSmartQuestionnaireInstanceByFilter,
      variables: {
        filter,
      },
    },
    req,
  );

  return payload.latestQuestionnaireInstanceByFilter;
};

export const createQuestionnaireInstance = async (
  req: Request,
  data: IVariables,
) => {
  const payload = await ioDbClient.mutate(
    {
      mutation: mutations.createSmartQuestionnaireInstance,
      variables: {
        data,
      },
    },
    req,
  );

  return payload.createSmartQuestionnaireInstance;
};

export const updateQuestionnaireInstance = async (
  req: Request,
  id: string,
  data: IVariables,
) => {
  const payload = await ioDbClient.mutate(
    {
      mutation: mutations.updateSmartQuestionnaireInstanceById,
      variables: {
        id,
        data,
      },
    },
    req,
  );

  return payload.updateSmartQuestionnaireInstanceById;
};

export const deleteQuestionnaireInstance = async (req: Request, id: string) => {
  const payload = await ioDbClient.mutate(
    {
      mutation: mutations.deleteSmartQuestionnaireInstanceById,
      variables: {
        id,
        permanently: false,
      },
    },
    req,
  );

  return payload.deleteSmartQuestionnaireInstanceById;
};
