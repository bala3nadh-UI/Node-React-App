import { Request } from 'express';
import { ioDbClient } from 'server/services/io/ioClient';
import graphqlResponseHandler from 'server/utils/graphqlResponseHandler';
import queries from './queries';

/**
 * draft by draftId
 * @param {Request} req
 * @param {number} draftId
 * @returns {Promise}
 */
export const getDraftByDraftId = async (req: Request, draftId: string) => {
  const payload = await ioDbClient.query(
    {
      query: queries.savedDraftByDraftId,
      variables: {
        draftId,
      },
    },
    req,
  );

  return graphqlResponseHandler(payload);
};

/**
 * save draft by draftId
 * @param {Request} req
 * @param {number} draftId
 * @param {any} data
 * @returns {Promise}
 */
export const upsertDraft = async (req: Request, draftId: string, data: any) => {
  const payload = await ioDbClient.mutate(
    {
      mutation: queries.upsertSavedDraft,
      variables: {
        draftId,
        data,
      },
    },
    req,
  );
  return graphqlResponseHandler(payload);
};
export default {
  getDraftByDraftId,
  upsertDraft,
};
