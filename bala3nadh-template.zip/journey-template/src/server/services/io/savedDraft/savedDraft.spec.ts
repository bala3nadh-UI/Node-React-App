import { ioDbClient } from 'server/services/io/ioClient';
import graphqlResponseHandler from 'server/utils/graphqlResponseHandler';
import * as repo from './index';

jest.mock('server/services/io/ioClient', () => ({
  ioDbClient: { query: jest.fn(), mutate: jest.fn() },
}));
const req: any = {};

jest.mock('server/utils/graphqlResponseHandler', () => jest.fn());

describe('savedDraft repo', () => {
  const mockApolloQuery = ioDbClient.query as jest.MockedFunction<
    typeof ioDbClient.query
  >;

  const mockApolloMutate = ioDbClient.mutate as jest.MockedFunction<
    typeof ioDbClient.mutate
  >;

  it('getDraftByDraftId should work correctly ', async () => {
    const mockResult = { data: 'data' } as any;
    mockApolloQuery.mockResolvedValue(mockResult);
    await repo.getDraftByDraftId(req, '1');
    expect(graphqlResponseHandler).toHaveBeenCalledWith(mockResult);
  });

  it('upsertDraft should work correctly ', async () => {
    const mockResult = { data: 'data' } as any;
    mockApolloMutate.mockResolvedValue(mockResult);
    await repo.upsertDraft(req, '1', {});
    expect(graphqlResponseHandler).toHaveBeenCalledWith(mockResult);
  });
});
