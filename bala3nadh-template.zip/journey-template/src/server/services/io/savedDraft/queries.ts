import gql from 'graphql-tag';

const savedDraftByDraftId = gql`
  query savedDraftByDraftId($draftId: ID!) {
    savedDraftByDraftId(draftId: $draftId) {
      id
      userId
      draftId
      applicationId
      data
    }
  }
`;

const upsertSavedDraft = gql`
  mutation upsertSavedDraft($draftId: ID!, $data: SavedDraftUpdateInput!) {
    upsertSavedDraft(draftId: $draftId, data: $data) {
      id
      userId
      draftId
      applicationId
      data
    }
  }
`;

export default {
  savedDraftByDraftId,
  upsertSavedDraft,
};
