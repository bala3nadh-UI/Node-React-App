import gql from 'graphql-tag';

export const getConfigByJourneyId = gql`
  query configByJourneyId($journeyId: String!, $preview: Boolean) {
    configByJourneyId(journeyId: $journeyId, preview: $preview)
  }
`;

export default {
  getConfigByJourneyId,
};
