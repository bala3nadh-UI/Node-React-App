import { ioDbClient } from 'server/services/io/ioClient';
import { Request } from 'express';
import graphqlResponseHandler from 'server/utils/graphqlResponseHandler';
import wbApplicationPreviewGraphqlRepo from './queries';

export const getConfigByJourneyId = async (
  req: Request,
  journeyId: string = '',
  preview: boolean = false,
) => {
  const result = await ioDbClient.query(
    {
      query: wbApplicationPreviewGraphqlRepo.getConfigByJourneyId,
      variables: {
        journeyId: journeyId.toString(),
        preview,
      },
    },
    req,
  );
  return graphqlResponseHandler(result);
};

export default {
  getConfigByJourneyId,
};
