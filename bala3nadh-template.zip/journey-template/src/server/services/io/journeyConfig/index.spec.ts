import { ioDbClient } from 'server/services/io/ioClient';
import graphqlResponseHandler from 'server/utils/graphqlResponseHandler';
import * as repo from './index';

jest.mock('server/services/io/ioClient', () => ({
  ioDbClient: { query: jest.fn(), mutate: jest.fn() },
}));
const req: any = {};

jest.mock('server/utils/graphqlResponseHandler', () => jest.fn());

describe('jourenyConfig repo', () => {
  const mockApolloQuery = ioDbClient.query as jest.MockedFunction<
    typeof ioDbClient.query
  >;

  it('getConfigByJourneyId should work correctly ', async () => {
    const mockResult = { data: 'data' } as any;
    mockApolloQuery.mockResolvedValue(mockResult);
    await repo.default.getConfigByJourneyId(req, '22', true);
    expect(graphqlResponseHandler).toHaveBeenCalledWith(mockResult);
  });
});
