import { Request, Response } from 'express';
import config from 'config';
import bala3nadhLogger from 'server/utils/logger';

const logger = bala3nadhLogger.getService();

const adpayRedirectHandler = (req: Request, res: Response) => {
  // Example Gateway Return Url = http://localhost:3000/journeys/journey-template/api/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect/payment-gateway-response-redirect/abcd1234

  logger.info('request Url ==>', req.url);
  const { body } = req;
  const splitArray = req.url.split('/');

  const workbenchVersion = splitArray[2];
  const workbenchUniqueId = splitArray[3];
  const serviceName = splitArray[4];
  const pageName = splitArray[5];
  const transactionId = req.url.endsWith('/')
    ? splitArray[splitArray.length - 2]
    : splitArray[splitArray.length - 1];
  const basePath = config.basePath.endsWith('/')
    ? config.basePath
    : `${config.basePath}/`;
  const returnUrl = `${basePath}${workbenchVersion}/${workbenchUniqueId}/${serviceName}/${pageName}?transactionId=${transactionId}${
    body ? `&paymentData=${JSON.stringify(body)}` : ''
  }`;
  logger.info('FE Return URL ==>', returnUrl);

  // FE Return URL ==> /journeys/journey-template/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect?transactionId=abcd1234&paymentData=undefined

  res.redirect(303, returnUrl);
};

export default adpayRedirectHandler;
