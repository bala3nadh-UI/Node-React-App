import httpMocks from 'node-mocks-http';
import adpayRedirectHandler from './index';

describe('adpayRedirectHandler test', () => {
  let req: httpMocks.MockRequest<any>;
  let res: httpMocks.MockResponse<any>;

  beforeEach(() => {
    req = httpMocks.createRequest();
    res = httpMocks.createResponse();
  });

  it(`should call adpayRedirectHandler`, () => {
    req.url =
      '/api/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect/payment-gateway-response-redirect/abcd1234';
    req.body = {
      paymentid: '1234',
      trandata: {
        paymentTranId: 'abcd',
      },
    };

    adpayRedirectHandler(req, res);
  });

  it(`should call adpayRedirectHandler with url terminated by slash`, () => {
    req.url =
      '/api/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect/payment-gateway-response-redirect/abcd1234/';
    req.body = {
      paymentid: '1234',
      trandata: {
        paymentTranId: 'abcd',
      },
    };

    adpayRedirectHandler(req, res);
  });

  it(`should call adpayRedirectHandler without body`, () => {
    req.url =
      '/api/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect/payment-gateway-response-redirect/abcd1234';
    req.body = null;

    adpayRedirectHandler(req, res);
  });
});
