import httpMocks from 'node-mocks-http';
import adpayRedirectHandlerV2 from './index';

describe('adpayRedirectHandlerV2 test', () => {
  let req: httpMocks.MockRequest<any>;
  let res: httpMocks.MockResponse<any>;

  beforeEach(() => {
    req = httpMocks.createRequest();
    res = httpMocks.createResponse();
  });

  it(`should call adpayRedirectHandlerV2`, () => {
    req.url =
      '/api/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect/payment-gateway-response-redirect/abcd1234';
    req.body = {
      paymentid: '1234',
      trandata: {
        paymentTranId: 'abcd',
      },
    };

    adpayRedirectHandlerV2(req, res);
  });

  it(`should call adpayRedirectHandlerV2 with url terminated by slash`, () => {
    req.url =
      '/api/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect/payment-gateway-response-redirect/abcd1234/';
    req.body = {
      paymentid: '1234',
      trandata: {
        paymentTranId: 'abcd',
      },
    };

    adpayRedirectHandlerV2(req, res);
  });

  it(`should call adpayRedirectHandlerV2 without body`, () => {
    req.url =
      '/api/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect/payment-gateway-response-redirect/abcd1234';
    req.body = null;

    adpayRedirectHandlerV2(req, res);
  });
});
