import { Request, Response } from 'express';
import config from 'config';
import bala3nadhLogger from 'server/utils/logger';
import ajaxClient from 'server/services/ajaxClient';

const logger = bala3nadhLogger.getService();

const adpayRedirectHandlerV2 = async (req: Request, res: Response) => {
  // Example Gateway Return Url = http://localhost:3000/journeys/journey-template/api/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect/payment-gateway-response-redirect/abcd1234

  logger.info('request Url ==>', req.url);
  const { body } = req;
  const splitArray = req.url.split('/');

  let serviceName = '';
  let pageName = '';
  let journey = '';
  let journeyId = '';
  let stageId = '';
  let instanceId = '';
  const workbenchVersion = splitArray[2];
  const workbenchUniqueId = splitArray[3];

  if (splitArray[4] === 'j') {
    journey = splitArray[4];
    journeyId = splitArray[5];
    stageId = splitArray[6];
    instanceId = splitArray[7];
    serviceName = splitArray[8];
    pageName = splitArray[9];
  } else {
    serviceName = splitArray[4];
    pageName = splitArray[5];
  }

  const transactionId = req.url.endsWith('/')
    ? splitArray[splitArray.length - 2]
    : splitArray[splitArray.length - 1];
  const basePath = config.basePath.endsWith('/')
    ? config.basePath
    : `${config.basePath}/`;

  let messageSend = false;
  if (body.trandata) {
    const trandata = JSON.parse(body.trandata);
    const processDefinitionId = trandata.udf8;
    const businessKey = trandata.udf9;

    if (processDefinitionId && businessKey) {
      const requestConfig: any = {
        url: `${config.adu.host}/bpm/workbench/message/${processDefinitionId}`,
        method: 'POST',
        headers: {
          Accept: 'application/json',
          [config.gateway.header]: process.env.API_GATEWAY_KEY,
        },
        data: {
          businessKey,
          messageName: 'paymentCompleted',
          variables: {
            paymentQueryParameters: `${JSON.stringify(trandata)}`,
          },
        },
      };

      const response: any = await ajaxClient(requestConfig, req as any);
      logger.info('Response ===> ', response);

      messageSend = response.data.success;
    }
  }

  let returnUrl;

  if (splitArray[4] === 'j') {
    returnUrl = `${basePath}${workbenchVersion}/${workbenchUniqueId}/${journey}/${journeyId}/${stageId}/${instanceId}/${serviceName}/${pageName}?transactionId=${transactionId}${
      body ? `&paymentData=${JSON.stringify(body)}` : ''
    }&messageSend=${messageSend}`;
  } else {
    returnUrl = `${basePath}${workbenchVersion}/${workbenchUniqueId}/${serviceName}/${pageName}?transactionId=${transactionId}${
      body ? `&paymentData=${JSON.stringify(body)}` : ''
    }&messageSend=${messageSend}`;
  }
  logger.info('adpayRedirectHandlerV2 - FE Return URL ==>', returnUrl);

  // FE Return URL ==> /journeys/journey-template/v5/RwEZCXQUpPmwuIx142vd0dIcwpox/get-tourist-guide-license/payment-redirect?transactionId=abcd1234&paymentData=undefined

  res.redirect(303, returnUrl);
};

export default adpayRedirectHandlerV2;
