import { ioMemoryClient } from 'server/utils/ioMemoryClient';
import graphqlResponseHandler from 'server/utils/graphqlResponseHandler';
import * as repo from './index';

jest.mock('server/utils/ioMemoryClient', () => ({
  ioMemoryClient: { query: jest.fn(), mutate: jest.fn() },
}));
const req: any = {};

jest.mock('server/utils/graphqlResponseHandler', () => jest.fn());

describe('ioMemory repo', () => {
  const mockApolloQuery = ioMemoryClient.query as jest.MockedFunction<
    typeof ioMemoryClient.query
  >;

  const mockApolloMutate = ioMemoryClient.mutate as jest.MockedFunction<
    typeof ioMemoryClient.mutate
  >;

  it('getCacheByKey should work correctly ', async () => {
    const mockResult = { data: 'data' } as any;
    mockApolloQuery.mockResolvedValue(mockResult);
    await repo.getCacheByKey(req, '1');
    expect(graphqlResponseHandler).toHaveBeenCalledWith(mockResult);
  });

  it('setCache should work correctly ', async () => {
    const mockResult = { data: 'data' } as any;
    mockApolloMutate.mockResolvedValue(mockResult);
    await repo.setCache(req, '1', {});
    expect(graphqlResponseHandler).toHaveBeenCalledWith(mockResult);
  });
});
