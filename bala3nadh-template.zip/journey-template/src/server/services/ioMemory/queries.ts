import gql from 'graphql-tag';

const getCacheByKey = gql`
  query getCacheByKey($key: String!) {
    cacheByKey(key: $key) {
      data
    }
  }
`;

const setCache = gql`
  mutation setCache($data: JSON!, $key: String!) {
    setCache(data: $data, key: $key) {
      key
      data
    }
  }
`;

export default {
  getCacheByKey,
  setCache,
};
