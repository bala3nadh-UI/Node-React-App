import { Request } from 'express';
import graphqlResponseHandler from 'server/utils/graphqlResponseHandler';
import { ioMemoryClient } from 'server/utils/ioMemoryClient';
import queries from './queries';

/**
 * list of cached data s
 * @param {Request} req
 * @param {string} key
 * @returns {Promise}
 */
export const getCacheByKey = async (req: Request, key: string) => {
  const payload = await ioMemoryClient.query(
    {
      query: queries.getCacheByKey,
      variables: {
        key,
      },
    },
    req,
  );

  return graphqlResponseHandler(payload);
};

/**
 * save cache users to cache
 * @param {Request} req
 * @param {string} key
 * @param {any} data
 * @returns {Promise}
 */
export const setCache = async (req: Request, key: string, data: any) => {
  const payload = await ioMemoryClient.mutate(
    {
      mutation: queries.setCache,
      variables: {
        key,
        data,
      },
    },
    req,
  );
  return graphqlResponseHandler(payload);
};
