import bala3nadhRequest from '@bala3nadh/request';
import bala3nadhLogger from 'server/utils/logger';
import config from 'config';

const logger = bala3nadhLogger.getService();

export default bala3nadhRequest({ logger, appName: config.projectName });
