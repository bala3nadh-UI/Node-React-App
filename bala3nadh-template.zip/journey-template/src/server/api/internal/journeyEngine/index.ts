import express, { NextFunction, Request, Response } from 'express';
import journeyEngine from 'server/journey-engine';
import { createErrorResponse } from '@bala3nadh/response';
import {
  getJourneyInstanceSchema,
  getJourneyInstancesSchema,
  createJourneyInstanceSchema,
  cancelJourneyInstanceSchema,
  updateJourneyInstanceSchema,
  getNextActionsSchema,
  createJourneyInstanceWithHelperSchema,
} from './schema';
import { variablesInjectionHandlerFromBody } from '../../proxy/handlers/variablesInjectionHandler';

const router = express.Router();

const validationMiddleware = (schema: any) => (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const { error: validationError } = schema.validate(req.body);
  if (validationError) {
    return createErrorResponse(req, res, 500, 'Invalid data in request body');
  }
  return next();
};

router.post(
  '/createJourneyInstance',
  validationMiddleware(createJourneyInstanceSchema),
  variablesInjectionHandlerFromBody,
  journeyEngine.api.createJourneyInstance,
);
router.post(
  '/getJourneyInstances',
  validationMiddleware(getJourneyInstancesSchema),
  variablesInjectionHandlerFromBody,
  journeyEngine.api.getJourneyInstances,
);
router.post(
  '/getJourneyInstance',
  validationMiddleware(getJourneyInstanceSchema),
  variablesInjectionHandlerFromBody,
  journeyEngine.api.getJourneyInstance,
);
router.post(
  '/cancelJourneyInstance',
  validationMiddleware(cancelJourneyInstanceSchema),
  variablesInjectionHandlerFromBody,
  journeyEngine.api.cancelJourneyInstance,
);

router.post(
  '/updateJourneyInstance',
  validationMiddleware(updateJourneyInstanceSchema),
  variablesInjectionHandlerFromBody,
  journeyEngine.api.updateJourneyInstance,
);

router.post(
  '/getNextActions',
  validationMiddleware(getNextActionsSchema),
  variablesInjectionHandlerFromBody,
  journeyEngine.api.getNextActions,
);

router.post(
  '/createJourneyInstanceWithHelper',
  validationMiddleware(createJourneyInstanceWithHelperSchema),
  variablesInjectionHandlerFromBody,
  journeyEngine.api.createJourneyInstanceWithHelper,
);

export default router;
