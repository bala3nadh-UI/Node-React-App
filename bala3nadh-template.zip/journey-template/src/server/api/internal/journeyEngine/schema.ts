import joi from 'joi';

const getJourneyInstanceSchema = joi.object({
  journeyId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  forceRecache: joi.boolean().required(),
  preview: joi.boolean().required(),
  userUuid: joi.string().valid('{{user.User Unique Identifier}}').required(),
  lang: joi.string().valid('en', 'ar', 'EN', 'AR'),
  instanceId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
});

const getJourneyInstancesSchema = joi.object({
  journeyCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  userUuid: joi.string().valid('{{user.User Unique Identifier}}').required(),
  lang: joi.string().valid('en', 'ar', 'EN', 'AR'),
});

const createJourneyInstanceSchema = joi.object({
  journeyId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  userUuid: joi.string().valid('{{user.User Unique Identifier}}').required(),
  journeyNameEn: joi
    .string()
    .regex(/^[a-z0-9AA-Z_, .-]+$/)
    .required(),
  journeyNameAr: joi
    .string()
    .regex(/^[a-z0-9AA-Z\u0600-\u06FF_, .-]+$/)
    .required(),
  instanceStatusId: joi.string().equal('INPROCESS').required(),
  sharedJourneyContext: joi.string().regex(/^[a-z0-9AA-Z_, .|-]+$/),
});

const cancelJourneyInstanceSchema = joi.object({
  journeyId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  instanceId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  userUuid: joi.string().valid('{{user.User Unique Identifier}}').required(),
  journeyNameEn: joi
    .string()
    .regex(/^[a-z0-9AA-Z_, .-]+$/)
    .required(),
  journeyNameAr: joi
    .string()
    .regex(/^[a-z0-9AA-Z\u0600-\u06FF_, .-]+$/)
    .required(),
});

const updateJourneyInstanceSchema = joi.object({
  instanceId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  userUuid: joi.string().valid('{{user.User Unique Identifier}}').required(),
  journeyNameEn: joi
    .string()
    .regex(/^[a-z0-9AA-Z_, .-]+$/)
    .required(),
  journeyNameAr: joi
    .string()
    .regex(/^[a-z0-9AA-Z\u0600-\u06FF_, .-]+$/)
    .required(),
  instanceName: joi
    .string()
    .regex(/^[a-z0-9AA-Z\u0600-\u06FF_, ./-]+$/)
    .required(),
  instanceStatusId: joi.string().equal('INPROCESS').required(),
});

const getNextActionsSchema = joi.object({
  journeyId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  forceRecache: joi.boolean().required(),
  preview: joi.boolean().required(),
  userUuid: joi.string().valid('{{user.User Unique Identifier}}').required(),
  lang: joi.string().valid('en', 'ar', 'EN', 'AR'),
  instanceId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  stageId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  itemId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
});

const createJourneyInstanceWithHelperSchema = joi.object({
  journeyId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  userUuid: joi.string().valid('{{user.User Unique Identifier}}').required(),
  customData: joi.object().optional(),
});

export {
  getJourneyInstanceSchema,
  getJourneyInstancesSchema,
  createJourneyInstanceSchema,
  cancelJourneyInstanceSchema,
  updateJourneyInstanceSchema,
  getNextActionsSchema,
  createJourneyInstanceWithHelperSchema,
};
