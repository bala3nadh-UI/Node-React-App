import express, { Request, Response } from 'express';
import requestSanitizer from 'server/middlewares/requestSanitizer';
import {
  createErrorResponse,
  createSuccessResponse,
} from 'server/utils/response-utils';
import { validate } from 'express-validation';
import { getDraftByDraftId, upsertDraft } from 'server/services/io/savedDraft';
import { getCacheByKey, setCache } from 'server/services/ioMemory';
import sizeLimiter from 'server/middlewares/sizeLimiter';
import { load as loadSchema, save as saveSchema } from './schema';

interface SQConfigRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo: any;
  };
}

const getCachedDraft = async (req: Request, id: string, userId: string) => {
  try {
    const cacheKey = `draft-{${userId}}{${id}}`;
    return getCacheByKey(req, cacheKey);
  } catch (error) {
    return null;
  }
};

const saveToCache = async (
  req: Request,
  id: string,
  userId: string,
  data: any,
) => {
  const cacheKey = `draft-{${userId}}{${id}}`;
  return setCache(req, cacheKey, data);
};
const getDraft = async (req: Request, id: string, userId: string) => {
  const cachedDraft = await getCachedDraft(req, id, userId);
  if (cachedDraft) return cachedDraft.data;
  const draft = await getDraftByDraftId(req, id);
  saveToCache(req, id, userId, draft);
  return draft;
};
export const load: any = async (req: SQConfigRequest, res: Response) => {
  try {
    const userId = req.session.bala3nadhUserInfo['User Unique Identifier'];
    const { id } = req.params;
    const draft = await getDraft(req, id, userId);
    if (draft?.userId !== userId)
      return createErrorResponse(req, res, 'Draft not exist', {}, 422);
    return createSuccessResponse(
      res,
      'Successfully loading saved draft',
      draft,
    );
  } catch (error) {
    return createErrorResponse(req, res, 'Failed to load draft', error, 500);
  }
};

export const save: any = async (req: SQConfigRequest, res: Response) => {
  try {
    const userId = req.session.bala3nadhUserInfo['User Unique Identifier'];
    const { id, applicationId } = req.params;
    const data = req.body;
    let draft = await getDraft(req, id, userId);
    if (!draft) {
      draft = {
        userId,
        applicationId,
        draftId: id,
      };
    }
    if (draft.userId !== userId)
      return createErrorResponse(req, res, 'Draft not exist', {}, 422);
    draft.data = data;
    delete draft.id;
    const updatedDraft = await upsertDraft(req, id, draft);
    saveToCache(req, id, userId, draft);
    return createSuccessResponse(
      res,
      'Successfully saving draft',
      updatedDraft,
    );
  } catch (error) {
    return createErrorResponse(req, res, 'Failed to save draft', error, 500);
  }
};
const router = express.Router();

router.get(
  '/load/:applicationId/:id',
  validate(loadSchema, {}, { abortEarly: false }),
  load,
);
router.post(
  '/save/:applicationId/:id',
  sizeLimiter(5 * 1024, 'Data exceeds 5kb limit to stored in draft'),
  validate(saveSchema, {}, { abortEarly: false }),
  requestSanitizer,
  save,
);

export default router;
