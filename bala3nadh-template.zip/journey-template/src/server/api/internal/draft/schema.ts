import joi from 'joi';

const saveStringRegex = /[\w-]*/;

export const load = {
  params: joi.object({
    id: joi.string().pattern(saveStringRegex).required(),
    applicationId: joi.string().pattern(saveStringRegex).required(),
  }),
};

export const save = {
  params: joi.object({
    id: joi.string().pattern(saveStringRegex).required(),
    applicationId: joi.string().pattern(saveStringRegex).required(),
  }),
  body: joi.object({}).unknown(),
};
