import httpMocks from 'node-mocks-http';
import {
  createErrorResponse,
  createSuccessResponse,
} from 'server/utils/response-utils';
import * as ioModule from 'server/services/io/savedDraft';
import * as ioMemoryModula from 'server/services/ioMemory';
import { load, save } from '.';

jest.mock('server/utils/response-utils', () => ({
  createErrorResponse: jest.fn(),
  createSuccessResponse: jest.fn(),
}));

jest.mock('server/services/io/savedDraft');

jest.mock('server/services/ioMemory');
// import { getDraftByDraftId, upsertDraft } from 'server/services/io/savedDraft';
// import { getCacheByKey, setCache } from 'server/services/ioMemorey';
describe('draft apis', () => {
  let req: any;
  let res: any;
  let next: any;
  const io: any = ioModule;
  const ioMemory: any = ioMemoryModula;

  beforeEach(() => {
    req = httpMocks.createRequest();
    res = {
      header: jest.fn(),
      set: jest.fn(),
      send: jest.fn(),
      json: jest.fn(),
    };
    next = jest.fn();

    req.log = {
      error: jest.fn(),
    };
  });

  describe('load', () => {
    it('should run successfully', async () => {
      req.session = { bala3nadhUserInfo: { 'User Unique Identifier': '1' } };

      io.getDraftByDraftId.mockResolvedValueOnce({
        id: 1,
        userId: '1',
      });
      await load(req, res, next);
      expect(createSuccessResponse).toHaveBeenCalled();
    });

    it('should return 422', async () => {
      req.session = { bala3nadhUserInfo: { 'User Unique Identifier': '12' } };
      ioMemory.getCacheByKey.mockResolvedValueOnce({
        data: {
          id: 1,
          userId: '1',
        },
      });
      await load(req, res, next);
      expect(createErrorResponse).toHaveBeenCalled();
    });
    it('it should fail', async () => {
      await load(req, res, next);
      expect(createErrorResponse).toHaveBeenCalled();
    });
  });

  describe('save', () => {
    it('should run successfully', async () => {
      req.session = { bala3nadhUserInfo: { 'User Unique Identifier': '1' } };
      req.body = {};
      io.getDraftByDraftId.mockResolvedValueOnce({
        id: 1,
        userId: '1',
      });
      await load(req, res, next);
      expect(createSuccessResponse).toHaveBeenCalled();
    });

    it('should return 422', async () => {
      req.session = { bala3nadhUserInfo: { 'User Unique Identifier': '12' } };
      req.body = {};
      ioMemory.getCacheByKey.mockResolvedValueOnce({
        data: {
          id: 1,
          userId: '1',
        },
      });
      await save(req, res, next);
      expect(createErrorResponse).toHaveBeenCalled();
    });
  });
});
