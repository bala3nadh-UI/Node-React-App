import express from 'express';
import oop from 'server/oop';

import smartPassRouter from 'server/api/internal/smartpass';
import cmsRouter from 'server/api/internal/cms';
import errorLogging from 'server/api/internal/errorLogging';
import aduProxyRouter from 'server/api/proxy/adu';
import msProxyRouter from 'server/api/proxy/ms';
import authMiddleware from 'server/middlewares/authMiddleware';
import proxyAuthMiddleware from 'server/middlewares/proxyAuthMiddleware';
import fileRouter from 'server/api/internal/file';
import draftRouter from 'server/api/internal/draft';
import journeyEngineRouter from 'server/api/internal/journeyEngine';
import bodyParser from 'body-parser';

const router = express.Router();

router.use((req, res, next) => {
  req.log.info('Internal API');
  next();
});

/**
 * Internal API
 */
router.use(
  '/proxy/ms-call',
  proxyAuthMiddleware('protected'),
  bodyParser.json({ limit: '20mb' }),
  msProxyRouter,
);
router.use(
  '/proxy',
  proxyAuthMiddleware('protected'),
  bodyParser.json(),
  aduProxyRouter,
);
router.use('/smartpass', smartPassRouter);
router.use('/cms', cmsRouter);
router.use('/error-logging', errorLogging);
router.use('/file', fileRouter);
router.use('/draft', authMiddleware, draftRouter);
router.use('/once-only', oop.router);
router.use('/journey-engine', authMiddleware, journeyEngineRouter);

export default router;
