import httpMocks from 'node-mocks-http';
import multer from 'multer';
import documentStore from 'server/services/documentStore';
import { createErrorResponse } from 'server/utils/response-utils';
import { IVariables } from '@bala3nadh/app-composer';
import fs from 'fs';
import { testBase64File } from './test.base64.file';
import { getFileHandler, fileUploadHandler, uploadMiddleware } from './index';

jest.mock('server/utils/response-utils', () => ({
  createErrorResponse: jest.fn(),
}));
jest.mock('server/services/documentStore');
jest.mock('stream');
jest.mock('file-type');
jest.mock('multer');
jest.mock('fs');

describe('File retreive/upload hanlders', () => {
  let mockMulter: any;
  let req: any;
  let res: any;
  let next: any;
  const mockedFs: any = fs;
  beforeAll(() => {
    mockMulter = multer;
  });

  mockedFs.unlinkSync = jest.fn();
  beforeEach(() => {
    req = httpMocks.createRequest();
    res = {
      header: jest.fn(),
      set: jest.fn(),
      send: jest.fn(),
      json: jest.fn(),
    };
    next = jest.fn();

    req.log = {
      error: jest.fn(),
    };
  });

  describe('getFileHandler', () => {
    it(`should detect mime type`, async () => {
      req.params = {
        filename: 'untitled.png__123123',
      };
      (documentStore.getFile as jest.MockedFunction<any>).mockResolvedValue(
        testBase64File,
      );
      await getFileHandler(req, res, next);
      expect(res.header).toBeCalled();
      expect(res.send).toBeCalled();
    });

    it(`should not detect mime type`, async () => {
      req.file = {};
      req.params = {
        filename: 'workbenchFile__untitled.png__sssdd',
      };
      (documentStore.getFile as jest.MockedFunction<any>).mockResolvedValue(
        testBase64File,
      );
      await getFileHandler(req, res, next);
      expect(res.send).toBeCalled();
    });

    it(`should throw error`, async () => {
      req.params = {
        filename: 'untitled.png',
      };
      (documentStore.getFile as jest.MockedFunction<any>).mockRejectedValue(
        new Error('test'),
      );
      await getFileHandler(req, res, next);
      expect(req.log.error).toBeCalled();
      expect(next).toBeCalled();
    });
  });

  describe('uploadMiddleware', () => {
    it('should handle upload success', async () => {
      mockMulter.mockImplementationOnce(() => {
        return {
          single() {
            return (reqArg: IVariables) => {
              // eslint-disable-next-line no-param-reassign
              reqArg.file = [
                {
                  originalname: 'sample.name',
                  mimetype: 'sample.type',
                  path: 'sample.url',
                },
              ];
              return next();
            };
          },
        };
      });
      await uploadMiddleware(req, res, next);
      expect(createErrorResponse).not.toHaveBeenCalled();
      expect(next).toHaveBeenCalled();
    });
  });

  describe('fileUploadHandler', () => {
    it('should pass', async () => {
      req.file = {
        originalname: 'www.png',
        buffer: [],
      };
      req.body = {
        file: 'file',
        filename: 'filename',
      };
      (documentStore.savePlain as jest.MockedFunction<any>).mockResolvedValue(
        1,
      );

      await fileUploadHandler(req, res, next);

      expect(res.json).toBeCalledWith({ fileId: 1 });
    });

    it('should throw exception', async () => {
      req.body = {
        file: 'file',
        filename: 'filename',
      };
      (documentStore.savePlain as jest.MockedFunction<any>).mockRejectedValue(
        1,
      );

      await fileUploadHandler(req, res, next);

      expect(req.log.error).toBeCalled();
      expect(next).toBeCalled();
    });
  });
});
