import express, { Request, Response, NextFunction } from 'express';
import documentStore from 'server/services/documentStore';
import stream from 'stream';
import multer from 'multer';
import { createErrorResponse } from 'server/utils/response-utils';
import sanitizeFilename from 'sanitize-filename';
import mimeTypes from 'mime-types';
import os from 'os';
import { unlinkSync } from 'fs';

type DownloadedFile = {
  name: string;
  content: Buffer;
};
const router = express.Router();

const allowedMimeTypesForView = [
  'application/pdf',
  'image/bmp',
  'image/jpeg',
  'image/png',
];

// TO BE CUSTOMISED BY ADU
// The entire list of allowed mimetypes allowed by doc store
const allowedMimeTypesForUpload = [
  'application/pdf',
  'x-gis/x-shapefile',
  'application/x-dbf',
  'application/x-sbx',
  'application/vnd.google-earth.kmz',
  'application/vnd.dynageo',
  'image/jpeg',
  'image/png',
  'application/vnd.ms-powerpoint', // ppt
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/msword', // doc
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // docx
  'video/x-msvideo',
  'video/mp4',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // xlsx
  'application/vnd.ms-excel',
  'application/zip', // zip
  'text/csv', // csv
  'application/octet-stream', // xls
  'image/tiff', // tiff
  'text/plain', // txt
  'image/bmp', // bmp
];

// base64 content
async function oldFileDownloadHandler(
  fileId: string,
  req: Request,
): Promise<DownloadedFile> {
  const file = await documentStore.getFile(fileId, req);
  const base64File = file.replace(/^data:.*;base64,/, '');
  const fileContents = Buffer.from(base64File, 'base64');
  const filename = fileId.split('__')[0] || fileId;
  return {
    content: fileContents,
    name: filename,
  };
}

// array of buffer content
async function newFileDownloadHandler(
  fileId: string,
  req: Request,
): Promise<DownloadedFile> {
  const file = await documentStore.getFile(fileId, req, 'arraybuffer');
  const [, filename] = fileId.split('__');

  return {
    content: file,
    name: filename,
  };
}

const fileFilter: any = (
  req: Request,
  file: Express.Multer.File,
  callback: (error: Error | null, acceptFile: boolean) => void,
  // eslint-disable-next-line consistent-return
) => {
  req.log.info('File details', {
    originalname: file.originalname,
    mimetype: file.mimetype,
    fileSize: file.size,
  });

  if (!allowedMimeTypesForUpload.includes(file.mimetype.toLowerCase())) {
    req.log.error('File type not supported');
    return callback(new Error('File type not supported'), false);
  }

  req.log.info('File type validation succeeded');
  callback(null, true);
};

export const uploadMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const upload = multer({
    dest: os.tmpdir(),
    limits: {
      fileSize: 20 * 1024 * 1024, // 20 MB
    },
    fileFilter,
  });

  upload.single('file')(req, res, (error: any) => {
    if (error) {
      return createErrorResponse(req, res, 'Failed to upload file', error, 400);
    }

    req.log.info('File should be available in req.file');
    return next();
  });
};

export async function getFileHandler(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const { filename } = req.params;
    let file: DownloadedFile;
    if (filename.includes('workbenchFile__'))
      file = await newFileDownloadHandler(filename, req);
    else file = await oldFileDownloadHandler(filename, req);
    const mime = mimeTypes.lookup(file.name).toString();
    if (allowedMimeTypesForView.includes(mime)) {
      res.header('Content-Type', mime);
      res.send(file.content);
    } else {
      const readStream = new stream.PassThrough();
      readStream.end(file.content);
      res.set('Content-disposition', `attachment; filename=${file.name}`);
      res.set('Content-Type', 'application/octet-stream');
      readStream.pipe(res);
    }
  } catch (err) {
    req.log.error('Could not get file from document store.');
    next(err);
  }
}

router.get('/:filename', getFileHandler);

export async function fileUploadHandler(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const { file } = req;
    let filename = sanitizeFilename(file.originalname);
    filename = `workbenchFile__${filename}`;
    const fileId = await documentStore.savePlain(file.path, filename, req);
    unlinkSync(file.path);
    res.json({ fileId });
  } catch (err) {
    req.log.error('Could not save file in document store.');
    next(err);
  }
}

router.post('/fu-avs/upload', uploadMiddleware, fileUploadHandler);

export default router;
