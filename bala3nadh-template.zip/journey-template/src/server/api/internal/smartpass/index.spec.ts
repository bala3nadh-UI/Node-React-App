import httpMocks from 'node-mocks-http';
import smartpassParts from 'server/smartpass';
import { getDownloadSignedDocument, postDownloadSignedDocument } from '.';

jest.mock('server/smartpass');

describe('Smartpass router', () => {
  let req: any;
  let res: any;
  let nextFn: any;

  beforeEach(() => {
    // eslint-disable-next-line global-require
    req = httpMocks.createRequest();
    res = httpMocks.createResponse();
    res.send = jest.fn();
    res.end = jest.fn();
    res.writeHead = jest.fn();
    nextFn = jest.fn();
  });

  afterEach(() => jest.resetModules());

  it('should create correct route to download signed document using POST method', async () => {
    (smartpassParts.api.uaepass
      .downloadSignedDocument as jest.Mock).mockResolvedValue('test data');
    await postDownloadSignedDocument(req, res, nextFn);

    expect(
      smartpassParts.api.uaepass.downloadSignedDocument,
    ).toHaveBeenCalledWith(req, res, nextFn);
    expect(res.send).toHaveBeenCalledWith({ success: true, data: 'test data' });
  });

  it('should create correct route to download signed document using GET method', async () => {
    (smartpassParts.api.uaepass
      .downloadSignedDocument as jest.Mock).mockResolvedValue({
      document: 'test data',
    });
    req.query = {
      processId: 123,
    };
    await getDownloadSignedDocument(req, res, nextFn);

    req.body = {
      processId: 123,
    };
    expect(
      smartpassParts.api.uaepass.downloadSignedDocument,
    ).toHaveBeenCalledWith(req, res, nextFn);
    expect(res.writeHead).toHaveBeenCalledWith(200, {
      'Content-Type': `application/pdf`,
      'Content-Disposition': `attachment; filename="Sign Document name.pdf"`,
    });
    expect(res.end).toHaveBeenCalledWith(expect.any(Buffer));
  });
});
