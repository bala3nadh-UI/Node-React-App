import config from 'config';
import express, { Request, Response, NextFunction } from 'express';
import smartpassParts from 'server/smartpass';
import { uploadMiddleware } from '../file';

const router = express.Router();

router.get('/login', smartpassParts.api.login);
router.get('/logout', smartpassParts.api.logout);

if (config.demoLogin) {
  router.get('/demo-login', smartpassParts.api.demoLogin);
  router.get('/demo-logout', smartpassParts.api.demoLogout);
  router.get('/userInfo', smartpassParts.api.userInfo);
}

/* Document Signing */

router.post(
  '/sign-document',
  uploadMiddleware,
  smartpassParts.api.uaepass.signDocument,
);

export const postDownloadSignedDocument = async (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const docData = await smartpassParts.api.uaepass.downloadSignedDocument(
    req,
    res,
    next,
  );
  return res.send({ success: true, data: docData });
};

router.post('/download-signed-document', postDownloadSignedDocument);

export const getDownloadSignedDocument = async (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  req.body = {
    processId: req.query.processId,
  };

  try {
    const docData: any = await smartpassParts.api.uaepass.downloadSignedDocument(
      req,
      res,
      next,
    );
    let docTitle: any = req.query.documentTitle || 'Sign Document name';
    docTitle = docTitle.endsWith('.pdf') ? docTitle : `${docTitle}.pdf`;

    res.writeHead(200, {
      'Content-Type': `application/pdf`,
      'Content-Disposition': `attachment; filename="${docTitle}"`,
    });
    const downloadDoc = Buffer.from(docData.document, 'base64');
    res.end(downloadDoc);
  } catch (e) {
    next(e);
  }
};

router.get('/download-signed-document', getDownloadSignedDocument);

export default router;
