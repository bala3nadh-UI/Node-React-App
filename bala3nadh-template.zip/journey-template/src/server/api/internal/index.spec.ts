import express from 'express';

jest.mock('express');
jest.mock('server/api/internal/smartpass', () => jest.fn());
jest.mock('server/api/internal/cms', () => jest.fn());
jest.mock('server/api/internal/errorLogging', () => jest.fn());
jest.mock('server/api/proxy/ms', () => jest.fn());
jest.mock('server/api/proxy/adu', () => jest.fn());
jest.mock('server/middlewares/proxyAuthMiddleware', () => jest.fn());
jest.mock('server/api/internal/file', () => jest.fn());
jest.mock('server/api/internal/journeyEngine', () => jest.fn());
jest.mock('body-parser', () => ({
  json: jest.fn(),
  text: jest.fn(),
  raw: jest.fn(),
}));
jest.mock('server/oop', () => ({
  router: jest.fn(),
}));

const existsInCallsArray = (arr: [], searchElement: string) => {
  return arr.findIndex((el: string[]) => el[0] === searchElement) !== -1;
};

describe('Internal router', () => {
  let expressRouter: any = null;
  beforeEach(() => {
    expressRouter = {
      use: jest.fn(),
      get: jest.fn(),
      post: jest.fn(),
    };
    (express.Router as jest.MockedFunction<any>).mockReturnValue(expressRouter);
  });

  it(`assign routes`, () => {
    // eslint-disable-next-line global-require
    require('./index');
    expect(
      existsInCallsArray(expressRouter.use.mock.calls, '/proxy/ms-call'),
    ).toBe(true);
    expect(existsInCallsArray(expressRouter.use.mock.calls, '/smartpass')).toBe(
      true,
    );
    expect(existsInCallsArray(expressRouter.use.mock.calls, '/cms')).toBe(true);
    expect(
      existsInCallsArray(expressRouter.use.mock.calls, '/error-logging'),
    ).toBe(true);
    expect(existsInCallsArray(expressRouter.use.mock.calls, '/file')).toBe(
      true,
    );
    expect(existsInCallsArray(expressRouter.use.mock.calls, '/once-only')).toBe(
      true,
    );
    expect(
      existsInCallsArray(expressRouter.use.mock.calls, '/journey-engine'),
    ).toBe(true);
  });
});
