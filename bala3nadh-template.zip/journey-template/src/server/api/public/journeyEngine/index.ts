import express from 'express';
import journeyEngine from 'server/journey-engine';

const router = express.Router();

router.post('/getJourneyConfig', journeyEngine.api.getJourneyConfig);

export default router;
