import { Request, Response } from 'express';
import { AdFeedback } from '@bala3nadh/adfeedback';

import config from 'config';
import ajaxClient from 'server/services/ajaxClient';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';

export const adFeedback = new AdFeedback({
  host: config.adFeedbackUrl,
  request: ajaxClient,
  headers: {
    [config.gateway.header]: config.gateway.key,
  },
});

export async function createFeedback(req: Request, res: Response) {
  try {
    const { body } = req;
    const { isMobile, isMobileNative, platform, os, browser, version }: any =
      req.useragent || {};
    const payload = await adFeedback.createAdFeedback(
      {
        surveyType: body.surveyType,
        smileyType: body.smileyType,
        comments: body.comments,
        ratings: body.ratings,
        logUuid: req.logUuid,
        pageUrl: body.pageUrl,
        serviceId: body.serviceId,
        productId: body.productId,
        surveyDateTime: new Date(),
        userAgent: {
          isMobile,
          isMobileNative,
          platform,
          os,
          browser,
          version,
        },
        user: {
          ip: req.ip,
          uuid: (req.session as any)?.bala3nadhUserInfo?.['User Unique Identifier'],
        },
      },
      req,
    );
    createSuccessResponse(res, 'success', payload.data);
  } catch (error) {
    createErrorResponse(req, res, 'Failed to create feedback', error.message);
  }
}
