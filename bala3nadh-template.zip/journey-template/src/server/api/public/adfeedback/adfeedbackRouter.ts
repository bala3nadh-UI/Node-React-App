import express from 'express';
import { createFeedback } from './feedback';
import { createBugReport } from './bugReport';

const router = express.Router();

router.post('/feedbacks', createFeedback);
router.post('/bugReport', createBugReport);

export default router;
