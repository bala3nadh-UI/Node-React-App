import router from './adfeedbackRouter';

describe('adfeedbackRouter', () => {
  it('should define router', () => {
    expect(router).toBeDefined();
  });
});
