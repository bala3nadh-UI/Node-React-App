import { Request, Response } from 'express';
import { createErrorResponse } from 'server/utils/response-utils';
import documentStore from 'server/services/documentStore';
import { getApplicationByReservedPath } from 'server/services/io/application';

const getBundlePrototype = async (req: Request, res: Response) => {
  try {
    let { prototypeId } = req.params;
    const app = await getApplicationByReservedPath(req, prototypeId);
    if (app) prototypeId = app.bundleId;
    const journeyConfig = await documentStore.getFile(
      `bundle.js__${prototypeId}`,
      req,
    );
    res.setHeader('content-type', 'text/javascript');
    return res.send(journeyConfig);
  } catch (error) {
    return createErrorResponse(
      req,
      res,
      'Failed to load journey config',
      error.message,
    );
  }
};

export default getBundlePrototype;
