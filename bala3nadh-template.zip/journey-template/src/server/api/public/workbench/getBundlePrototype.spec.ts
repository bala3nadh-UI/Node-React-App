import httpMocks from 'node-mocks-http';
import { createErrorResponse } from 'server/utils/response-utils';
import getBundlePrototype from 'server/api/public/workbench/getBundlePrototype';
import documentStore from 'server/services/documentStore';
import * as applicationIo from 'server/services/io/application';

jest.mock('server/utils/response-utils');
jest.mock('server/services/documentStore');
jest.mock('server/services/io/application');

describe('public/routes/getBundlePrototype', () => {
  let req: any;
  let res: any;

  const mockGetFile = documentStore.getFile as any;
  const mockedApplicationIo: any = applicationIo;
  beforeEach(() => {
    req = httpMocks.createRequest({
      params: {
        prototypeId: 'prototypeId',
      },
    });
    res = httpMocks.createResponse();
    req.log = {
      error: jest.fn(),
    };
  });

  it('should do', async () => {
    mockGetFile.mockImplementationOnce(() => Promise.resolve());
    mockedApplicationIo.getApplicationByReservedPath = jest
      .fn()
      .mockResolvedValue({ bundleId: '22' });
    await getBundlePrototype(req, res);

    // eslint-disable-next-line no-underscore-dangle
    expect(res._getHeaders()['content-type']).toEqual('text/javascript');
  });

  it('should do', async () => {
    mockGetFile.mockImplementationOnce(() => Promise.resolve());
    mockedApplicationIo.getApplicationByReservedPath = jest
      .fn()
      .mockResolvedValue(null);
    await getBundlePrototype(req, res);

    // eslint-disable-next-line no-underscore-dangle
    expect(res._getHeaders()['content-type']).toEqual('text/javascript');
  });

  it('should call createErrorResponse()', async () => {
    const mockError = 'error';
    const mockErr = new Error(mockError);

    mockGetFile.mockImplementationOnce(() => Promise.reject(mockErr));

    await getBundlePrototype(req, res);

    expect(createErrorResponse).toHaveBeenCalled();
  });
});
