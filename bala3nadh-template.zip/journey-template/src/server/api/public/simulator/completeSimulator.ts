import { Request, Response } from 'express';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { adlockerUpsertApplication } from '../smartQuestionnaire/utils';
import { completeSimulatorSchema } from './schema';

const completeSimulator = async (req: Request, res: Response) => {
  try {
    const { error: validationError } = completeSimulatorSchema.validate(
      req.body,
    );
    if (validationError) {
      return createErrorResponse(
        req,
        res,
        'Invalid data in request body',
        validationError,
      );
    }
    const completeSimulatorResponse = await adlockerUpsertApplication(
      'INSERT',
      'Completed',
      req,
    );
    if (completeSimulatorResponse.status === 'error') {
      return createErrorResponse(
        req,
        res,
        'Failed to update ADLocker record',
        process.env.STAGING === 'true' ? completeSimulatorResponse.message : '',
      );
    }
    return createSuccessResponse(res, 'Success', {
      ...completeSimulatorResponse,
      success: true,
    });
  } catch (ex) {
    return createErrorResponse(
      req,
      res,
      'Failed to update ADLocker record',
      process.env.STAGING === 'true' ? ex?.message : '',
    );
  }
};

export default completeSimulator;
