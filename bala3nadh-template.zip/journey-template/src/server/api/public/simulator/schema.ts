import joi from 'joi';

const completeSimulatorSchema = joi.object({
  simulatorCmsId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  refKey: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  refCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyInstanceId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyStage: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyStageNameEn: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,. -]+$/)
    .required(),
  journeyStageNameAr: joi
    .string()
    .regex(/^[a-z0-9A-Z\u0600-\u06FF_, .-]+$/)
    .required(),
  journeyStageOrder: joi.number().required(),
});

export { completeSimulatorSchema };
