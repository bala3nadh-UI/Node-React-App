import express from 'express';

import completeSimulator from './completeSimulator';

const router = express.Router();

router.post('/completeSimulator', completeSimulator);

export default router;
