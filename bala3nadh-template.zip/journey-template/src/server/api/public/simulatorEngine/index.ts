import express from 'express';
import simulatorEngine from 'server/simulator-engine';

const router = express.Router();

router.post('/getSimulatorConfig', simulatorEngine.api.getConfig);
router.post('/getStepDetails', simulatorEngine.api.getStepDetails);
router.post('/getProcessedPdf', simulatorEngine.api.getProcessPdf);
router.post('/createSimulatorInstance', simulatorEngine.api.createInstance);

export default router;
