import express from 'express';

jest.mock('express');
jest.mock('server/simulator-engine');

const existsInCallsArray = (arr: [], searchElement: string) => {
  return arr.findIndex((el: string[]) => el[0] === searchElement) !== -1;
};

describe('simulator-engine router', () => {
  let expressRouter: any = null;
  beforeEach(() => {
    expressRouter = {
      get: jest.fn(),
      post: jest.fn(),
    };
    (express.Router as jest.MockedFunction<any>).mockReturnValue(expressRouter);
  });

  it(`assign routes`, () => {
    // eslint-disable-next-line global-require
    require('./index');
    expect(
      existsInCallsArray(expressRouter.post.mock.calls, '/getSimulatorConfig'),
    ).toBe(true);
  });
});
