import { Request, Response } from 'express';
import fs from 'fs';
import sanitizeFilename from 'sanitize-filename';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';

const getServiceById = (req: Request, res: Response) => {
  const { id } = req.params;
  const sanitizedId = sanitizeFilename(id);

  fs.readFile(
    `public/gsp/${sanitizedId}.json`,
    'utf8',
    (fileReadErr, service) => {
      let message;

      if (!service || service === 'undefined' || fileReadErr) {
        message = 'GSP Services not found';

        return createErrorResponse(
          req,
          res,
          message,
          fileReadErr ? fileReadErr.message : 'No errors while reading cache',
          404,
        );
      }

      return createSuccessResponse(res, 'Success', JSON.parse(service));
    },
  );
};

export default getServiceById;
