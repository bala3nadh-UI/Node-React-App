import httpMocks from 'node-mocks-http';
import { createSuccessResponse } from 'server/utils/response-utils';
import getServiceByPath from 'server/api/public/service/getServiceByPath';
import request from 'server/services/ajaxClient';

jest.mock('server/utils/response-utils');
jest.mock('server/services/ajaxClient');

describe('public/routes/getServiceByPath', () => {
  let req: any;
  let res: any;

  const mockRequest = request as jest.MockedFunction<any>;

  beforeEach(() => {
    req = httpMocks.createRequest({
      params: {
        path: 'path',
      },
    });
    res = httpMocks.createResponse();
    req.log = {
      error: jest.fn(),
    };
  });
  it('should request for service when cache is missing', async () => {
    const mockData = {
      data: {},
    };
    mockRequest.mockResolvedValue(mockData);

    await getServiceByPath(req, res);

    expect(createSuccessResponse).toHaveBeenCalled();
  });
});
