import { Request, Response } from 'express';
import request from 'server/services/ajaxClient';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { get } from 'lodash';
import authConfig from 'config/authConfig';
import config from 'config';

// eslint-disable-next-line consistent-return
const getServiceByPath = (req: Request, res: Response) => {
  const { path } = req.params;
  const { recache } = req.query;

  const servicePathArr = path.split('_');
  const lang = servicePathArr.pop();
  request(
    {
      url: `${config.gsp.host}${config.gsp.servicesAll.serviceByPath}`,
      method: 'POST',
      headers: {
        [authConfig.apiGateway.header]: authConfig.apiGateway.key,
      },
      data: {
        servicePath: servicePathArr.join('/'),
        lang,
        recache,
      },
    },
    req,
  )
    .then(response => {
      const data = get(response, 'data.data', {});
      return createSuccessResponse(res, 'Success', { serviceCodeData: data });
    })
    .catch(e => {
      const message = 'GSP Services not found';
      return createErrorResponse(req, res, message, 404);
    });
};

export default getServiceByPath;
