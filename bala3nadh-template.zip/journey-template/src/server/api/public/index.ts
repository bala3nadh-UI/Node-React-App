import express, { Response } from 'express';
import { cmsProxy } from '@bala3nadh/cms-integration';
import aduProxyRouter from 'server/api/proxy/adu';
import msProxyRouter from 'server/api/proxy/ms';
import config from 'config';

import proxyAuthMiddleware from 'server/middlewares/proxyAuthMiddleware';
import ajaxClient from 'server/services/ajaxClient';
import bodyParser from 'body-parser';
import workbenchRouter from './workbench';
import serviceRouter from './service';
import cmsRouter from './cms';
import gspRouter from './gsp';
import adfeedbackRouter from './adfeedback/adfeedbackRouter';
import journeyEngineRouter from './journeyEngine';
import simulatorEngineRouter from './simulatorEngine';
import smartQuestionnaireRouter from './smartQuestionnaire';
import simulatorRouter from './simulator';

const router = express.Router();

router.get('/', (req: Express.Request, res: Response) => {
  res.json({
    message: 'Public API',
    success: true,
  });
});

/**
 * external apis
 */

router.use(
  '/proxy/ms-call',
  proxyAuthMiddleware('public'),
  bodyParser.json(),
  msProxyRouter,
);

router.use(
  '/proxy',
  proxyAuthMiddleware('public'),
  bodyParser.json(),
  aduProxyRouter,
);
router.use('/workbench', workbenchRouter);
router.use('/service', serviceRouter);
router.use('/cms', cmsRouter);
router.use('/gsp', gspRouter);
router.use(
  '/search/autosuggest',
  cmsProxy({
    service: ajaxClient,
    apiGateway: config.gateway,
    url: `${config.cms.host}${config.cms.search.autoSuggest}`,
    plainResponse: true,
  }),
);
router.use('/feedback', adfeedbackRouter);
router.use('/journey-engine', journeyEngineRouter);
router.use('/simulator-engine', simulatorEngineRouter);
router.use('/smart-questionnaire', smartQuestionnaireRouter);
router.use('/simulator', simulatorRouter);

export default router;
