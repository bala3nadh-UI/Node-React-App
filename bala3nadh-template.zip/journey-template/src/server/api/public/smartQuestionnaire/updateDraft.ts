import { Request, Response } from 'express';
import {
  getQuestionnaireInstanceByFilter,
  updateQuestionnaireInstance,
} from 'server/services/io/smartQuestionnaire';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { checkUserSession } from './utils';
import { handleUpdateDraft as handleDynamicSQUpdateDraft } from './dynamicQuestionnaireUtils';

import { updateDraftQuestionnaireSchema } from './schema';

interface SQConfigRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

const updateDraft = async (req: SQConfigRequest, res: Response) => {
  try {
    const { error: validationError } = updateDraftQuestionnaireSchema.validate(
      req.body,
    );
    if (validationError) {
      return createErrorResponse(
        req,
        res,
        `Invalid request ${validationError}`,
        validationError,
      );
    }

    // Parse body
    const {
      questionnairePath,
      isPreview,
      userJourneyId,
      draftData,
      guestUserInstanceId,
      isDynamicSQ,
      dynamicSQConfig,
    } = req.body;

    // Check if user session exists
    const sessionExists = checkUserSession(req);

    let queryFilter: any = {};

    if (sessionExists) {
      // Fetch user uuid
      const userId = req.session.bala3nadhUserInfo['User Unique Identifier'];

      queryFilter = {
        userJourneyId,
        userId,
        questionnairePath,
        isPreview,
      };
    } else {
      // For guest user, query on id
      queryFilter = {
        id: guestUserInstanceId,
        userId: 'guest',
      };
    }

    const latestDraftData = await getQuestionnaireInstanceByFilter(
      req,
      queryFilter,
    );

    if (!latestDraftData) {
      return createErrorResponse(req, res, 'Could not find draft record');
    }

    let parsedDraftData = draftData;
    let responseData: any = {};

    if (isDynamicSQ) {
      const dynamicRes = await handleDynamicSQUpdateDraft(
        req,
        draftData,
        latestDraftData,
        dynamicSQConfig,
      );
      parsedDraftData = dynamicRes.draftData;
      responseData = dynamicRes.responseData;
      if (responseData.showError) {
        return createSuccessResponse(res, 'Success', responseData);
      }
    }

    await updateQuestionnaireInstance(req, latestDraftData.id, parsedDraftData);
    return createSuccessResponse(res, 'Success', responseData);
  } catch (e) {
    return createErrorResponse(
      req,
      res,
      'Failed to update questionnaire draft data',
      process.env.STAGING === 'true' ? e?.message : '',
    );
  }
};

export default updateDraft;
