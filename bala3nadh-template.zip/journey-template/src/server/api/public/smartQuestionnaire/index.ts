import express from 'express';

import fetchConfig from './fetchConfig';
import updateDraft from './updateDraft';
import deleteDraft from './deleteDraft';
import startQuestionnaire from './startQuestionnaire';
import completeQuestionnaire from './completeQuestionnaire';
import cancelQuestionnaire from './cancelQuestionnaire';
import fetchCmsDetails from './fetchCmsDetails';
import fetchQuestionnaireOutputs from './fetchQuestionnaireOutputs';
import fetchQuestionById from './fetchQuestionById';

const router = express.Router();

router.post('/fetchConfig', fetchConfig);
router.post('/updateDraft', updateDraft);
router.post('/deleteDraft', deleteDraft);
router.post('/startQuestionnaire', startQuestionnaire);
router.post('/cancelQuestionnaire', cancelQuestionnaire);
router.post('/completeQuestionnaire', completeQuestionnaire);
router.post('/fetchCmsDetails', fetchCmsDetails);
router.post('/fetchQuestionnaireOutputs', fetchQuestionnaireOutputs);
router.post('/fetchQuestionById', fetchQuestionById);

export default router;
