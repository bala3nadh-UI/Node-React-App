import httpMocks from 'node-mocks-http';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { adlockerUpsertApplication } from './utils';
import startQuestionnaire from './startQuestionnaire';

jest.mock('server/utils/response-utils');
jest.mock('server/services/io/smartQuestionnaire');
jest.mock('./utils');

describe('routes/smartQuestionnaire/startQuestionnaire', () => {
  let req: any;
  let res: any;

  const OLD_ENV = process.env;

  const mockedAdlocker: any = adlockerUpsertApplication;
  beforeEach(() => {
    req = httpMocks.createRequest({
      body: {
        questionnaireCmsId: 'adlockerRefCode',
        refKey: `asdkjashd129831-21391283`,
        refCode: 'adlockerRefCode',
        journeyInstanceId: '1234',
        journeyStage: 'sjfh738d2h',
        journeyStageNameEn: 'Sstage en',
        journeyStageNameAr: 'لقب',
        journeyStageOrder: 0,
      },
      session: {
        bala3nadhUserInfo: {},
      },
    });
    res = httpMocks.createResponse();
    req.log = {
      error: jest.fn(),
    };
    jest.resetModules();
    process.env = { ...OLD_ENV };
  });

  afterAll(() => {
    process.env = OLD_ENV;
  });

  it('should handle success', async () => {
    mockedAdlocker.mockImplementationOnce(() => ({ status: 'sometthing' }));

    await startQuestionnaire(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should handle fail', async () => {
    mockedAdlocker.mockImplementationOnce(() => ({ status: 'error' }));

    await startQuestionnaire(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle exception', async () => {
    mockedAdlocker.mockImplementationOnce(() => undefined);

    await startQuestionnaire(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle fail, process.env staging', async () => {
    process.env.STAGING = 'true';
    mockedAdlocker.mockImplementationOnce(() => ({
      status: 'error',
      message: 'abcd',
    }));

    await startQuestionnaire(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle exception, process.env staging', async () => {
    process.env.STAGING = 'true';
    mockedAdlocker.mockImplementationOnce(() => undefined);

    await startQuestionnaire(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should trigger validation error', async () => {
    req.body.questionnaireCmsId = 1234;
    mockedAdlocker.mockImplementationOnce(() => ({ status: 'sometthing' }));

    await startQuestionnaire(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });
});
