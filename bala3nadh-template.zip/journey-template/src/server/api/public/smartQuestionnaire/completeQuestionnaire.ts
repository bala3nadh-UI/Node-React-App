import { Request, Response } from 'express';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { adlockerUpsertApplication } from './utils';
import { completeQuestionnaireSchema } from './schema';

const completeQuestionnaire = async (req: Request, res: Response) => {
  try {
    const { error: validationError } = completeQuestionnaireSchema.validate(
      req.body,
    );
    if (validationError) {
      return createErrorResponse(
        req,
        res,
        'Invalid data in request body',
        validationError,
      );
    }
    const completeQuestionnaireResponse = await adlockerUpsertApplication(
      'UPDATE',
      'Completed',
      req,
    );
    if (completeQuestionnaireResponse.status === 'error') {
      return createErrorResponse(
        req,
        res,
        'Failed to update ADLocker record',
        process.env.STAGING === 'true'
          ? completeQuestionnaireResponse.message
          : '',
      );
    }
    return createSuccessResponse(res, 'Success', {
      ...completeQuestionnaireResponse,
      success: true,
    });
  } catch (ex) {
    return createErrorResponse(
      req,
      res,
      'Failed to update ADLocker record',
      process.env.STAGING === 'true' ? ex?.message : '',
    );
  }
};

export default completeQuestionnaire;
