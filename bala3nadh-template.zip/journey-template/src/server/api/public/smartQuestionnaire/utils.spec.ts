import httpMocks from 'node-mocks-http';
import ajaxClient from 'server/services/ajaxClient';
import { adlockerUpsertApplication } from './utils';

jest.mock('server/services/ajaxClient');
jest.mock('server/utils/logger');
jest.mock('config', () => ({
  projectName: 'acbd',
  gateway: {
    header: 'x-Gateway-APIKey',
    key: 'apiKey',
  },
  cms: {
    host: 'asdasd',
    journeyItems: {
      endpoint: '12312',
    },
  },
  adlServicesInProgress: {
    host: '123123',
    endpoints: {
      upsert: '/upsert',
    },
  },
}));

describe('questionnaire utils', () => {
  let mockRequest: any;
  // let res: httpMocks.MockResponse<any>;
  let mockAjaxClient: any;

  beforeEach(() => {
    mockRequest = httpMocks.createRequest();
    mockAjaxClient = ajaxClient as jest.MockedFunction<any>;
    mockRequest.session = {
      bala3nadhUserInfo: {
        'User Unique Identifier': '1234',
      },
    };
    mockRequest.log = {
      info: jest.fn(),
      error: jest.fn(),
    };
  });

  it('success adlocker callout', async () => {
    mockRequest.body = {
      applicationId: 'applicationId',
      refCode: 'refCode',
      refKey: 'refKey',
      journeyInstanceId: 'journeyInstanceId',
      journeyStage: 'journeyStage',
      journeyStageNameEn: 'journeyStageNameEn',
      journeyStageNameAr: 'journeyStageNameAr',
      journeyStageOrder: 'journeyStageOrder',
    };

    mockAjaxClient.mockImplementationOnce(() => {
      return {
        data: {
          data: {
            items: [
              [
                {
                  AGDE: '{123123123-123123123}',
                },
              ],
            ],
          },
        },
      };
    });

    mockAjaxClient.mockImplementationOnce(() => {
      return {
        data: {
          data: {
            items: [
              [
                {
                  Abbreviation: 'DED',
                },
              ],
            ],
          },
        },
      };
    });

    mockAjaxClient.mockImplementationOnce(() => {
      return {
        status: 200,
        data: {
          body: {
            data: [
              {
                ApplicationId: '1234',
              },
            ],
          },
          header: {},
        },
      };
    });

    const expectedValue = {
      ApplicationId: '1234',
    };

    const value = await adlockerUpsertApplication(
      'INSERT',
      'Initiated',
      mockRequest,
    );
    expect(value).toEqual(expectedValue);
  });

  it('fail adlocker callout', async () => {
    mockRequest.body = {
      applicationId: 'applicationId',
      refCode: 'refCode',
      refKey: 'refKey',
      journeyInstanceId: 'journeyInstanceId',
      journeyStage: 'journeyStage',
      journeyStageNameEn: 'journeyStageNameEn',
      journeyStageNameAr: 'journeyStageNameAr',
      journeyStageOrder: 'journeyStageOrder',
    };

    mockAjaxClient.mockImplementationOnce(() => {
      return {
        data: {
          data: {
            items: [
              [
                {
                  AGDE: '{123123123-123123123}',
                },
              ],
            ],
          },
        },
      };
    });

    mockAjaxClient.mockImplementationOnce(() => {
      return {
        data: {
          data: {
            items: [
              [
                {
                  Abbreviation: 'DED',
                },
              ],
            ],
          },
        },
      };
    });

    mockAjaxClient.mockImplementationOnce(() => {
      return {
        status: 400,
        data: {
          header: {},
        },
      };
    });

    const expectedValue = {};

    const value = await adlockerUpsertApplication(
      'INSERT',
      'Initiated',
      mockRequest,
    );
    expect(value).toEqual(expectedValue);
  });
});
