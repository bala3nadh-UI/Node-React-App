import ajaxClient from 'server/services/ajaxClient';
import httpMocks from 'node-mocks-http';
import * as utils from './dynamicQuestionnaireUtils';

jest.mock('server/services/ajaxClient');
jest.mock('server/utils/logger');
jest.mock('config', () => ({
  projectName: 'mockProject',
  gateway: {
    header: 'x-Gateway-APIKey',
    key: 'mockAPIKey',
  },
  serviceApiBaseUrl: 'mockHost',
}));

describe('dynamicQuestionnaireUtils', () => {
  let mockAjaxClient: any;
  let mockRequest: any;
  beforeEach(() => {
    mockRequest = httpMocks.createRequest();
    mockAjaxClient = ajaxClient as jest.MockedFunction<any>;
  });

  describe('handleFetchConfig', () => {
    it('should handle question parsing', async () => {
      mockAjaxClient.mockReturnValueOnce({
        data: {
          question: {
            id: 'mockQuestionId',
            title: { en: 'mockTitleEn', ar: 'mockTitleAr' },
            shortDescription: {
              en: 'mockDescriptionEn',
              ar: 'mockDescriptionAr',
            },
            answerType: { field: 'input' },
          },
          totalQuestions: 20,
        },
      });
      const res = await utils.handleFetchConfig(mockRequest, '');
      expect(res.questions.length).toBe(1);
    });

    it('should handle results without any questions', async () => {
      mockAjaxClient.mockReturnValueOnce({
        data: {
          showResults: true,
        },
      });
      const res = await utils.handleFetchConfig(mockRequest, '');
      expect(res.showError).toBeTruthy();
    });

    it('should send api errors', async () => {
      const errorMsg = 'Error!!';
      mockAjaxClient.mockReturnValueOnce({
        data: {
          showError: true,
          errorMessage: { en: errorMsg, ar: errorMsg },
        },
      });
      const res = await utils.handleFetchConfig(mockRequest, '');
      expect(res.showError).toBeTruthy();
      expect(res.errorMessage.en).toBe(errorMsg);
    });

    it('should handle validation error', async () => {
      mockAjaxClient.mockReturnValueOnce({
        data: {
          question: {
            id: 'mockQuestionId',
            title: { en: 'mockTitleEn', ar: 'mockTitleAr' },
            shortDescription: {
              en: 'mockDescriptionEn',
              ar: 'mockDescriptionAr',
            },
          },
          totalQuestions: 20,
        },
      });
      const res = await utils.handleFetchConfig(mockRequest, '');
      expect(res.showError).toBeTruthy();
    });
  });

  describe('handleUpdateDraft', () => {
    const draftData = { questionnaireResponses: {} };
    it('should handle question parsing', async () => {
      mockAjaxClient.mockReturnValueOnce({
        data: {
          question: {
            id: 'mockQuestionId',
            title: { en: 'mockTitleEn', ar: 'mockTitleAr' },
            shortDescription: {
              en: 'mockDescriptionEn',
              ar: 'mockDescriptionAr',
            },
            answerType: { field: 'input', validation: 'regexp' },
          },
          relatedAction: { cmsId: 'mockCmsId' },
          totalQuestions: 20,
        },
      });
      const res = await utils.handleUpdateDraft(
        mockRequest,
        draftData,
        {
          questionnaireResponses: { dynamicQuestionnaireData: {} },
        },
        { requestType: 'next' },
      );
      expect(res.responseData.question.questionId).toBe('mockQuestionId');
    });

    it('should handle results without any questions', async () => {
      mockAjaxClient.mockReturnValueOnce({
        data: {
          showResults: true,
        },
      });
      const res = await utils.handleUpdateDraft(
        mockRequest,
        draftData,
        {
          questionnaireResponses: { dynamicQuestionnaireData: {} },
        },
        { requestType: 'next' },
      );
      expect(res.responseData.activeQuestionId).toBe('output');
    });

    it('should send api errors', async () => {
      const errorMsg = 'Error!!';
      mockAjaxClient.mockReturnValueOnce({
        data: {
          showError: true,
          errorMessage: { en: errorMsg, ar: errorMsg },
        },
      });
      const res = await utils.handleUpdateDraft(
        mockRequest,
        draftData,
        {
          questionnaireResponses: { dynamicQuestionnaireData: {} },
        },
        { requestType: 'next' },
      );
      expect(res.responseData.showError).toBeTruthy();
      expect(res.responseData.errorMessage.en).toBe(errorMsg);
    });

    it('should handle validation error - duplicateQuestion', async () => {
      mockAjaxClient.mockReturnValueOnce({
        data: {
          question: {
            id: 'mockQuestionId',
            title: { en: 'mockTitleEn', ar: 'mockTitleAr' },
            shortDescription: {
              en: 'mockDescriptionEn',
              ar: 'mockDescriptionAr',
            },
            answerType: { field: 'input' },
          },
          totalQuestions: 20,
        },
      });
      const res = await utils.handleUpdateDraft(
        mockRequest,
        draftData,
        {
          questionnaireResponses: { dynamicQuestionnaireData: {} },
        },
        { requestType: 'next', questionStack: ['mockQuestionId'] },
      );
      expect(res.responseData.showError).toBeTruthy();
    });

    it('should handle previous update draft', async () => {
      const res = await utils.handleUpdateDraft(
        mockRequest,
        draftData,
        {
          questionnaireResponses: {
            dynamicQuestionnaireData: {
              questions: [
                { questionId: 'mockQuestionId' },
                { questionId: 'mockQuestionId1-to be deleted' },
              ],
            },
          },
        },
        { requestType: 'previous', questionStack: ['mockQuestionId'] },
      );

      expect(
        (res.draftData as any).questionnaireResponses.dynamicQuestionnaireData
          .questions.length,
      ).toBe(1);
    });

    it('should handle previous update draft - branches', async () => {
      const res1 = await utils.handleUpdateDraft(
        mockRequest,
        draftData,
        {
          questionnaireResponses: {
            dynamicQuestionnaireData: {
              questions: [{ questionId: 'mockQuestionId' }],
            },
          },
        },
        { requestType: 'previous' },
      );

      const res2 = await utils.handleUpdateDraft(
        mockRequest,
        draftData,
        {
          questionnaireResponses: {
            dynamicQuestionnaireData: {},
          },
        },
        { requestType: 'previous' },
      );

      expect(res1.responseData).toMatchObject({});
      expect(res2.responseData).toMatchObject({});
    });

    it('should handle output update draft', async () => {
      const res = await utils.handleUpdateDraft(
        mockRequest,
        draftData,
        {
          questionnaireResponses: {
            dynamicQuestionnaireData: {
              questions: [
                { questionId: 'mockQuestionId' },
                { questionId: 'mockQuestionId1-to be deleted' },
              ],
            },
          },
        },
        { requestType: 'output' },
      );

      expect(
        (res.draftData as any).questionnaireResponses.dynamicQuestionnaireData
          .questions.length,
      ).toBe(2);
    });
  });
});
