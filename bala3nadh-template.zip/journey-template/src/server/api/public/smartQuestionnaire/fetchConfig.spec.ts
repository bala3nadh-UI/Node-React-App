import httpMocks from 'node-mocks-http';
import * as sqIo from 'server/services/io/smartQuestionnaire';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import * as utils from './utils';
import * as cmsUtils from './cmsUtils';
import fetchConfig from './fetchConfig';
import * as dynamicSQUtils from './dynamicQuestionnaireUtils';

jest.mock('server/utils/response-utils');
jest.mock('server/services/io/smartQuestionnaire');
jest.mock('./utils');
jest.mock('./cmsUtils');

describe('routes/smartQuestionnaire/fetchConfig', () => {
  let req: any;
  let res: any;

  const OLD_ENV = process.env;

  const mockedSqIo: any = sqIo;
  const mockedUtils: any = utils;
  const mockedCmsUtils: any = cmsUtils;
  beforeEach(() => {
    req = httpMocks.createRequest({
      body: {
        questionnairePath: '/questionnairePath',
      },
      session: {
        bala3nadhUserInfo: {},
      },
    });
    res = httpMocks.createResponse();
    req.log = {
      error: jest.fn(),
    };
    jest.resetModules();
    process.env = { ...OLD_ENV };
  });

  afterAll(() => {
    process.env = OLD_ENV;
  });

  mockedSqIo.createQuestionnaireInstance = jest.fn().mockResolvedValue({});

  it('should fetch valid config - with init draft', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(true);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockResolvedValue(null);
    mockedSqIo.getQuestionnaireConfigByFilter = jest
      .fn()
      .mockResolvedValue({ config: 'bar' });

    await fetchConfig(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();

    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockResolvedValue({ questionnaireStatus: 'inactive' });
    mockedSqIo.getQuestionnaireConfigByFilter = jest
      .fn()
      .mockResolvedValue({ config: 'bar' });

    await fetchConfig(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should fetch valid config - without init draft', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest.fn().mockResolvedValue({
      questionnaireStatus: 'draft',
      questionnaireResponses: {},
    });
    mockedSqIo.getQuestionnaireConfigByFilter = jest
      .fn()
      .mockResolvedValue({ config: 'bar' });

    await fetchConfig(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should fetch invalid config', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockResolvedValue({ questionnaireStatus: 'draft' });
    mockedSqIo.getQuestionnaireConfigByFilter = jest
      .fn()
      .mockResolvedValue(null);

    await fetchConfig(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should handle errors, env variable is false', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    process.env.STAGING = 'false';

    mockedSqIo.getQuestionnaireConfigByFilter = jest
      .fn()
      .mockRejectedValue({ error: 'baz' });

    await fetchConfig(req, res);
    expect(createErrorResponse).toHaveBeenCalled();

    mockedSqIo.getQuestionnaireConfigByFilter = jest
      .fn()
      .mockRejectedValue({ message: 'baz' });

    await fetchConfig(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle errors, env variable is true', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    process.env.STAGING = 'true';

    mockedSqIo.getQuestionnaireConfigByFilter = jest
      .fn()
      .mockRejectedValue(null);

    await fetchConfig(req, res);
    expect(createErrorResponse).toHaveBeenCalled();

    mockedSqIo.getQuestionnaireConfigByFilter = jest
      .fn()
      .mockRejectedValue({ message: 'baz' });

    await fetchConfig(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle valid config - with cmsFetch & login required', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest.fn().mockResolvedValue({
      questionnaireStatus: 'draft',
      questionnaireResponses: {},
    });
    mockedSqIo.getQuestionnaireConfigByFilter = jest.fn().mockResolvedValue({
      config: {
        questionnaireCmsItem: { cmsId: 'mockCmsId' },
        dataSourceSettings: { dataSource: 'static' },
      },
    });
    mockedCmsUtils.getSourceKeyMapping = jest.fn().mockReturnValue({});
    mockedCmsUtils.fetchAndParseCmsContentRecursively = jest
      .fn()
      .mockResolvedValue({
        loginRequired: 'true',
      });

    await fetchConfig(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should handle valid config - with cmsFetch & login required', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest.fn().mockResolvedValue({
      questionnaireStatus: 'draft',
      questionnaireResponses: {},
    });
    mockedSqIo.getQuestionnaireConfigByFilter = jest.fn().mockResolvedValue({
      config: {
        questionnaireCmsItem: { cmsId: 'mockCmsId' },
      },
    });
    mockedCmsUtils.getSourceKeyMapping = jest.fn().mockReturnValue({});
    mockedCmsUtils.fetchAndParseCmsContentRecursively = jest
      .fn()
      .mockResolvedValue(undefined);

    await fetchConfig(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should skip fetch and handle dynamic sq error', async () => {
    const standaloneReq = httpMocks.createRequest({
      body: {
        questionnairePath: '/questionnairePath',
        userJourneyId: 'standalone',
      },
      session: {
        bala3nadhUserInfo: {},
      },
    });
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireConfigByFilter = jest.fn().mockResolvedValue({
      config: {
        dataSourceSettings: {
          dataSource: 'dynamic',
        },
      },
    });
    jest.spyOn(dynamicSQUtils, 'handleFetchConfig');
    (dynamicSQUtils.handleFetchConfig as any).mockResolvedValue({
      showError: true,
    });

    await fetchConfig(standaloneReq, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });
});
