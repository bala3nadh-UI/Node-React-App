import httpMocks from 'node-mocks-http';
import * as sqIo from 'server/services/io/smartQuestionnaire';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import * as utils from './utils';
import fetchQuestionnaireOutputs from './fetchQuestionnaireOutputs';

jest.mock('server/utils/response-utils');
jest.mock('server/services/io/smartQuestionnaire');
jest.mock('./utils');

describe('routes/smartQuestionnaire/fetchQuestionnaireOutputs', () => {
  let req: any;
  let res: any;

  const OLD_ENV = process.env;

  const mockedSqIo: any = sqIo;
  const mockedUtils: any = utils;
  beforeEach(() => {
    req = httpMocks.createRequest({
      body: {
        questionnairePath: '/questionnairePath',
      },
      session: {
        bala3nadhUserInfo: {},
      },
    });
    res = httpMocks.createResponse();
    req.log = {
      error: jest.fn(),
    };
    jest.resetModules();
    process.env = { ...OLD_ENV };
  });

  afterAll(() => {
    process.env = OLD_ENV;
  });

  it('should handle success', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(true);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest.fn().mockResolvedValue({
      userJourneyId: 'standalone',
      questionnaireResponses: { outputs: { output1: 'value1' } },
    });

    await fetchQuestionnaireOutputs(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should handle failure if instance id is incorrect', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(true);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockResolvedValue(null);

    await fetchQuestionnaireOutputs(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle failure if instance id is not standalone and user is present', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(true);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest.fn().mockResolvedValue({
      userJourneyId: '123',
      questionnaireResponses: { outputs: { output1: 'value1' } },
    });

    await fetchQuestionnaireOutputs(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle failure if outputs are absent', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(true);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest.fn().mockResolvedValue({
      userJourneyId: 'standalone',
      questionnaireResponses: { outputs: {} },
    });

    await fetchQuestionnaireOutputs(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle exception, env variable is false', async () => {
    process.env.STAGING = 'false';

    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockRejectedValue(null);

    await fetchQuestionnaireOutputs(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle exception, env variable is true', async () => {
    process.env.STAGING = 'true';

    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockRejectedValue(null);

    await fetchQuestionnaireOutputs(req, res);
    expect(createErrorResponse).toHaveBeenCalled();

    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockRejectedValue({ message: 'error' });

    await fetchQuestionnaireOutputs(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });
});
