import { Request } from 'express';
import config from 'config';
import ajaxClient from 'server/services/ajaxClient';

interface SQConfigRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

export const getCmsItem = async (cmsId: string, req: SQConfigRequest) => {
  const headers = {
    'Content-Type': 'application/json',
    [config.gateway.header]: config.gateway.key,
  };
  const cmsRequestConfig: any = {
    url: `${config.cms.host}${config.cms.journeyItems.endpoint}`,
    method: 'post',
    headers,
    data: {
      items: [
        {
          id: `{${cmsId}}`,
          children: false,
        },
      ],
      lang: ['en', 'ar'],
    },
  };
  return ajaxClient(cmsRequestConfig, req);
};

export const checkUserSession = (req: SQConfigRequest) =>
  !!req.session?.bala3nadhUserInfo;

// eslint-disable-next-line complexity
export const adlockerUpsertApplication = async (
  recordAction: string,
  providerStatus: 'Completed' | 'Initiated',
  req: SQConfigRequest,
) => {
  const userId = req.session.bala3nadhUserInfo['User Unique Identifier'];
  let adgeId: string = '';
  const {
    applicationId,
    refCode,
    refKey,
    journeyInstanceId,
    journeyStage,
    journeyStageNameEn,
    journeyStageNameAr,
    journeyStageOrder,
  } = req.body;

  const ADL_PROVIDER_STATUS_MAPPING = {
    Completed: {
      en: 'Completed',
      ar: 'مكتملة',
    },
    Initiated: {
      en: 'Initiated',
      ar: 'تم إنشاء الطلب',
    },
  };

  try {
    const cmsItem = await getCmsItem(refCode, req);
    req.log.info('cmsItem =>', cmsItem);
    if (
      cmsItem &&
      cmsItem.data &&
      cmsItem.data.data &&
      cmsItem.data.data.items &&
      cmsItem.data.data.items.length > 0
    ) {
      const adgeCmsId = cmsItem.data.data.items[0][0].ADGE;
      const adgeCmsItem: any = await getCmsItem(adgeCmsId, req);
      req.log.info('adgeCmsItem =>', adgeCmsItem);
      if (
        adgeCmsItem &&
        adgeCmsItem.data &&
        adgeCmsItem.data.data &&
        adgeCmsItem.data.data.items &&
        adgeCmsItem.data.data.items.length > 0
      ) {
        adgeId = adgeCmsItem.data.data.items[0][0].Abbreviation;
      }
    }

    const url = `${config.adlServicesInProgress.host}${config.adlServicesInProgress.endpoints.upsert}`;
    const headers = {
      'Content-Type': 'application/json',
      [config.gateway.header]: config.gateway.key,
    };

    const refCodeLookup: any = {
      '08F8DD1D-4E5C-4105-A4D3-958C6E930F65': '108400580',
      '12C5691E-559C-43AA-BECD-669050ADAF80': '108400590',
    };

    const requestConfig: any = {
      url,
      method: 'post',
      headers,
      data: {
        header: {
          channelid: '4', // 4 - from bala3nadh, 1 - from ADGE
        },
        body: {
          data: [
            {
              ApplicationID: applicationId,
              UserID: userId,
              RefKey: refKey,
              RefCode: refCodeLookup[refCode] || refCode,
              RecordAction: recordAction,
              ProviderStatusCode: providerStatus,
              ADGEID: adgeId,
              StatusDate: new Date().toISOString(),
              ApplicationType: 'APPLICATION',
              Metadata: {},
              ProviderStatusName_EN:
                ADL_PROVIDER_STATUS_MAPPING[providerStatus].en,
              ProviderStatusName_AR:
                ADL_PROVIDER_STATUS_MAPPING[providerStatus].ar,
              JourneyInstanceID: journeyInstanceId
                ? journeyInstanceId.trim()
                : '',
              JourneyStage: journeyStage,
              JourneyStageName_EN: journeyStageNameEn,
              JourneyStageName_AR: journeyStageNameAr,
              JourneyStageOrder: `${journeyStageOrder}`,
            },
          ],
        },
      },
    };
    const response: any = await ajaxClient(requestConfig, req);
    req.log.info('ADLocker response ==>', response.data);
    if (response.status === 200 && response.data.body) {
      return response.data.body?.data[0];
    }
    return response.data.header;
  } catch (err) {
    const { response } = err;
    req.log.error('Exception ==>', err);
    req.log.error('Exception response  ==>', response.data);
    throw err;
  }
};
