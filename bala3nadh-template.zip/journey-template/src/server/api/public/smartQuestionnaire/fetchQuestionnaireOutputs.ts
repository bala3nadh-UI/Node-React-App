import { Request, Response } from 'express';
import { getQuestionnaireInstanceByFilter } from 'server/services/io/smartQuestionnaire';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { checkUserSession } from './utils';

interface SQConfigRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

const fetchQuestionnaireOutputs = async (
  req: SQConfigRequest,
  res: Response,
) => {
  try {
    // Parse body
    const { instanceId } = req.body;

    // Check if user session exists
    const sessionExists = checkUserSession(req);

    const data = await getQuestionnaireInstanceByFilter(req, {
      id: instanceId,
    });

    if (!data) {
      return createErrorResponse(
        req,
        res,
        'Questionnaire instance not found.',
        {},
        404,
      );
    }

    const { userJourneyId } = data;
    const { outputs } = data?.questionnaireResponses;

    if (userJourneyId !== 'standalone' && sessionExists) {
      return createErrorResponse(
        req,
        res,
        'This instance is not associated with a standalone or guest questionnaire attempt.',
        {},
        401,
      );
    }
    if (Object.keys(outputs).length === 0) {
      return createErrorResponse(
        req,
        res,
        'No output found for the questionnaire.',
        {},
        400,
      );
    }

    return createSuccessResponse(res, 'Success', outputs);
  } catch (e) {
    return createErrorResponse(
      req,
      res,
      'Failed to fetch questionnaire instance.',
      process.env.STAGING === 'true' ? e?.message : '',
    );
  }
};

export default fetchQuestionnaireOutputs;
