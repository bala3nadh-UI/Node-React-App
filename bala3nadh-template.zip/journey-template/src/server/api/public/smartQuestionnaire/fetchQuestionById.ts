import { Request, Response } from 'express';
import ajaxClient from 'server/services/ajaxClient';
import config from 'config';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import {
  parseDynamicQuestion,
  validateDynamicQuestion,
} from './dynamicQuestionnaireUtils';

interface SQConfigRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

const fetchQuestionById = async (req: SQConfigRequest, res: Response) => {
  try {
    const { path, questionId, responses, stack } = req.body;

    const url = `${config.serviceApiBaseUrl}${path}/${questionId}`;

    const data = {
      questionnaireResponses: responses,
      questionnaireOrder: stack,
    };

    const headers = {
      'Content-Type': 'application/json; charset=utf-8',
      [config.gateway.header]: config.gateway.key,
    };

    const requestConfig: any = {
      url,
      method: 'post',
      headers,
      data,
    };

    const result = await ajaxClient(requestConfig, req);

    const response = result.data.data?.data || result.data.data || result.data;

    const validationError = validateDynamicQuestion(response.question);

    if (validationError || response.question.id !== questionId) {
      return createSuccessResponse(res, 'Success', null);
    }

    const parsedQuestion = parseDynamicQuestion(
      response.question,
      response.relatedAction,
    );

    return createSuccessResponse(res, 'Success', { question: parsedQuestion });
  } catch (e) {
    return createErrorResponse(
      req,
      res,
      'Failed to fetch question by id.',
      process.env.STAGING === 'true' ? e?.message : '',
    );
  }
};

export default fetchQuestionById;
