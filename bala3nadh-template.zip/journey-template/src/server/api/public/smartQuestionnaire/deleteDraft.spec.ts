import httpMocks from 'node-mocks-http';
import * as sqIo from 'server/services/io/smartQuestionnaire';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import * as utils from './utils';
import deleteDraft from './deleteDraft';

jest.mock('server/utils/response-utils');
jest.mock('server/services/io/smartQuestionnaire');
jest.mock('./utils');

describe('routes/smartQuestionnaire/deleteDraft', () => {
  let req: any;
  let res: any;

  const OLD_ENV = process.env;

  const mockedSqIo: any = sqIo;
  const mockedUtils: any = utils;
  beforeEach(() => {
    req = httpMocks.createRequest({
      body: {
        questionnairePath: '/questionnairePath',
      },
      session: {
        bala3nadhUserInfo: {},
      },
    });
    res = httpMocks.createResponse();
    req.log = {
      error: jest.fn(),
    };
    jest.resetModules();
    process.env = { ...OLD_ENV };
  });

  afterAll(() => {
    process.env = OLD_ENV;
  });

  mockedSqIo.deleteQuestionnaireInstance = jest.fn().mockResolvedValue({});

  it('should handle success', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(true);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockResolvedValue({ id: 'something' });

    await deleteDraft(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should handle fail', async () => {
    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockResolvedValue(null);

    await deleteDraft(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle exception, env variable is false', async () => {
    process.env.STAGING = 'false';

    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockRejectedValue(null);

    await deleteDraft(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle exception, env variable is true', async () => {
    process.env.STAGING = 'true';

    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockRejectedValue(null);

    await deleteDraft(req, res);
    expect(createErrorResponse).toHaveBeenCalled();

    mockedUtils.checkUserSession = jest.fn().mockReturnValue(false);
    mockedSqIo.getQuestionnaireInstanceByFilter = jest
      .fn()
      .mockRejectedValue({ message: 'error' });

    await deleteDraft(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });
});
