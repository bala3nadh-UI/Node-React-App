import config from 'config';
import { Request } from 'express';
import { IVariables } from '@bala3nadh/app-composer';
import { getCmsItem } from './utils';

const getSourceKey = (key: string) => {
  const mappingObject: IVariables = {
    'Service Page': 'service',
    'General Information Page': 'information',
    Tool: 'tool',
    Journeys: 'journey',
  };

  return mappingObject[key];
};

/* eslint-disable complexity */
export const getSourceKeyMapping = (stageItemType: string): IVariables[] => {
  if (stageItemType === 'journey') {
    return [
      { name: 'Journey Heading', as: 'title' },
      { name: 'Journey Short Description', as: 'description' },
      { name: 'Link', as: 'link' },
    ];
  }
  if (stageItemType === 'service') {
    return [
      { name: 'Service Name', as: 'title' },
      { name: 'Service Short Description', as: 'description' },
      { name: 'Related Online Service', as: 'link' },
    ];
  }
  if (stageItemType === 'tool' || stageItemType === 'questionnaire') {
    return [
      { name: 'Title', as: 'title' },
      { name: 'ShortDescription', as: 'description' },
      { name: 'StandaloneServiceLink', as: 'link', parse: true },
      {
        name: 'ADGE',
        as: 'sponsoringEntity',
        pull: true,
      },
      {
        name: 'Login Required',
        as: 'loginRequired',
        skipLangParsing: true,
      },
    ];
  }
  if (stageItemType === 'information') {
    return [
      { name: 'GI Name', as: 'title' },
      { name: 'GI Short Description', as: 'description' },
      { name: 'ItemPath', as: 'link', parse: true },
    ];
  }
  const parsedItemType = getSourceKey(stageItemType);

  return parsedItemType ? getSourceKeyMapping(parsedItemType) : [];
};

export const getParsedContent = (
  type: string,
  item: string,
  lang?: string,
  baseUrl?: string,
): string => {
  if (item && item !== '') {
    if (type === 'ItemPath') {
      return item.replace(
        '/sitecore/content/bala3nadh/Home/home',
        `${baseUrl || ''}/${lang === 'ar' ? 'ar-AE' : 'en'}`,
      );
    }
    if (type === 'StandaloneServiceLink' || type === 'Link' || type === 'URL') {
      const urlRegex = /(?:^|\s)url="(.*?)"(?:\s|$)/gm;
      const match = urlRegex.exec(item);
      return match ? match[1] : item;
    }
    if (
      type === 'Journey Image' ||
      type === 'Highlight Image' ||
      type === 'Entity Logo' ||
      item.indexOf('mediaid=') > -1
    ) {
      const mediaRegex = /(?:^|\s)mediaid="(.*?)"(?:|$)/gm;
      const match = mediaRegex.exec(item);
      return match ? match[1] : item;
    }
    return item;
  }
  return item;
};

export const fetchAndParseCmsContentRecursively = async (
  cmsId: string,
  pick: IVariables[] | null,
  fetchChildren: boolean,
  req: Request,
) => {
  try {
    const cmsItem = await getCmsItem(cmsId, req);

    if (cmsItem?.data?.data?.items?.length > 0) {
      const cmsDetailsEn = cmsItem.data.data.items[0][0];
      const cmsDetailsAr = cmsItem.data.data.items[0][1];
      const actionType = cmsDetailsEn.TemplateName;

      // eslint-disable-next-line no-param-reassign
      if (!pick) pick = getSourceKeyMapping(actionType);

      const cmsData = pick.reduce((dataAcc: any, currentKey: any) => {
        if (currentKey.skipLangParsing) {
          return {
            ...dataAcc,
            [currentKey.as]: cmsDetailsEn[currentKey.name],
          };
        }
        return currentKey.parse
          ? {
              ...dataAcc,
              [currentKey.as]: {
                en: getParsedContent(
                  currentKey.name,
                  cmsDetailsEn[currentKey.name],
                  'en',
                  config.cms.bala3nadhUrl,
                ),
                ar: getParsedContent(
                  currentKey.name,
                  cmsDetailsAr[currentKey.name],
                  'ar',
                  config.cms.bala3nadhUrl,
                ),
              },
            }
          : {
              ...dataAcc,
              [currentKey.as]: {
                en: cmsDetailsEn[currentKey.name],
                ar: cmsDetailsAr[currentKey.name],
              },
            };
      }, {});

      const childCmsKeys = fetchChildren
        ? pick.filter((currentKey: any) => currentKey.pull)
        : [];

      const childCmsData: any = await Promise.all(
        childCmsKeys.map(async currentKey => {
          const childCmsId = cmsData[currentKey.as].en;
          let childPick: any = [];
          if (currentKey.name === 'ADGE') {
            childPick = [
              { name: 'Name', as: 'name' },
              { name: 'Address', as: 'address' },
              { name: 'Phone', as: 'phone' },
              { name: 'Email', as: 'email' },
              { name: 'URL', as: 'url', parse: true },
              { name: 'Office Hours', as: 'officeHours' },
              { name: 'Public Service Hours', as: 'publicServiceHours' },
              {
                name: 'Entity Logo',
                as: 'logo',
                parse: true,
                pull: true,
              },
            ];
          } else if (
            currentKey.name === 'Hero Image' ||
            currentKey.name === 'Highlight Image' ||
            currentKey.name === 'Entity Logo'
          ) {
            childPick = [
              { name: 'Name', as: 'name' },
              { name: 'ItemMedialUrl', as: 'imageLink' },
            ];
          }

          return fetchAndParseCmsContentRecursively(
            childCmsId,
            childPick,
            fetchChildren,
            req,
          );
        }),
      );

      const parsedChildCmsData = childCmsKeys.reduce(
        (acc: any, currentValue: any, currentIndex: number) => {
          return {
            ...acc,
            [currentValue.as]: childCmsData[currentIndex],
          };
        },
        {},
      );

      return {
        ...cmsData,
        ...parsedChildCmsData,
        actiontype: getSourceKey(actionType),
      };
    }
    return null;
  } catch (e) {
    return null;
  }
};
