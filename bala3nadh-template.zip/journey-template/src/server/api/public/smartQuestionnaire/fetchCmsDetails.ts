import { Request, Response } from 'express';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';

import { fetchAndParseCmsContentRecursively } from './cmsUtils';

const fetchCmsDetails = async (req: Request, res: Response) => {
  try {
    const { cmsId, requiresEntityDetails } = req.body;

    const cmsData = await fetchAndParseCmsContentRecursively(
      cmsId,
      null,
      requiresEntityDetails,
      req,
    );

    if (cmsData) {
      return createSuccessResponse(res, 'Success', cmsData);
    }

    return createErrorResponse(req, res, 'Failed to fetch CMS Details');
  } catch (e) {
    return createErrorResponse(
      req,
      res,
      'Failed to fetch CMS Details',
      process.env.STAGING === 'true' ? e?.message : '',
    );
  }
};

export default fetchCmsDetails;
