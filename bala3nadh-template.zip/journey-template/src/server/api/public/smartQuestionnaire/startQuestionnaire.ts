import { Request, Response } from 'express';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { adlockerUpsertApplication } from './utils';
import { startQuestionnaireSchema } from './schema';

const startQuestionnaire = async (req: Request, res: Response) => {
  try {
    const { error: validationError } = startQuestionnaireSchema.validate(
      req.body,
    );
    if (validationError) {
      return createErrorResponse(
        req,
        res,
        'Invalid data in request body',
        validationError,
      );
    }
    const startQuestionnaireResponse = await adlockerUpsertApplication(
      'INSERT',
      'Initiated',
      req,
    );
    if (startQuestionnaireResponse.status === 'error') {
      return createErrorResponse(
        req,
        res,
        'Failed to insert ADLocker record',
        process.env.STAGING === 'true'
          ? startQuestionnaireResponse.message
          : '',
      );
    }
    return createSuccessResponse(res, 'Success', {
      ...startQuestionnaireResponse,
      success: true,
    });
  } catch (ex) {
    return createErrorResponse(
      req,
      res,
      'Failed to insert ADLocker record',
      process.env.STAGING === 'true' ? ex?.message : '',
    );
  }
};

export default startQuestionnaire;
