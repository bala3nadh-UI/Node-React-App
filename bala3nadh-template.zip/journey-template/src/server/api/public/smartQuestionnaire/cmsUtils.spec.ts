import httpMocks from 'node-mocks-http';
import {
  getSourceKeyMapping,
  getParsedContent,
  fetchAndParseCmsContentRecursively,
} from './cmsUtils';
import { getCmsItem } from './utils';

jest.mock('./utils');

describe('getSourceKeyMapping', () => {
  it('stageItemType = journey', () => {
    const items = getSourceKeyMapping('journey');
    const expected = [
      { name: 'Journey Heading', as: 'title' },
      { name: 'Journey Short Description', as: 'description' },
      { name: 'Link', as: 'link' },
    ];
    expect(items).toStrictEqual(expected);
  });

  it('stageItemType = service', () => {
    const items = getSourceKeyMapping('service');
    const expected = [
      { name: 'Service Name', as: 'title' },
      { name: 'Service Short Description', as: 'description' },
      { name: 'Related Online Service', as: 'link' },
    ];
    expect(items).toStrictEqual(expected);
  });

  it('stageItemType = tool', () => {
    const items = getSourceKeyMapping('tool');
    const expected = [
      { name: 'Title', as: 'title' },
      { name: 'ShortDescription', as: 'description' },
      { name: 'StandaloneServiceLink', as: 'link', parse: true },
      { name: 'ADGE', as: 'sponsoringEntity', pull: true },
      { name: 'Login Required', as: 'loginRequired', skipLangParsing: true },
    ];
    expect(items).toStrictEqual(expected);
  });

  it('stageItemType = information', () => {
    const items = getSourceKeyMapping('information');
    const expected = [
      { name: 'GI Name', as: 'title' },
      { name: 'GI Short Description', as: 'description' },
      { name: 'ItemPath', as: 'link', parse: true },
    ];
    expect(items).toStrictEqual(expected);
  });

  it('stageItemType = random', () => {
    const items = getSourceKeyMapping('random');
    const expected: any = [];
    expect(items).toStrictEqual(expected);
  });
});

describe('getParsedContent', () => {
  it('type = ItemPath, lang=en', () => {
    const item =
      '/sitecore/content/bala3nadh/Home/home/aspects-of-life/consultationstraining/businesssupport/BusinessTraining/ManageMyTouristGuideLicence';
    const result = getParsedContent(
      'ItemPath',
      item,
      'en',
      'https://stage.bala3nadh.abudhabi',
    );
    expect(result).toEqual(
      'https://stage.bala3nadh.abudhabi/en/aspects-of-life/consultationstraining/businesssupport/BusinessTraining/ManageMyTouristGuideLicence',
    );
  });

  it('type = ItemPath, lang=ar', () => {
    const item =
      '/sitecore/content/bala3nadh/Home/home/aspects-of-life/consultationstraining/businesssupport/BusinessTraining/ManageMyTouristGuideLicence';
    const result = getParsedContent(
      'ItemPath',
      item,
      'ar',
      'https://stage.bala3nadh.abudhabi',
    );
    expect(result).toEqual(
      'https://stage.bala3nadh.abudhabi/ar-AE/aspects-of-life/consultationstraining/businesssupport/BusinessTraining/ManageMyTouristGuideLicence',
    );
  });

  it('type = ItemPath', () => {
    const item =
      '/sitecore/content/bala3nadh/Home/home/aspects-of-life/consultationstraining/businesssupport/BusinessTraining/ManageMyTouristGuideLicence';
    const result = getParsedContent('ItemPath', item);
    expect(result).toEqual(
      '/en/aspects-of-life/consultationstraining/businesssupport/BusinessTraining/ManageMyTouristGuideLicence',
    );
  });

  it('type = StandaloneServiceLink', () => {
    const item =
      '<link linktype="external" url="https://stage.bala3nadh.abudhabi/services/housing/upc/estidama-requirements-clarification?lang=en" anchor="" target="" />';
    const result = getParsedContent('StandaloneServiceLink', item);
    expect(result).toEqual(
      'https://stage.bala3nadh.abudhabi/services/housing/upc/estidama-requirements-clarification?lang=en',
    );
  });

  it('type = StandaloneServiceLink - invalid', () => {
    const item =
      '<link linktype="external" url=https://stage.bala3nadh.abudhabi/services/housing/upc/estidama-requirements-clarification?lang=en anchor="" target="" />';
    const result = getParsedContent('StandaloneServiceLink', item);
    expect(result).toEqual(item);
  });

  it('type = Journey Image', () => {
    const item = '<image mediaid="{29197336-109A-46E2-BBED-19FFA43D46F1}" />';
    const result = getParsedContent('Journey Image', item);
    expect(result).toEqual('{29197336-109A-46E2-BBED-19FFA43D46F1}');
  });

  it('type = Highlight Image', () => {
    const item = '<image mediaid="{29197336-109A-46E2-BBED-19FFA43D46F1}" />';
    const result = getParsedContent('Highlight Image', item);
    expect(result).toEqual('{29197336-109A-46E2-BBED-19FFA43D46F1}');
  });

  it('type = Entity Logo', () => {
    const item = '<image mediaid="{29197336-109A-46E2-BBED-19FFA43D46F1}" />';
    const result = getParsedContent('Entity Logo', item);
    expect(result).toEqual('{29197336-109A-46E2-BBED-19FFA43D46F1}');
  });

  it('type = Entity Logo - invalid', () => {
    const item = '<image mediaid={29197336-109A-46E2-BBED-19FFA43D46F1} />';
    const result = getParsedContent('Entity Logo', item);
    expect(result).toEqual(item);
  });

  it('type = random', () => {
    const item = 'ABCD';
    const result = getParsedContent('random', item);
    expect(result).toEqual('ABCD');
  });
});

describe('fetchAndParseCmsContentRecursively', () => {
  const mockedCmsApi: any = getCmsItem;

  let req: any;

  beforeEach(() => {
    req = httpMocks.createRequest();
  });

  const mockSuccessfulCmsData = {
    data: {
      data: {
        items: [[{ bar: 'baz' }, { bar: 'baz' }]],
      },
    },
  };

  it('fetched successful cms data', async () => {
    mockedCmsApi.mockReturnValueOnce(mockSuccessfulCmsData);
    mockedCmsApi.mockReturnValueOnce(mockSuccessfulCmsData);
    mockedCmsApi.mockReturnValueOnce(mockSuccessfulCmsData);

    await fetchAndParseCmsContentRecursively(
      'mockCmsId',
      [
        {
          name: 'ADGE',
          as: 'sponsoringEntity',
          pull: true,
        },
      ],
      true,
      req,
    );
  });

  it('fetched failure cms data', async () => {
    mockedCmsApi.mockReturnValueOnce(null);

    await fetchAndParseCmsContentRecursively(
      'mockCmsId',
      [{ name: 'ADGE', as: 'sponsoringEntity' }],
      false,
      req,
    );
  });

  it('catch error cms data', async () => {
    mockedCmsApi.mockRejectedValueOnce({ message: 'error' });

    await fetchAndParseCmsContentRecursively(
      'mockCmsId',
      [{ name: 'ADGE', as: 'sponsoringEntity' }],
      false,
      req,
    );
  });
});
