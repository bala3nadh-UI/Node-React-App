import httpMocks from 'node-mocks-http';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { fetchAndParseCmsContentRecursively } from './cmsUtils';
import fetchCmsDetails from './fetchCmsDetails';

jest.mock('server/utils/response-utils');
jest.mock('./cmsUtils');

describe('routes/smartQuestionnaire/fetchCmsDetails', () => {
  let req: any;
  let res: any;

  const OLD_ENV = process.env;

  const mockedCmsData: any = fetchAndParseCmsContentRecursively;

  beforeEach(() => {
    req = httpMocks.createRequest({
      body: {
        cmsId: 'cmsId',
        requestedData: {
          foo: 'bar',
          bar: true,
        },
      },
      session: {
        bala3nadhUserInfo: {},
      },
    });
    res = httpMocks.createResponse();
    req.log = {
      error: jest.fn(),
    };
    jest.resetModules();
    process.env = { ...OLD_ENV };
  });

  afterAll(() => {
    process.env = OLD_ENV;
  });

  it('should handle success', async () => {
    mockedCmsData.mockReturnValueOnce({
      data: 'Successful data',
    });

    await fetchCmsDetails(req, res);
    expect(createSuccessResponse).toHaveBeenCalled();
  });

  it('should handle fail', async () => {
    mockedCmsData.mockReturnValueOnce(null);

    await fetchCmsDetails(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle exception, env variable is false', async () => {
    process.env.STAGING = 'false';

    mockedCmsData.mockRejectedValueOnce(null);

    await fetchCmsDetails(req, res);
    expect(createErrorResponse).toHaveBeenCalled();

    mockedCmsData.mockRejectedValueOnce({ message: 'error' });

    await fetchCmsDetails(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });

  it('should handle exception, env variable is true', async () => {
    process.env.STAGING = 'true';

    mockedCmsData.mockRejectedValueOnce(null);

    await fetchCmsDetails(req, res);
    expect(createErrorResponse).toHaveBeenCalled();

    mockedCmsData.mockRejectedValueOnce({ message: 'error' });

    await fetchCmsDetails(req, res);
    expect(createErrorResponse).toHaveBeenCalled();
  });
});
