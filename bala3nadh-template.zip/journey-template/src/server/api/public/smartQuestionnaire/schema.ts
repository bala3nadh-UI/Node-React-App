import joi from 'joi';

const scriptRegex = /[{}[\]<>]/;

const genericObjectSchema = joi
  .object()
  .pattern(
    /^/,
    joi.alternatives(
      joi.string().regex(scriptRegex, { invert: true }).allow('').allow(null),
      joi.boolean(),
      joi
        .array()
        .items(
          joi
            .string()
            .regex(scriptRegex, { invert: true })
            .allow('')
            .allow(null),
          joi.boolean(),
          joi.number(),
          joi.link('..'),
          joi.link('...'),
        ),
      joi.number(),
      joi.link('#genericObject'),
    ),
  )
  .id('genericObject');

const genericArraySchema = joi
  .array()
  .items(genericObjectSchema)
  .shared(genericObjectSchema);

const localizedStringSchema = joi.object({
  en: joi.string().required(),
  ar: joi.string().required(),
});

const startQuestionnaireSchema = joi.object({
  questionnaireCmsId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  refKey: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  refCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyInstanceId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyStage: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyStageNameEn: joi
    .string()
    .regex(/^[a-z0-9AA-Z_, .-]+$/)
    .required(),
  journeyStageNameAr: joi
    .string()
    .regex(/^[a-z0-9A-Z\u0600-\u06FF_, .-]+$/)
    .required(),
  journeyStageOrder: joi.number().required(),
});

const completeQuestionnaireSchema = joi.object({
  applicationId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  questionnaireCmsId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  refKey: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  refCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyInstanceId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyStage: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyStageNameEn: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,. -]+$/)
    .required(),
  journeyStageNameAr: joi
    .string()
    .regex(/^[a-z0-9A-Z\u0600-\u06FF_, .-]+$/)
    .required(),
  journeyStageOrder: joi.number().required(),
});

const cancelQuestionnaireSchema = joi.object({
  applicationId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  questionnaireCmsId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  refKey: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  refCode: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyInstanceId: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyStage: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,.-]+$/)
    .required(),
  journeyStageNameEn: joi
    .string()
    .regex(/^[a-z0-9AA-Z_,. -]+$/)
    .required(),
  journeyStageNameAr: joi
    .string()
    .regex(/^[a-z0-9A-Z\u0600-\u06FF_, .-]+$/)
    .required(),
  journeyStageOrder: joi.number().required(),
});

const updateDraftQuestionnaireSchema = joi.object({
  questionnairePath: joi.string().regex(scriptRegex, { invert: true }),
  isPreview: joi.boolean(),
  userJourneyId: joi.string().regex(scriptRegex, { invert: true }),
  draftData: joi.object().keys({
    questionnaireStatus: joi.string().regex(scriptRegex, { invert: true }),
    questionnaireResponses: joi.object().keys({
      adlApplicationId: joi
        .string()
        .regex(scriptRegex, { invert: true })
        .allow('')
        .allow(null),
      activeQuestionId: joi
        .string()
        .regex(scriptRegex, { invert: true })
        .allow('')
        .allow(null),
      data: joi.array().items(
        joi.object().keys({
          questionId: joi.string().regex(scriptRegex, { invert: true }),
          description: joi.alternatives(
            joi
              .string()
              .regex(scriptRegex, { invert: true })
              .allow('')
              .allow(null),
            joi.boolean(),
            joi.object(),
            joi.array(),
            joi.number(),
          ),
          optionData: joi.alternatives(genericObjectSchema, genericArraySchema),
        }),
      ),
      outputs: genericObjectSchema,
      computedOptionData: joi.boolean(),
    }),
  }),
  guestUserInstanceId: joi
    .string()
    .regex(scriptRegex, { invert: true })
    .allow('')
    .allow(null),
  isDynamicSQ: joi.boolean(),
  dynamicSQConfig: genericObjectSchema,
});

const dynamicQuestionSchema = joi
  .object({
    id: joi.string().required(),
    title: localizedStringSchema.required(),
    shortDescription: localizedStringSchema.required(),
    answerType: joi
      .alternatives(
        joi
          .object({
            field: joi.string().valid('input').required(),
          })
          .unknown(true),
        joi
          .object({
            field: joi.string().valid('inputNumber').required(),
          })
          .unknown(true),
        joi
          .object({
            field: joi.string().valid('inputTelephone').required(),
          })
          .unknown(true),
        joi
          .object({
            field: joi.string().valid('textArea').required(),
          })
          .unknown(true),
        joi
          .object({
            field: joi.string().valid('radioGroup').required(),
            items: joi.array().required(),
          })
          .unknown(true),
        joi
          .object({
            field: joi.string().valid('checkboxGroup').required(),
            items: joi.array().required(),
          })
          .unknown(true),
        joi
          .object({
            field: joi.string().valid('select').required(),
            items: joi.array().required(),
          })
          .unknown(true),
        joi
          .object({
            field: joi.string().valid('selectorAccordion').required(),
            items: joi.array().required(),
          })
          .unknown(true),
        joi
          .object({
            field: joi.string().valid('selectorCard').required(),
            options: joi.array().required(),
          })
          .unknown(true),
      )
      .required(),
  })
  .unknown(true);

export {
  startQuestionnaireSchema,
  completeQuestionnaireSchema,
  cancelQuestionnaireSchema,
  updateDraftQuestionnaireSchema,
  dynamicQuestionSchema,
};
