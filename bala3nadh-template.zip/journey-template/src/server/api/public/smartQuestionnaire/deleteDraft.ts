import { Request, Response } from 'express';
import {
  getQuestionnaireInstanceByFilter,
  deleteQuestionnaireInstance,
} from 'server/services/io/smartQuestionnaire';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { checkUserSession } from './utils';

interface SQConfigRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

const deleteDraft = async (req: SQConfigRequest, res: Response) => {
  try {
    // Parse body
    const {
      questionnairePath,
      isPreview,
      userJourneyId,
      guestUserInstanceId,
    } = req.body;

    // Check if user session exists
    const sessionExists = checkUserSession(req);

    let queryFilter: any = {};

    if (sessionExists) {
      // Fetch user uuid
      const userId = req.session.bala3nadhUserInfo['User Unique Identifier'];

      queryFilter = {
        userJourneyId,
        userId,
        questionnairePath,
        isPreview,
      };
    } else {
      // For guest user, query on id
      queryFilter = {
        id: guestUserInstanceId,
        userId: 'guest',
      };
    }

    const latestDraftData = await getQuestionnaireInstanceByFilter(
      req,
      queryFilter,
    );

    if (!latestDraftData) {
      return createErrorResponse(req, res, 'Could not find draft record');
    }

    await deleteQuestionnaireInstance(req, latestDraftData.id);
    return createSuccessResponse(res, 'Success');
  } catch (e) {
    return createErrorResponse(
      req,
      res,
      'Failed to update questionnaire draft data',
      process.env.STAGING === 'true' ? e?.message : '',
    );
  }
};

export default deleteDraft;
