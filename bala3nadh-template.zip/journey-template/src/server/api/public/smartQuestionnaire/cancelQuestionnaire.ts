import { Request, Response } from 'express';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { adlockerUpsertApplication } from './utils';
import { cancelQuestionnaireSchema } from './schema';

const cancelQuestionnaire = async (req: Request, res: Response) => {
  try {
    const { error: validationError } = cancelQuestionnaireSchema.validate(
      req.body,
    );
    if (validationError) {
      return createErrorResponse(
        req,
        res,
        'Invalid data in request body',
        validationError,
      );
    }
    const cancelQuestionnaireResponse = await adlockerUpsertApplication(
      'DELETE',
      'Initiated',
      req,
    );
    if (cancelQuestionnaireResponse.status === 'error') {
      return createErrorResponse(
        req,
        res,
        'Failed to cancel ADLocker record',
        process.env.STAGING === 'true'
          ? cancelQuestionnaireResponse.message
          : '',
      );
    }
    return createSuccessResponse(res, 'Success', {
      ...cancelQuestionnaireResponse,
      success: true,
    });
  } catch (ex) {
    return createErrorResponse(
      req,
      res,
      'Failed to insert ADLocker record',
      process.env.STAGING === 'true' ? ex?.message : '',
    );
  }
};

export default cancelQuestionnaire;
