import { Request, Response } from 'express';
import {
  getQuestionnaireConfigByFilter,
  getQuestionnaireInstanceByFilter,
  createQuestionnaireInstance,
} from 'server/services/io/smartQuestionnaire';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import { checkUserSession } from './utils';
import {
  fetchAndParseCmsContentRecursively,
  getSourceKeyMapping,
} from './cmsUtils';
import {
  handleFetchConfig as handleDynamicSQFetchConfig,
  stripOptions as stripOptionsFromDynamicSQ,
} from './dynamicQuestionnaireUtils';

interface SQConfigRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

// eslint-disable-next-line complexity
const fetchConfig = async (req: SQConfigRequest, res: Response) => {
  try {
    // Parse body
    const { questionnairePath, isPreview, userJourneyId } = req.body;

    // Check if user session exists
    const sessionExists = checkUserSession(req);

    const userId = sessionExists
      ? req.session.bala3nadhUserInfo['User Unique Identifier']
      : 'guest';

    // Skip fetch of questionnaire instance for guest user in preview or standalone
    const skipFetch =
      !sessionExists && (userJourneyId === 'standalone' || isPreview);

    let shouldInitDraft = false;
    let latestDraftData: any;

    if (skipFetch) {
      latestDraftData = null;
    } else {
      // Attempt fetch draft
      latestDraftData = await getQuestionnaireInstanceByFilter(req, {
        userJourneyId,
        userId,
        questionnairePath,
        isPreview,
      });
    }

    if (
      !latestDraftData ||
      latestDraftData.questionnaireStatus === 'inactive'
    ) {
      // Should create new draft instance
      shouldInitDraft = true;
    }
    const shouldFetchLatestVersion = shouldInitDraft;

    // Attempt fetch config
    const questionnaireConfig = await getQuestionnaireConfigByFilter(req, {
      questionnairePath,
      isPreview,
      id: shouldFetchLatestVersion
        ? undefined
        : latestDraftData?.questionnaireDeploymentId,
    });

    if (!questionnaireConfig) {
      // no questionnaire config found. return null and let frontend handle error
      return createSuccessResponse(res, 'Success', questionnaireConfig);
    }

    // eslint-disable-next-line
    const cmsId = questionnaireConfig.config?.questionnaireCmsItem?.cmsId;
    let cmsData: any = {
      isFetched: false,
    };

    const isDataSourceDynamic =
      questionnaireConfig.config?.dataSourceSettings?.dataSource === 'dynamic';

    const dynamicQuestionnaireDraftData = shouldInitDraft
      ? undefined
      : latestDraftData?.questionnaireResponses?.dynamicQuestionnaireData;

    if (!isPreview && cmsId) {
      const cmsTemplateMapping = getSourceKeyMapping('tool');

      const cmsResponse = await fetchAndParseCmsContentRecursively(
        cmsId,
        cmsTemplateMapping,
        true,
        req,
      );

      const cmsLoginRequired = cmsResponse?.loginRequired;
      const isLoginRequired =
        typeof cmsLoginRequired === 'string'
          ? cmsLoginRequired.toLowerCase() === 'true'
          : cmsLoginRequired === true;

      if (isLoginRequired && userId === 'guest') {
        return createSuccessResponse(res, 'Success', {
          loginRequired: isLoginRequired,
          ...questionnaireConfig,
        });
      }

      cmsData = {
        isFetched: true,
        loginRequired: isLoginRequired,
        cmsId,
        data: {
          ...cmsResponse,
        },
      };
    }

    let dynamicQuestionnaireData = null;
    if (
      isDataSourceDynamic &&
      !(dynamicQuestionnaireDraftData?.questions.length > 0)
    ) {
      const dynamicRes = await handleDynamicSQFetchConfig(
        req,
        questionnaireConfig.config.dataSourceSettings.endpoint,
      );
      if (dynamicRes.showError) {
        return createSuccessResponse(res, 'Success', dynamicRes);
      }
      dynamicQuestionnaireData = {
        ...dynamicRes,
        endpoint: questionnaireConfig.config.dataSourceSettings?.endpoint,
      };
    } else if (isDataSourceDynamic) {
      dynamicQuestionnaireData = dynamicQuestionnaireDraftData;
    }

    if (shouldInitDraft) {
      // Draft data not found, create a new record
      latestDraftData = await createQuestionnaireInstance(req, {
        userJourneyId,
        userId,
        questionnaireDeploymentId: questionnaireConfig.id,
        questionnairePath,
        isPreview,
        questionnaireResponses: {
          dynamicQuestionnaireData: stripOptionsFromDynamicSQ(
            dynamicQuestionnaireData,
          ),
        },
      });
    }

    // Return config injected with draft values
    return createSuccessResponse(res, 'Success', {
      ...questionnaireConfig,
      ...dynamicQuestionnaireData,
      draftData: {
        questionnaireStatus: latestDraftData.questionnaireStatus,
        questionnaireInstanceId: latestDraftData.id,
        adlApplicationId:
          latestDraftData.questionnaireResponses?.adlApplicationId || '',
        questionnaireResponses:
          latestDraftData.questionnaireResponses?.data || [],
        activeQuestionId:
          latestDraftData.questionnaireResponses?.activeQuestionId || '',
        dynamicDropdownOptions:
          latestDraftData.questionnaireResponses?.dynamicDropdownOptions || {},
        computedOptionData:
          latestDraftData.questionnaireResponses?.computedOptionData,
      },
      guestUserInstanceId: sessionExists ? '' : latestDraftData.id,
      cmsData,
    });
  } catch (e) {
    return createErrorResponse(
      req,
      res,
      'Failed to load questionnaire config',
      process.env.STAGING === 'true' ? e?.message : '',
    );
  }
};

export default fetchConfig;
