import { IVariables } from '@bala3nadh/app-composer';
import { Request } from 'express';
import config from 'config';
import ajaxClient from 'server/services/ajaxClient';
import { dynamicQuestionSchema } from './schema';

const fetchDynamicQuestion = async (
  req: Request,
  endpoint: string,
  questionnaireResponses: IVariables = {},
  questionnaireOrder: string[] = [],
) => {
  const url = `${config.serviceApiBaseUrl}${endpoint}`;

  const data = {
    questionnaireResponses,
    questionnaireOrder,
  };

  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    [config.gateway.header]: config.gateway.key,
  };

  const requestConfig: any = {
    url,
    method: 'post',
    headers,
    data,
  };

  const result = await ajaxClient(requestConfig, req);

  return result.data.data?.data || result.data.data || result.data;
};

const parseDynamicQuestion = (
  question: IVariables,
  relatedAction: IVariables | undefined,
) => {
  const relatedActionProps = relatedAction?.cmsId
    ? {
        hasRelatedAction: true,
        cmsId: relatedAction.cmsId,
        linkTarget: relatedAction.linkTarget,
        supportText: relatedAction.text,
      }
    : {
        hasRelatedAction: false,
      };

  const validationProps = question.answerType.validation
    ? {
        validation: 'customRegex',
        customRegex: question.answerType.validation,
      }
    : {};

  return {
    ...question,
    questionId: question.id,
    questionName: question.id,
    stepTrackerLabel: question.shortDescription,
    id: undefined,
    answerType: undefined,
    shortDescription: undefined,
    inputProps: {
      ...question.answerType,
      inputType: question.answerType.field,
      field: undefined,
      ...validationProps,
    },
    visibilityCriteria: [],
    relatedAction: relatedActionProps,
  };
};

const validateDynamicQuestion = (
  question: IVariables,
  questionStack?: string[],
) => {
  const { error: validationError } = dynamicQuestionSchema.validate(question);

  if (validationError) {
    return validationError;
  }

  if (!questionStack) {
    return null;
  }

  if (questionStack.includes(question.id)) {
    return 'Duplicate Question ID';
  }

  return null;
};

const stripOptions = (dynamicQuestionnaireData: IVariables) => {
  if (!dynamicQuestionnaireData) {
    return dynamicQuestionnaireData;
  }

  return {
    ...dynamicQuestionnaireData,
    questions: dynamicQuestionnaireData.questions?.map((el: IVariables) => ({
      ...el,
      inputProps: {
        ...el.inputProps,
        items: undefined,
        options: undefined,
      },
    })),
  };
};

const handlePreviousQuestion = (
  draftData: IVariables,
  ioDraftData: IVariables,
  dynamicSQConfig: IVariables,
) => {
  const { dynamicQuestionnaireData } = ioDraftData.questionnaireResponses;
  const questions = (
    dynamicQuestionnaireData.questions || []
  ).filter((el: IVariables) =>
    (dynamicSQConfig.questionStack || []).includes(el.questionId),
  );

  return {
    draftData: {
      ...draftData,
      questionnaireResponses: {
        ...draftData.questionnaireResponses,
        dynamicQuestionnaireData: {
          ...dynamicQuestionnaireData,
          ...dynamicSQConfig,
          questions,
        },
      },
    },
    responseData: {},
  };
};

const handleNextQuestion = async (
  req: Request,
  draftData: IVariables,
  ioDraftData: IVariables,
  dynamicSQConfig: IVariables,
) => {
  const { dynamicQuestionnaireData } = ioDraftData.questionnaireResponses;
  const questionStack = dynamicSQConfig.questionStack || [];

  const nextQuestionResponse = await fetchDynamicQuestion(
    req,
    dynamicQuestionnaireData.endpoint,
    dynamicSQConfig.questionnaireResponses,
    questionStack,
  );

  if (nextQuestionResponse.showError) {
    return {
      draftData: {},
      responseData: {
        ...nextQuestionResponse,
      },
    };
  }

  if (nextQuestionResponse.showResults) {
    return {
      draftData: {
        ...draftData,
        questionnaireResponses: {
          ...draftData.questionnaireResponses,
          dynamicQuestionnaireData: {
            ...dynamicQuestionnaireData,
            ...dynamicSQConfig,
          },
          activeQuestionId: 'output',
        },
      },
      responseData: {
        activeQuestionId: 'output',
      },
    };
  }

  const validationError = validateDynamicQuestion(
    nextQuestionResponse.question,
    questionStack,
  );

  if (validationError) {
    return {
      draftData: {},
      responseData: {
        showError: true,
        error: validationError,
      },
    };
  }

  const parsedQuestion = parseDynamicQuestion(
    nextQuestionResponse.question,
    nextQuestionResponse.relatedAction,
  );

  return {
    draftData: {
      ...draftData,
      questionnaireResponses: {
        ...draftData.questionnaireResponses,
        dynamicQuestionnaireData: stripOptions({
          ...dynamicQuestionnaireData,
          ...dynamicSQConfig,
          questions: [
            ...(dynamicQuestionnaireData.questions || []),
            parsedQuestion,
          ],
        }),
        activeQuestionId: parsedQuestion.questionId,
      },
    },
    responseData: {
      question: parsedQuestion,
      activeQuestionId: parsedQuestion.questionId,
    },
  };
};

const handleUpdateDraft = async (
  req: Request,
  draftData: IVariables,
  ioDraftData: IVariables,
  dynamicSQConfig: IVariables,
) => {
  if (dynamicSQConfig.requestType === 'next') {
    return handleNextQuestion(req, draftData, ioDraftData, dynamicSQConfig);
  }
  if (dynamicSQConfig.requestType === 'previous') {
    return handlePreviousQuestion(draftData, ioDraftData, dynamicSQConfig);
  }
  return {
    draftData: {
      ...draftData,
      questionnaireResponses: {
        ...draftData.questionnaireResponses,
        dynamicQuestionnaireData:
          ioDraftData.questionnaireResponses.dynamicQuestionnaireData,
      },
    },
    responseData: {},
  };
};

const handleFetchConfig = async (req: Request, endpoint: string) => {
  const initQuestionResponse = await fetchDynamicQuestion(req, endpoint);

  if (initQuestionResponse.showResults) {
    return {
      showError: true,
      error: 'Results page without any question',
    };
  }
  if (initQuestionResponse.showError) {
    return {
      ...initQuestionResponse,
    };
  }

  const validationError = validateDynamicQuestion(
    initQuestionResponse.question,
    [],
  );

  if (validationError) {
    return {
      showError: true,
      error: validationError,
    };
  }

  const parsedQuestion = parseDynamicQuestion(
    initQuestionResponse.question,
    initQuestionResponse.relatedAction,
  );

  return {
    questions: [parsedQuestion],
    totalQuestions: initQuestionResponse.totalQuestions,
  };
};

export {
  handleUpdateDraft,
  handleFetchConfig,
  validateDynamicQuestion,
  parseDynamicQuestion,
  stripOptions,
};
