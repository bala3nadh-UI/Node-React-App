import express, { Request, Response } from 'express';
import ajaxClient from 'server/services/ajaxClient';
import { AxiosRequestConfig } from 'axios';
import envConfig from 'config';
import { get } from 'lodash';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import {
  bodyProxyGetMethodExtractor,
  generalBodyProxyExtractor,
} from 'server/api/proxy/handlers/bodyProxyExtractor';
import variablesInjectionHandler, {
  variablesInjectionHandlerForGetHeader,
} from 'server/api/proxy/handlers/variablesInjectionHandler';
import validationHandler from 'server/api/proxy/handlers/validationHandler';
import { getAduAuthHeaders } from '../handlers/authHeaders';

const router = express.Router();
const proxyRequestHandler = async (req: Request, res: Response) => {
  let config: AxiosRequestConfig = {};
  try {
    let url = envConfig.serviceApiBaseUrl + req.path;
    if (envConfig.proxyTestMiddleware) {
      url = url.replace(/(\/Bala3nadhJourney)(.*?)(\/1\.0)/, '$1$2Test$3');
    }
    const params = get(res, 'locals.requestBody.params', {});
    const headers = get(res, 'locals.requestBody.headers', {});
    const aduAuthHeaders = getAduAuthHeaders(req);
    const data = get(res, 'locals.requestBody.body', undefined);
    const proxyOptions = get(res, 'locals.requestBody.proxyOptions', {});
    const targetMethod: any = req.method;
    let contentType: any = {
      'Content-Type': 'application/json',
    };
    if (targetMethod === 'GET' && req.path.match(/2.0/)) {
      contentType = {};
    }
    config = {
      url,
      method: targetMethod,
      params: {
        ...req.query, // request params as it will not be included in the path
        ...params, // user's params
      },
      data,
      headers: {
        'Log-Uuid': req.logUuid,
        [envConfig.gateway.header]: envConfig.gateway.key, // gateway header
        ...contentType,
        ...aduAuthHeaders, // adu auth header
        ...headers, // user's custom headers
      },
      timeout: proxyOptions.timeout || 0, // the default for axios is 0 means not set
      maxContentLength: 20 * 1024 * 1024, // 20 MB
    };
    req.log.info('Ms call config', config);
    const result = await ajaxClient(config, req);
    const resultData = result.data.data || result.data;

    req.log.info('Ms call result', resultData);
    return createSuccessResponse(res, 'Success', resultData);
  } catch (error) {
    req.log.error('Error while process ms proxy call', {
      error,
      config,
      response: error.response?.data,
    });
    return createErrorResponse(req, res, `Api call error `, error);
  }
};

router.get(
  '*',
  validationHandler,
  bodyProxyGetMethodExtractor,
  variablesInjectionHandler,
  variablesInjectionHandlerForGetHeader,
  proxyRequestHandler,
);

router.all(
  '*',
  validationHandler,
  generalBodyProxyExtractor,
  variablesInjectionHandler,
  proxyRequestHandler,
);
export default router;
