import httpMocks from 'node-mocks-http';
import ms from '.';

describe('ms proxy ', () => {
  let req: any;
  let res: any;
  let next: any;

  beforeEach(() => {
    req = httpMocks.createRequest();
    res = {
      header: jest.fn(),
      set: jest.fn(),
      send: jest.fn(),
      json: jest.fn(),
    };
    next = jest.fn();

    req.log = {
      error: jest.fn(),
      info: jest.fn(),
    };
  });
  it('should ', async () => {
    await ms(req, res, next);
  });
});
