import express, { Request, Response } from 'express';
import ajaxClient from 'server/services/ajaxClient';
import { AxiosRequestConfig } from 'axios';
import envConfig from 'config';
import { get } from 'lodash';
import {
  createSuccessResponse,
  createErrorResponse,
} from 'server/utils/response-utils';
import validationHandler from 'server/api/proxy/handlers/validationHandler';
import { getAduAuthHeaders } from '../handlers/authHeaders';

const router = express.Router();

const getRequestedPath = (req: Request, res: Response) => {
  let { path } = req;
  if (res.locals.proxyRequestSchema && req.path.includes('/bpm/')) {
    const start = req.path.indexOf('/bpm/');
    path = req.path.substr(start);
  }
  return path;
};
const proxyRequestHandler = async (req: Request, res: Response) => {
  let config: AxiosRequestConfig = {};
  try {
    const path = getRequestedPath(req, res);
    const url = envConfig.adu.host + path;
    const aduAuthHeaders = getAduAuthHeaders(req, true);
    const targetMethod: any = req.method.toLocaleLowerCase();
    const data = targetMethod.includes('get', 'delete')
      ? undefined
      : get(req, 'body', {});
    config = {
      url,
      method: targetMethod,
      params: {
        ...req.query, // request params as it will not be included in the path
      },
      data,
      headers: {
        'Log-Uuid': req.logUuid,
        [envConfig.gateway.header]: envConfig.gateway.key, // gateway header
        'Content-Type': 'application/json',
        ...aduAuthHeaders, // adu auth header
      },
      maxContentLength: 20 * 1024 * 1024, // 20 MB
    };
    req.log.info('adu call config', config);
    const result = await ajaxClient(config, req);
    const resultData = result.data.data || result.data;
    req.log.info('adu call result', resultData);
    return createSuccessResponse(res, 'Success', resultData);
  } catch (error) {
    req.log.error('Error while process adu proxy call', {
      error,
      config,
      response: error.response?.data,
    });
    return createErrorResponse(req, res, `adu call error `, error);
  }
};

router.all('*', validationHandler, proxyRequestHandler);
export default router;
