import { Request, Response, NextFunction } from 'express';
import { isObject } from 'lodash';

export const bodyProxyGetMethodExtractor = (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  try {
    res.locals.requestBody = {};
    const queryData: string = (req.query.data || '') as string;
    const configData = JSON.parse(queryData);
    if (isObject(configData)) {
      delete req.query.data;
      res.locals.requestBody = configData;
    }
  } catch (e) {
    req.log.error('The query does not have proxy configuration', e);
  } finally {
    next();
  }
};

export const generalBodyProxyExtractor = (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  try {
    res.locals.requestBody = {};
    const { body } = req;
    const HasBodyConfig = Object.keys(body).some(key =>
      ['body', 'params', 'headers', 'proxyOptions'].includes(key),
    );
    res.locals.requestBody = HasBodyConfig ? body : { body };
  } catch (e) {
    req.log.error('The proxy body has a problem', e);
  } finally {
    next();
  }
};
