import { Request, Response, NextFunction } from 'express';
import { get } from 'lodash';
import config from 'config';

interface ProcessStringifiedBodyRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

function processStringifiedBody(
  req: ProcessStringifiedBodyRequest,
  stringedBody: string,
): string {
  let parsedBody = stringedBody.replace(
    /{{configVars\.([\w.]*)}}/g,
    (matched: string, configVar: string) => {
      return get(config, configVar);
    },
  );
  // Inject user data
  parsedBody = parsedBody.replace(
    /{{user\.([\w. ]*)}}/g,
    (matched: string, userVar: string) => {
      return get(req?.session?.bala3nadhUserInfo, userVar);
    },
  );

  return JSON.parse(parsedBody);
}

export default function variablesInjectionHandler(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const bodyData = res.locals.requestBody;
    const stringedBody = JSON.stringify(bodyData);
    const parsedBody = processStringifiedBody(req, stringedBody);
    res.locals.requestBody = parsedBody;
  } catch (error) {
    req.log.error('Error while parsing injection vars in proxy body', req);
  } finally {
    next();
  }
}

export function variablesInjectionHandlerFromBody(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const bodyData = req.body;
    const stringedBody = JSON.stringify(bodyData);
    const parsedBody = processStringifiedBody(req, stringedBody);
    req.body = parsedBody;
  } catch (error) {
    req.log.error('Error while parsing injection vars in request body', req);
  } finally {
    next();
  }
}

export function variablesInjectionHandlerForGetHeader(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const [url, query] = req.originalUrl.split('?data=');
    const decodedQuery = JSON.stringify(decodeURIComponent(query));
    const parsedQuery = processStringifiedBody(req, decodedQuery);
    const enCodedQuery = encodeURIComponent(parsedQuery);
    req.originalUrl = query ? `${url}?data=${enCodedQuery}` : req.originalUrl;
  } catch (error) {
    req.log.error(
      'Error while parsing injection env vars in GET query params',
      error,
    );
  } finally {
    next();
  }
}
