import httpMocks from 'node-mocks-http';
import { variablesInjectionHandlerForGetHeader } from './variablesInjectionHandler';

describe('variablesInjectionHandlerForGetHeader', () => {
  let req: any;
  let res: any;
  let next: any;
  beforeEach(() => {
    req = httpMocks.createRequest();
    res = httpMocks.createResponse();
    next = jest.fn();
  });
  test('test with encode URI', () => {
    req.originalUrl = ` /services/housing/getList?data=%7B%22body%22%3Anull%2C%22headers%22%3A%7B%22Accept%22%3A%22application%2Fjson%22%2C%22elkeytoken%22%3A%22%7B%7BconfigVars.doe.elKeyToken%7D%7D%22%2C%22elkey%22%3A%22%7B%7BconfigVars.doe.elKey%7D%7D%22%7D%7D`;
    variablesInjectionHandlerForGetHeader(req, res, next);
  });

  test('test without encode URI', () => {
    req.originalUrl = ` /services/housing/getList`;
    variablesInjectionHandlerForGetHeader(req, res, next);
  });
});
