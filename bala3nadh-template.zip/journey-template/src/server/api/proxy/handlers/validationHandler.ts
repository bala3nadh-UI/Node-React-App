import { Request, Response, NextFunction } from 'express';
import { createErrorResponse } from '@bala3nadh/response';

export const schemaValidator = (schema: any, data: any) => {
  if (schema) {
    const { error } = schema.validate(data);
    if (error) throw new Error(`Validation error: ${error.message}`);
  }
  return true;
};

const validationHandler = (req: Request, res: Response, next: NextFunction) => {
  try {
    const { proxyRequestSchema } = res.locals;
    const querySchema = proxyRequestSchema?.query;
    const bodySchema = proxyRequestSchema?.body;
    schemaValidator(querySchema, req.query);
    schemaValidator(bodySchema, req.body);
    return next();
  } catch (error) {
    req.log.error('ms proxy call - validation error', error);
    return createErrorResponse(req, res, 500, error.message, error);
  }
};

export default validationHandler;
