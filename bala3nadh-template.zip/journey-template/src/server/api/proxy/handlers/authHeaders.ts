import { Request } from 'express';
import envConfig from 'config';

interface GetAduAuthHeadersRequest extends Request {
  session: Request['session'] & {
    bala3nadhUserInfo?: any;
  };
}

export const getAduAuthHeaders = (
  req: GetAduAuthHeadersRequest,
  aduMs: boolean = false,
) => {
  const isAduMs = aduMs || req.path.toLocaleLowerCase().match(/adu-[\w-]*\//g);
  const { proxyAuthEndpoints } = envConfig;
  const isAuthEnabled = proxyAuthEndpoints.map(i =>
    req.path.toLowerCase().includes(i.toLowerCase()),
  );
  const aduAuthHeaders: any = {};
  if (req.session?.bala3nadhUserInfo && (isAduMs || isAuthEnabled)) {
    const { SmartPassToken, ThirdPartyToken } = req.session.bala3nadhUserInfo;
    aduAuthHeaders.Authorization = SmartPassToken;
    aduAuthHeaders['Auth-Third-Party-Token'] = ThirdPartyToken;
    aduAuthHeaders.Provider = req.session.bala3nadhUserInfo.provider || 'smartpass';
  }
  return aduAuthHeaders;
};
