import smartpass from '@bala3nadh/smartpass';
import sessionStore from 'server/session-store';

jest.mock('@bala3nadh/smartpass');
jest.mock('@bala3nadh/request');
jest.mock('server/session-store');
jest.mock('server/services/io/ioClient');
jest.mock('config', () => ({
  projectName: 'projectName',
  basePath: 'basePath',
  smartpass: {
    host: {
      public: 'public',
      private: 'private',
    },
    endpoints: {
      generateBala3nadhUuid: 'generateBala3nadhUuid',
    },
  },
  uaepass: {
    host: 'test/uaepass',
    endpoints: {
      signDocument: 'test/sign',
      downloadSignedDocument: 'test/download',
    },
  },
  io: {
    client: 'io_client_url',
    memory: 'io_memory_url',
  },
}));
jest.mock('server/utils/logger', () => ({
  getService: () => ({
    error: jest.fn(),
    info: jest.fn(),
  }),
}));

describe('smartpass', () => {
  let initialApiGatewayHeader: any;
  let initialApiGatewayKey: any;

  beforeEach(() => {
    initialApiGatewayHeader = process.env.API_GATEWAY_HEADER;
    initialApiGatewayKey = process.env.API_GATEWAY_KEY;
  });

  afterEach(() => {
    process.env.API_GATEWAY_HEADER = initialApiGatewayHeader;
    process.env.API_GATEWAY_KEY = initialApiGatewayKey;
  });

  it('should call smartpass() with correct params', () => {
    process.env.API_GATEWAY_HEADER = 'apiGatewayHeader';
    process.env.API_GATEWAY_KEY = 'apiGatewayKey';

    jest.isolateModules(() => {
      require('./smartpass'); // eslint-disable-line global-require
    });

    expect(smartpass).toHaveBeenCalledWith(
      expect.objectContaining({
        sessionStore: sessionStore.getSessionStore(false),
        projectName: expect.any(String),
        appNestedPath: expect.any(String),
        apiGateway: {
          header: expect.any(String),
          key: expect.any(String),
        },
        host: {
          public: expect.any(String),
          private: expect.any(String),
        },
        endpoints: {
          generateBala3nadhUuid: expect.any(String),
        },
        demoUsers: expect.any(Array),
      }),
    );
  });

  it('should call smartpass() with correct params if variables is undefined', () => {
    process.env.API_GATEWAY_HEADER = '';
    process.env.API_GATEWAY_KEY = '';

    jest.isolateModules(() => {
      require('./smartpass'); // eslint-disable-line global-require
    });

    expect(smartpass).toHaveBeenCalledWith(
      expect.objectContaining({
        apiGateway: {
          header: '',
          key: '',
        },
      }),
    );
  });
});
