import simulatorEngine from '@bala3nadh/simulator-engine';
import ajaxClient from 'server/services/ajaxClient';
import config from 'config';
import bala3nadhLogger from 'server/utils/logger';
import authConfig from '../config/authConfig';

const logger = bala3nadhLogger.getService();

export default simulatorEngine({
  logger,
  service: ajaxClient,
  bala3nadhUrl: config.cms.bala3nadhUrl,
  apiGateway: {
    header: authConfig.apiGateway.header,
    key: authConfig.apiGateway.key,
  },
  docConverter: {
    host: config.documentConverter.host,
    endpoint: config.documentConverter.endpoints.htmlToPdf,
  },
  io: {
    name: config.projectName,
    host: `${config.io.db}`,
  },
  ioMemory: {
    name: config.projectName,
    host: `${config.io.memory}`,
  },
  cms: {
    host: config.cms.host,
    endpoint: {
      journeyItems: config.cms.journeyItems.endpoint,
    },
  },
  serviceApi: {
    host: config.serviceApiBaseUrl,
  },
  globalContext: {
    host: `${config.serviceApiBaseUrl}/${config.globalContext.endpoint}`,
    endpoint: '/context',
  },
  gsp: {
    host: config.gsp.host,
    endpoint: {
      getServiceByCode: config.gsp.serviceByCode.endpoint,
    },
  },
});
