import app from 'server/app';
import cms from 'server/cms';
// import gsp from 'server/gsp';
import bala3nadhLogger from 'server/utils/logger';
import appUtils from '@bala3nadh/application-utils/server';

import config from 'config';

// Hooks
import { onStartProd } from 'server/hooks';

const logger = bala3nadhLogger.getService();
const cmsHook = cms.hooks.start;
// const gspHook = gsp.hooks.start; // use this code in your repository if you want to cache cards but also remove cacheAll from default

//
// Launch the server
// -----------------------------------------------------------------------------
if (!module.hot) {
  Promise.resolve().then(() => {
    onStartProd(cmsHook).then(() => {
      // add gspHook parameter if you have uncommented the line 14 (onStartProd(cmsHook, gspHook ))
      const server = app.listen(config.port, () =>
        logger.info(
          `The server is running at https://localhost:${config.port}/${process.env.APP_NESTED_PATH}`,
        ),
      );

      appUtils.services.gracefulShutdown(server);

      return server;
    });
  });
}

//
// Hot Module Replacement
// -----------------------------------------------------------------------------
if (module.hot) {
  app.hot = module.hot;
}

export default app;
