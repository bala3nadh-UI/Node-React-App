import getSmartpassParts from '@bala3nadh/smartpass';
import Bala3nadhSessionFactory from 'server/session-store';

import config from 'config';
import smartpassHousing from './smartpass-housing';

const smartpassParts = getSmartpassParts({
  sessionStore: Bala3nadhSessionFactory.getSessionStore(false),
  projectName: config.projectName,
  appNestedPath: config.basePath,
  apiGateway: {
    header: process.env.API_GATEWAY_HEADER || '',
    key: process.env.API_GATEWAY_KEY || '',
  },
  host: {
    public: config.smartpass.host.public,
    private: config.smartpass.host.private,
  },
  endpoints: {
    generateBala3nadhUuid: config.smartpass.endpoints.generateBala3nadhUuid,
  },
  demoUsers: [
    {
      key: 'mockSmartpassUuid-SAU-7',
      data: {
        SmartPassToken:
          'eyJ0eXAiOiJKV1QiLCJraWQiOiI2OVNsM2MrRlV3bloxZ0x6VVdwdzNjL1NNdEk9IiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoiR01ZMzRVYUk3VVplcTFURkt4S1h1QSIsInN1YiI6ImViNjY5YzdlLTBkM2QtNGFkNC04ZDY0LTdhNjNjZDU1ZGYxZiIsImF1ZGl0VHJhY2tpbmdJZCI6ImRlZmM3N2UzLTFkZDYtNDY5Yy05MzBmLWVlNTkwYWI2NTBkZS0xMjExMDYiLCJpc3MiOiJodHRwczovL3N0YWdlLnNtYXJ0cGFzcy5nb3Zlcm5tZW50Lm5ldC5hZTo0NDMvc2VjdXJlL29hdXRoMi9UUkEiLCJ0b2tlbk5hbWUiOiJpZF90b2tlbiIsImF1ZCI6WyJ0YW1tIl0sImNfaGFzaCI6IllJT2QyOU1ka1J1T0k1QzV0cVVvb2ciLCJhY3IiOiJ1c2VybmFtZXBhc3N3b3JkX2NoYWluIiwib3JnLmZvcmdlcm9jay5vcGVuaWRjb25uZWN0Lm9wcyI6IjQ5MmU5NDU5LWJkMmItNGVhNS05YTExLWFjMGM4MTY2MWFhNCIsImF6cCI6InRhbW0iLCJhdXRoX3RpbWUiOjE1NDI0MDA4NDMwMDAsInJlYWxtIjoiL1RSQSIsImV4cCI6MTU0MjQwMTE0NiwidG9rZW5UeXBlIjoiSldUVG9rZW4iLCJpYXQiOjE1NDI0MDA4NDZ9.b4NuYJiBQPBi3Q61XhHjHVhL-aWunkREf8LmRyJvdsvHMAP2Nt7JNCifjRnyB8k36ZswLD17AP6GRpqTw2gkYDLtKehn5QAWvLy6sOto5g5X3a3Elb74t1NCb85MT2mK6QLSpaBzD_WR_dejjO2gQDFKfD6Y2QRbOSlIELqMyM__rArcf-h4RQbTEGOpp7VLWHPTaLkLNinx7BsuvQgTK7fwEHLpnfYcxKGDrlIIQx_6UTmIrEdb2LlIOLypSKEWqyxZEOF_MSZMr2x8IvxtE5iCQQ-wEJOGooackj3_FSnX1qbWh3P2b3hPTtk8mRwH5nTR3-se8XVxsFE9sQBQ_w',
        SmartPassRefreshToken: '6286f0c4-af3d-4eed-90a3-79b845608e00',
        'Nationality EN': 'SAU',
        'First Name EN': 'Demo',
        'Last Name EN': 'Demo',
        'User Unique Identifier': '8cc2ae0a-c064-4b9d-bbc1-63b52ad18a76',
        'Mobile Not Verified': '375291231234',
        Type: 'SOP1',
        ThirdPartyToken:
          'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJlYjY2OWM3ZS0wZDNkLTRhZDQtOGQ2NC03YTYzY2Q1NWRmMWYiLCJpc3MiOiJodHRwczovL3N0YWdlLnNtYXJ0cGFzcy5nb3Zlcm5tZW50Lm5ldC5hZTo0NDMvc2VjdXJlL29hdXRoMi9UUkEiLCJsYXN0bmFtZUVOIjoiQWJkdWwiLCJub25jZSI6ImJqMlAzMjJTanluM1llRjUiLCJ1dWlkIjoiOGNjMmFlMGEtYzA2NC00YjlkLWJiYzEtNjNiNTJhZDE4YTc2IiwibW9iaWxlTm90VmVyaWZpZWQiOiIzNzUyOTEyMzEyMzQiLCJhdWQiOlsidGFtbSJdLCJhY3IiOiJ1c2VybmFtZXBhc3N3b3JkX2NoYWluIiwiZmlyc3RuYW1lRU4iOiJBbWlyIiwiYXpwIjoiYXBpZ3ciLCJhdXRoX3RpbWUiOjE1NDI0MDA4NDYsInVzZXJUeXBlIjoiU09QMSIsImV4cCI6MTU0MjQwMjY0NiwiaWF0IjoxNTQyNDAwODQ2LCJqdGkiOiI0MGVjODQ1Ni1kM2RkLTQ1NTQtOTAzNS02ODZkZWY3MTY5ZTQiLCJlbWFpbCI6InBlcnNvbmEuYWRvc3NAZ21haWwuY29tIn0.LLZLJHubHfOm7iC878AjbMY9bSftGzwgkdxazwHIGde5Tjn1N_q2AJKbDXwhHJuWnNTRpfzHluA9y6CQsBi_XrtgLN6m9-CGq7ES1qKpsWW7c9aq_1QSLKGLznqgYF61r7qOP59Rt8KAVAmi5_tI3xNrehkOv9O13cxXMSjSpdNYY_ny1mnY_l0_Xxltc3tpiDwiweXi5UGZbfXJJKBscBqlCUiOpQx9jOIsBHqzLAcvHiw1KnGMUWdo5H-zm4dPY-vlZ62hEQocGcG6EHP4sMa8KER4vcbON_oHlp58rY1dMJEjDkJ9BK7cPVoPqKiVV9LLWA6KyybOajNuqCgsIw',
      },
    },
    ...smartpassHousing,
  ],
  documentSigning: {
    host: config.uaepass.host,
    endpoints: {
      signDocument: config.uaepass.endpoints.signDocument,
      downloadSignedDocument: config.uaepass.endpoints.downloadSignedDocument,
    },
  },
});

export default smartpassParts;
