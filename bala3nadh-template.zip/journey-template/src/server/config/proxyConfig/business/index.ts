import adcci from './adcci';

export default {
  public: [...adcci.public],
  loggedIn: [...adcci.loggedIn],
  verified: [...adcci.verified],
};
