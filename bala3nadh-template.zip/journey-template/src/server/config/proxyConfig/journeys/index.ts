import investorJourney from './investor-journey';
import businessSimulator from './business-simulator';
import manageYourFarm from './manage-your-farm';
import podJourney from './pod-journey';
import startingIndustrialBusiness from './starting-industrial-business';
import takamulServices from './takamul-services';
import aduMobility from './adu-mobility';
import goldenVisa from './golden-visa';

export default {
  public: [
    ...investorJourney.public,
    ...businessSimulator.public,
    ...manageYourFarm.public,
    ...podJourney.public,
    ...startingIndustrialBusiness.public,
    ...takamulServices.public,
    ...aduMobility.public,
    ...goldenVisa.public,
  ],
  loggedIn: [
    ...investorJourney.loggedIn,
    ...businessSimulator.loggedIn,
    ...manageYourFarm.loggedIn,
    ...podJourney.loggedIn,
    ...startingIndustrialBusiness.loggedIn,
    ...takamulServices.loggedIn,
    ...aduMobility.loggedIn,
    ...goldenVisa.loggedIn,
  ],
  verified: [
    ...investorJourney.verified,
    ...businessSimulator.verified,
    ...manageYourFarm.verified,
    ...podJourney.verified,
    ...startingIndustrialBusiness.verified,
    ...takamulServices.verified,
    ...aduMobility.verified,
    ...goldenVisa.verified,
  ],
};
