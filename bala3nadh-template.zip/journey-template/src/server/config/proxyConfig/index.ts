import jt from './jt';
import business from './business';
import community from './community';
import education from './education';
import housing from './housing';
import mobility from './mobility';
import journeys from './journeys';

export default {
  public: [
    ...jt.public,
    ...business.public,
    ...community.public,
    ...education.public,
    ...housing.public,
    ...mobility.public,
    ...journeys.public,
  ],

  loggedIn: [
    ...jt.loggedIn,
    ...business.loggedIn,
    ...community.loggedIn,
    ...education.loggedIn,
    ...housing.loggedIn,
    ...mobility.loggedIn,
    ...journeys.loggedIn,
  ],
  verified: [
    ...jt.verified,
    ...business.verified,
    ...community.verified,
    ...education.verified,
    ...housing.verified,
    ...mobility.verified,
    ...journeys.verified,
  ],
};
