export default {
  public: [],
  loggedIn: [],
  verified: [],
};
