// https://content-security-policy.com/

import helmet from 'helmet';

const { env } = process;

const TRUSTED_SOURCES = [
  // same domain
  "'self'",
  // and others
  'gstatic.com',
  'journeys-stg.bala3nadh.abudhabi',
  'stage.bala3nadh.abudhabi',
  'js.arcgis.com',
  'portaldev.elab.abudhabi.ae',
  'server.arcgisonline.com',
  'services.arcgisonline.com',
  'stackpath.bootstrapcdn.com',
  'static.arcgis.com',
  'arcgis.sdi.abudhabi.ae',
  'translate.google.com',
  'translate.googleapis.com',
  'www.google.com',
  'www.gstatic.com',
  'www.bala3nadh.abudhabi',
  'stage-api.abudhabi.ae',
  'api.abudhabi.ae',
  'sandboxadmin.prioticket.com',
  'adda-chatbot-prod.azurewebsites.net',
  'ocsdk-prod.azureedge.net',
  // '*.blob.core.windows.net',
  'addadevstorage.blob.core.windows.net',
  'webchatic3.blob.core.windows.net',
  'addastorageaccountuat.blob.core.windows.net',
  // '*.omnichannelengagementhub.com',
  'comms.omnichannelengagementhub.com',
  'orgbb3c15ea-crm15.omnichannelengagementhub.com',
  'earthquake.usgs.gov',
  'onwani.abudhabi.ae',
];

const FRAME_ANCESTORS = [
  "'self'",
  'wb.bala3nadh.abudhabi',
  'journeys-stg.bala3nadh.abudhabi',
];
if (env.NODE_ENV === 'development') {
  TRUSTED_SOURCES.push('localhost:3000');
  FRAME_ANCESTORS.push('localhost:3000');
}

export default {
  contentSecurityPolicy: {
    directives: {
      defaultSrc: helmet.contentSecurityPolicy.dangerouslyDisableDefaultSrc,
      styleSrc: [
        ...TRUSTED_SOURCES,
        "'unsafe-inline'",
        "'unsafe-eval'",
        'blob:',
        'filesystem:',
      ],
      scriptSrc: [
        ...TRUSTED_SOURCES,

        // disable unsafe-eval for production
        "'unsafe-eval'",
        // ...(env.NODE_ENV === 'development' ? ["'unsafe-eval'"] : []),

        'blob:',

        // next line should be commented due to security audit requirements
        // "'unsafe-inline'",

        // below we have exclusions for dev scripts (like react-error-overlay)
        // you'll see warning in console with hashes
        "'sha256-KpHv3zgivMSB4dPnfYfqMt2lBibsYvM36EdoBBAsfbM='",
        "'sha256-CyaL1Is5BrtV1nqGyf5M82XfYCZN/AlWOA1PAYCeQn0='",
        "'sha256-ThhI8UaSFEbbl6cISiZpnJ4Z44uNSq2tPKgyRTD3LyU='",
        "'sha256-NNiElek2Ktxo4OLn2zGTHHeUR6b91/P618EXWJXzl3s='",
        "'sha256-iJzZc68vmFUdQcHFENrt71ytPNej1jN9vfbHsHeC3EY='",
        "'sha256-9E/vN59Vhl5uVfXqJSzWab36nu8sc/qubjpo15R2h3c='",
        "'sha256-MllbaXjKDb8zmCId86PfKk5mI7On1rtSLhAdwB5ydag='",

        // in case you have problems with maps component due to CORS restrictions
        // uncomment next line
        // "'unsafe-eval'",
      ],
      imgSrc: [...TRUSTED_SOURCES, 'blob:', 'data:'],
      objectSrc: ["'none'"],
      mediaSrc: [...TRUSTED_SOURCES],
      workerSrc: [...TRUSTED_SOURCES, 'blob:'],
      connectSrc: [...TRUSTED_SOURCES, 'blob:', 'ws:', 'wss:'],
      frameAncestors: FRAME_ANCESTORS,
    },
  },
  referrerPolicy: { policy: 'strict-origin' },
};
