yarn build --release
cd build
cp ../.env .
ENV=production node server.js
