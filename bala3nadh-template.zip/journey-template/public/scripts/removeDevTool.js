// eslint-disable-next-line no-underscore-dangle
if (typeof window.__REACT_DEVTOOLS_GLOBAL_HOOK__ === 'object') {
  // eslint-disable-next-line no-underscore-dangle
  window.__REACT_DEVTOOLS_GLOBAL_HOOK__.inject = function() {};
}
