#!/usr/bin/env sh

function info {
    printf "\033[0;36m===> \033[0;33m${1}\033[0m\n"
}
info "docker-entrypoint.sh"
################################

# rewritable variables
CHECK_READY_DELAY=${CHECK_READY_DELAY:-5}
###

# while `node docker/isInfrReady.js` ;
# do
#   info "will try again after $CHECK_READY_DELAY sec"
#   sleep ${CHECK_READY_DELAY};
# done

exec "$@"
