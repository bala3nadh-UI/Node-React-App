
### v.0.1.6
* 7c01fd96 - Add dotenv configuration to the gsp and gspAll scripts
### v.0.1.5
* d658a051 - Allow bmp and txt files to upload

### v.0.1.4
* 1a06144e - Remove config.js 

### v.0.0.45
* 00ef1e94 - Enable grid 
---

### v.0.0.44
* 7a199de9 - Update .env_stage 
---

### v.0.0.43
* 69db42b8 - TQA-636 Sanitize file parts 
---

### v.0.0.42
* a584fa7f - Update .gitlab-ci.yml 
---

### v.0.0.41
* 92a4d308 - add tempalte dir and dockerfile for adnet 
---

### v.0.0.40
* b3a2751d - Update .dockerignore 
---

### v.0.0.39
* 27647fa3 - Exclude types.js files from coverage. 
---

### v.0.0.38
* 84a3ad18 - TUM-118: Remove user management code from JT 
---

### v.0.0.37
* 9a4c203e - Add resolution for react-dom (https://github.com/ReactTraining/react-router/issues/6630) 
---

### v.0.0.36
* 09d66fd7 - TJC-229: keep updated analytics dependencies 
---

### v.0.0.35
* 3823c96a - Resolve TJC-229 
---

### v.0.0.34
* 6bfa862d - Extract error handling 
---












