## Quick Info
Journey template provides basic encapsulation for your frontend. Consider app-composer as rendering engine and journey template as basic functionalities around your journey, like CMS, Smartpass login, proxy calls to your ADU micro-service and similar.

## What?
Journey template responsible for creating applications based on app-composer frontend and our standardise backend. It offers basic functionalities like example app-composer configuration (with multiple-tenancy applications running) environment configuration, proxy to communicate to ADU micro-service template and other micro-services and similar. Journey template caters both for journey and lately mostly for developing services, able to host multiple services at once on one repository.

For more details, see [VIDEO TRAINING and detailed documentation](https://confluence.bala3nadh.abudhabi/confluence/display/MJ/Developing+Frontend+with+App+Composer).

## How?

#### Main configuration file - config.ts

Here is an example of configuration file

```
const config = {
  // configuration/app version, please keep updateding
  // for now redux uses this version to disregard the incompatible state
  version: '1.2',
  // default variables, for now title is used
  defaults: {
    title: 'Get Trade License',
  },
  // initial redux state, you can configure per your project need, and there are some default state attributes added automatically
  initialState: {
    formEconomicName: {
      nameEn: '',
      nameAr: '',
    },
  },
  // header for the application
  header: {
    // template you are using for header
    template: 'header',
    // pass any props to template
    props: {},
    // map state and actions
    state: {
      mapState: ['user'],
      mapDispatch: [],
    },
    // do not display for this paths
    hideForPaths: ['/login'],
  },
  // footer for the application
  footer: {
    template: 'footer',
    props: {},
    state: {
      mapState: ['user'],
      mapDispatch: [],
    },
    hideForPaths: ['/login'],
  },
  // pages of the application
  pages: [
    ...home,
    ...form,
    ...summary,
    ...payment
  ],
};
```

You can look at [example app config file included in Journey template](https://gitlab.abudhabi.ae/bala3nadh/templates/journey-template/blob/phase2-composer/src/client/_examples/license-poc/config.ts).

Following configuration elements should be provided when initilising the App Composer.

| Prop name    | Type   | Required | Description                                                                                                   |
| ------------ | :----- | :------- | :------------------------------------------------------------------------------------------------------------ |
| version      | String | Yes      | version of your application, it helps to reset Redux state and resolve other issues with updating the version |
| defaults     | Object | Yes      | for now it accepts the title                                                                                  |
| initialState | Object | Yes      | initial state of your application, look below for ready available values                                      |
| header       | Object | No       | header config                                                                                                 |
| footer       | Object | No       | footer config                                                                                                 |
| pages        | Array  | Yes      | Array of pages available in your app, look below for page configuration example                               |

## Journey template usage of app-composer

When you start you project using Journey template (phase2-composer branch) you will get ready made example.
For setting up please follow [the development experience installing and setting up tutorial](https://confluence.digitalx1.io/confluence/x/fwLNAQ).

Within journey template `src/client/_examples/licence-poc` you will find same structure as mentioned above. By exploring this example project you can get quickly get familiar with app-composer.

How the config is used once it's set up you can take a look at `src/client/App.tsx`.

```
import React from 'react';
import AppComposer from '@bala3nadh/app-composer';
import baseUrl from 'client/utils/baseUrl';
import { config, fetchState, templates } from './_examples/license-poc';

// Once you start developing your own project please use config folder
// import { config, fetchState, templates } from './config';

// simply render the app using AppComposer
const App: React.SFC = () => {
  return (
    <AppComposer
      config={config}
      baseUrl={baseUrl}
      fetchState={fetchState}
      skipFetchState={[ //... array of react router matching paths you want to skip state fetching for ]}
      customTemplates={templates}
    />
  );
};

export default App;
```

## Examples from Workbench

Exported example - [http://localhost:3000/journeys/journey-template/exported/request-for-issuing-permit-for-atm--payment-and-self-service-machines](http://localhost:3000/journeys/journey-template/exported/request-for-issuing-permit-for-atm--payment-and-self-service-machines).

Exported bundle example - [http://localhost:3000/journeys/journey-template/exported-bundle/request-for-issuing-permit-for-atm--payment-and-self-service-machines](http://localhost:3000/journeys/journey-template/exported-bundle/request-for-issuing-permit-for-atm--payment-and-self-service-machines)


## State

For state we are using Redux library but we are providing automatic state management.
All your `initialState` object attributes will get option to be passed to page or updated using `props.actions.{name-of-attribute}.update()` function within pages.
Details on how to use state within pages will be explain below.

There are several state attributes we are adding automatically to state. These are:
**locale** - locale of the applciation - values can be 'en' and 'ar'
**loading** - loading state for each of the pages
**businessKey** - business key of ongoing business process
**instanceId** - instance id of ongoing business process

## Pages

Each page presented above in the configuration is imported and it has it's own config file. You do not have to separate each page in it's own config file but this way you make it more readable. All page config file are located withing `pages` folder.

Here is an example of full page config options.

```
const examplePage = [
  {
    // path of the page, it can be array of paths if you want
    path: '/example-page',
    // unique identified for the page
    uniqueId: 'example-page',
    // name of the template, either from DLS or custom made template
    template: 'simple', // DLSv2 will have 'informational', 'form', 'notice' etc.
    // title of the page, soon we will add support for internationalisation
    title: 'Submit license',
    // init function to be run before page loads
    init: (props: IVariables) => {
        // load data from server
        const data = fetch('/proxy/load/data', 'GET');
        // save data using redux dispatch
        props.actions.data.update(data);
    },
    // fetch variables from process state, array of var names
    fromProcessState: {
        processName: 'processName',
        variables: ['varName']
    },
    // onPageInit is function called after everything has loaded (init function, fromProcessState, translations and similar, state variables)
    // and you can use it to create any new variables or update state
    onPageInit: (props: IVariables) => {
        return {
            newVariable: props.variable ? true : false // get new var from existing ones or similar
        }
    }
    // list of props the template supports
    props: {
        description: 'Page description',
        button: {
            title: 'Submit',
            type: 'primary',
            onClick: (props : IVariables) => {
              // usually for functions props will be passed
              // for example here you can update redux state
              props.actions.formSubmitLicence.update({nameEn: props.input.nameEn, nameAr: props.inout.nameAr})
            }
        }
    },
    // mapping state variables and actions
    state: {
      // array of state attributes to be passed as props to page
      mapState: [
        // you can send simple attribute name
        `formSubmitLicence`,
        // or you can send function to map it from the state
        {
            derivedVariable: state => state.formSubmitLicence.nameEn
        }
      ],
      // array of state attributes you want actions to be passed as props to page
      mapDispatch: [
        // once you pass this attribute in dispatch you will have update action available in page
        // for this case specifically props.actions.formSubmitLicence.update(newValue)
        'formSubmitLicence',
        // data, some data you are using in your stata
        'data'
      ],
    },
    // required options to view the page
    requires: [
      // if page requires you to be logged in then you can use this constant
      REQUIRES_LOGIN,
      // custom requirment to view the page
      {
          // custom test, if returns false app-composer will redirect to redirectTo page
          test: (props: IVariables) => { return licenseSubmitted; },
          redirectTo: '/submit-licence'
      }
    ]
  },
];

export default examplePage;
```

You can look at [example page config included in Journey template](https://gitlab.abudhabi.ae/bala3nadh/templates/journey-template/blob/phase2-composer/src/client/_examples/license-poc/pages/SubmitLicense/index.ts).

Above example illustrates what currently app-composer supports within page configuration.

Let's break down each part so we can dive deeper.

#### General page config

**path** - defined the path of your page, you can use array here if you want multiple paths to show same page
**uniqueId** - unique ID of the page, for analytics and debugging purposes it is good to have unique ID
**template** - provide template name for the page, there will be set of around 20 templates within DLS that you will be using within application, in rare occasions you will define your own templates
**title** - used to set page title within HTML tag, we will expand this by using CMS and other SEO tags

### Preloading data, loading variables from state and processing

With below configuration you can easily allow your page to load data before render, or load variables from process state.

**init** - function to run before page renders, for example load data from APIs and push them to state with props.actions

**fromProcessState** - load list of variables from process state, for example if you have updated state by calling ADGE API in your business process now your can before page loads fetch that data from process state

**onPageInit** - run after all data is loaded, like redux state, init function has run and all process state variables are loaded. This function enabled you to generate new variables based on current ones, for example if process state variable needs to be mapped out to new variable.

### Properties

List of properties will depend based on template. For example form template will accept form fields as props, while notice template will accept type of notice and message to a user.
If you built your custom template, you are the one deciding what props template will accept.
You can also supply props through derived state props using `state.mapState` attribute explained below

### State

`state` has two supported attributes. \*_mapState_ - maps state to page props. You can use simple name mapping just by adding attribute name to the array like mapState: ['attributeFromState'] or you can use regular redux mapping deriving it from state for example

```
  state: {
      mapState: {
          {
              fullName: state => `${state.firstName} ${state.lastName}`
          }
      }
  }
```

**mapDispatch** - Similar to mapping state to props, we can pass actions to page props.
For that we are using mapDispatch. It accepts array of state attributes, and for each attribute it will add update action to page.
For example

```
state: {
  mapDispatch: ['locale', 'name']
}
```

will add two actions to your page props

```
props.actions.locale.update()
props.actions.name.update()

// you can also call resetState to reset all state to initialState
props.actions.resetState();
```

### Requires

Requires specifies if page should be shown. It has two simple options.
Either you can use predefined constants to require page to be shown. Right now we support `REQUIRES_LOGIN` if page requires user to be logged in.
You can also create your custom requires function by passing object like this:

```
requires: {
    test: (props:IVariable) => {
        // base test on props available on page, for example if something was submitted, if it's not redirect back to that page
        return !!props.formSubmitted;
    },
    redirectTo: '/form'
}
```

## Creating custom templates

Most of the needs of the application when it comes to templates should be covered by our DLS version 2. Sometimes and especially in early project phase you might need to develop your custom simple templates.

Template is basically React component, that exposes set of properties that you can use in your page config. We strongly advise on using hooks and functional components for templates.

In order to add new template to your applications, follow below steps:

1. Create functional component template in `config/templates/TEMPLATE_NAME/index.tsx`
2. Make sure you component exports with HOC wrapper `export default withTemplateHooks(ComponentName);` - this will ensure all the templating functionality of app-composer
3. Include your template inside `config/templates/index.ts`. This ensures lazy loading of your template

That's it, once you add your template following above 3 steps you can then defined a page in config that as `template` attribute specified custom template.

You can take a look at custom template at Journey template example - [Notice template](https://gitlab.abudhabi.ae/bala3nadh/templates/journey-template/blob/phase2-composer/src/client/_examples/license-poc/templates/Notice/index.js).

## Adding a demo users

Demo users can be added to `demoUsers` array in src/server/smartpass.ts. To authenticate with demo user you can use the following url: http://localhost:3000/journeys/journey-template/api/smartpass/demo-login?personKey=mockSmartpassUuid-SAU-7. Where instead of journey-template should be the journey name, instead of mockSmartpassUuid-SAU-7 should be user key. More demo user examples can be found here: https://gitlab.abudhabi.ae/bala3nadh/core/packages/smartpass/blob/development/server-src/api/demo/session-data.js.

## Upgrading UI Components

You may upgrade all the DLS UI components

1. To latest release version

```
yarn upgrade:uilib
```

2. To latest pre-release versions (test versions) if that exist

```
yarn upgrade:uilib latest
```

## How to pull updates from the template

From time to time this template gets updates. They might add some functionality of fix bugs. To pull those updates to your project you need to do next steps:

1. Add new remote to your project, with reference to the journey-template repo

```bash
git remote add template git@gitlab.abudhabi.ae:bala3nadh/core/templates/journey-template.git
# or
git remote add template https://gitlab.abudhabi.ae/bala3nadh/core/templates/journey-template.git
```

2. Fetch changes from new remote

```bash
git fetch template
```

3. Create new branch in your repo and merge changes from `journey-template/development`

```bash
git checkout -b updates-from-journey-template
git merge template/development
```

4. Fix conflicts, if there is some. Check code. Commit, push, merge request
