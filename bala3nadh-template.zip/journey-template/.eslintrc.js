module.exports = {
  rules: {
    complexity: ['error', { max: 10 }],
    'prettier/prettier': 'error',
    'react/prop-types': 'off',
    'import/extensions': [
      'error',
      'ignorePackages',
      {
        js: 'never',
        jsx: 'never',
        ts: 'never',
        tsx: 'never',
      },
    ],
  },
  plugins: ['prettier'],
  extends: ['prettier', '@bala3nadh/eslint-config', 'plugin:jsx-a11y/recommended'],
};
