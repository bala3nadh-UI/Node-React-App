#!/usr/bin/env node

const fs = require('fs');

// This is ignored because this script will only be used in development
// eslint-disable-next-line import/no-extraneous-dependencies
const compareVersions = require('compare-versions');

const { execSync } = require('child_process');

const prefix = process.argv[2]
  ? process.argv[2].split('--withPrefix=')[1]
  : false;

if (prefix) {
  // eslint-disable-next-line
  console.log(
    '\n\nNOTE:- Latest versions may include experimental versions\n\n',
  );
}

const fileContent = fs.readFileSync('package.json').toString();
const packages = {};

/* eslint-disable complexity */
fileContent
  .match(/"(@bala3nadh\/ui-lib-v2.+)": "(.+)"/g)
  .filter(str => {
    const match = str.match(/"(@bala3nadh\/ui-lib-v2.+)": "(.+)"/);
    const currentVersion = match[2];

    return !currentVersion.includes('npm:');
  })
  .forEach(str => {
    // eslint-disable-line
    const match = str.match(/"(@bala3nadh\/ui-lib-v2.+)": "(.+)"/);
    const packageName = match[1];
    const currentVersion = match[2];
    const packageVersions = execSync(`yarn info ${packageName} versions`)
      .toString()
      .split('\n')
      .filter(Boolean)
      .filter(line => line !== '[' && line !== ']')
      .map(version => version.match(/'(\d+\.\d+\.\d+.*)'/)[1]);

    let latestProdVersion;
    let latestPrefixVersion;
    // eslint-disable-next-line @typescript-eslint/prefer-for-of
    for (let index = 0; index < packageVersions.length; index += 1) {
      if (prefix) {
        if (packageVersions[index].match(new RegExp(prefix))) {
          latestPrefixVersion = packageVersions[index];
        }
      } else if (packageVersions[index].match(/(\d+\.\d+\.\d+)$/)) {
        latestProdVersion = packageVersions[index];
      }
    }

    const newVersion = prefix ? latestPrefixVersion : latestProdVersion;

    if (prefix && !newVersion) {
      // eslint-disable-next-line no-console
      console.log(`${packageName} is not available with prefix: ${prefix}`);
      return;
    }

    if (compareVersions(newVersion, currentVersion) === 1) {
      packages[packageName] = { currentVersion, newVersion };
      // eslint-disable-next-line
      console.log(`${packageName} new version is available: ${newVersion}`);
    } else {
      // eslint-disable-next-line
      console.log(
        `There is no newer ${
          prefix ? '' : 'production '
        }version of ${packageName}`,
      );
    }
  });

let upgradeCommand = `yarn upgrade`;
let logMessage = '';

Object.keys(packages).forEach(packageName => {
  upgradeCommand = `${upgradeCommand} ${packageName}@${packages[packageName].newVersion}`;
  logMessage = `${logMessage}\n${packageName} updated: ${packages[packageName].currentVersion} --> ${packages[packageName].newVersion}`;
});

if (upgradeCommand !== `yarn upgrade`) {
  execSync(upgradeCommand);
  // eslint-disable-next-line
  console.log(logMessage);
}
