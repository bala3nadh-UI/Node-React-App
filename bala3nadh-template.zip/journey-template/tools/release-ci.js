#!/usr/bin/env node

const envs = [
  process.env.CI_PROJECT_NAME,
  process.env.CI_PROJECT_ID,
  process.env.CI_API_V4_URL,
  process.env.CI_PROJECT_PATH,
  process.env.bala3nadh_CI_USER_NAME,
  process.env.bala3nadh_CI_USER_EMAIL,
  process.env.bala3nadh_CI_USER_TOKEN,
];
const isEnvMissed = envs.some(env => !env);

if (isEnvMissed) {
  console.error('Some env variables are missed');
  process.exit(1);
}

const {
  CI_PROJECT_NAME,
  CI_PROJECT_ID,
  CI_API_V4_URL,
  CI_PROJECT_PATH,
  bala3nadh_CI_USER_NAME,
  bala3nadh_CI_USER_EMAIL,
  bala3nadh_CI_USER_TOKEN,
} = process.env;

const { execSync } = require('child_process');
const { writeFileSync, readFileSync, existsSync } = require('fs');
const axios = require('axios');

const isTemplate = CI_PROJECT_NAME === 'journey-template';

const apiUrl = `${CI_API_V4_URL}/projects/${CI_PROJECT_ID}`;
const repositoryUrl = `https://${bala3nadh_CI_USER_NAME}:${bala3nadh_CI_USER_TOKEN}@gitlab.digitalx1.io/${CI_PROJECT_PATH}.git`;

/**
 * Gets last two release tags
 * @returns {Object}: { currentReleaseTag, prevReleaseTag }
 */
function getLastTag() {
  try {
    execSync('git fetch --tags');

    const tags = execSync(
      'git tag -l "release-*" --sort=-creatordate',
    ).toString();

    return tags.split('\n')[0];
  } catch (e) {
    // eslint-disable-next-line
    console.log(`Failed to get the last release: ${e.message}`);
    return null;
  }
}

/**
 * Returns changleLog betweet 2 commits
 *
 * @param {string} firstHash - start commit hash
 * @param {string} lastHash - end commit hash
 * @returns {string} changeLog
 */
function getChangeLog(firstHash, lastHash) {
  const gitOutput = execSync(
    `git log ${firstHash}..${lastHash} --no-merges --pretty=format:'* %h - %s %+b'`,
  );

  return gitOutput.toString().replace(/"/g, '\\"') || 'No valuable changes';
}

/**
 * Updates change log files
 *
 * @param {string} fileName - change log file name
 * @param {string} content - textual representation of changes
 * @param {string} releaseVersion - release version
 * @returns {void}
 */
function updateChangeLog(fileName, content, releaseVersion) {
  const isChangeLogExists = existsSync(fileName);

  const changeLogMD = isChangeLogExists ? readFileSync(fileName) : '';

  const changeLogObj = `
### v.${releaseVersion}
${content}
---
${changeLogMD}
`;

  writeFileSync(fileName, changeLogObj);

  // eslint-disable-next-line
  console.log(`ChangeLog file '${fileName}' successfully updated`);
}

/**
 * Update journey-template or application version
 *
 * @param {string} filename
 * @param {string} newVersion
 * @returns {undefined}
 */
function updateVersion(filename, newVersion) {
  const propertyName = isTemplate ? 'templateVersion' : 'version';
  const packageJson = JSON.parse(readFileSync(filename));

  packageJson[propertyName] = newVersion || packageJson[propertyName];

  writeFileSync(filename, JSON.stringify(packageJson, null, 2));
  // eslint-disable-next-line
  console.log(`${propertyName} is successfully updated`);
}

/**
 * @param {Object} lastTag
 * @returns {string}
 */
function getNewVersion(lastTag) {
  if (!lastTag) {
    return '1.0.0';
  }

  const lastReleaseVersion = lastTag.replace('release-', '');

  return lastReleaseVersion
    .split('.')
    .map((el, i, list) => (i !== list.length - 1 ? el : parseInt(el, 10) + 1))
    .join('.');
}

/**
 * Commit all changes (changelog and version)
 *
 * @param {string} newTag
 * @returns {undefined}
 */
function commitChanges(newTag) {
  const branch =
    process.env.CI_COMMIT_REF_NAME ||
    execSync('git rev-parse --abbrev-ref HEAD').toString().trim();

  execSync(`git config user.name ${bala3nadh_CI_USER_NAME}`);
  execSync(`git config user.email ${bala3nadh_CI_USER_EMAIL}`);

  execSync('git add --all');
  execSync('git commit -m "[RELEASE] Updated version and CHANGELOG"');

  execSync(`git tag ${newTag}`);

  execSync(`git push --tags ${repositoryUrl} HEAD:${branch}`);
  // eslint-disable-next-line
  console.log(`Changes is successfully committed`);
}

/**
 * @param {string} changeLog
 * @param {string} releaseVersion
 * @param {string} releaseTag
 * @returns {undefined}
 */
function release(changeLog, releaseVersion, releaseTag) {
  const description = `
  ##### CHANGELOG
  ${changeLog}
  `;

  axios({
    url: `${apiUrl}/releases`,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'PRIVATE-TOKEN': bala3nadh_CI_USER_TOKEN,
    },
    data: {
      name: `v.${releaseVersion}`,
      tag_name: releaseTag,
      description,
    },
  }) // eslint-disable-next-line
    .then(() => console.log(`New release is created from ${releaseTag}`))
    .catch(({ message }) =>
      console.error(`Failed to create new release: ${message}`),
    );
}

/* -Start Workflow- */
const currentSha1 =
  process.env.CI_COMMIT_SHORT_SHA ||
  execSync('git rev-parse HEAD').toString().trim();

const lastTag = getLastTag();
const newVersion = getNewVersion(lastTag);
const newTag = `release-${newVersion}`;

const changeLog = lastTag
  ? getChangeLog(lastTag, currentSha1)
  : 'No changes due no last tag';

updateChangeLog('CHANGELOG.md', changeLog, newVersion);
updateVersion('package.json', newVersion);
commitChanges(newTag);
release(changeLog, newVersion, newTag);
