const { execSync } = require('child_process');

/**
 * Checks all less files from src/client for DLS style overriding
 * @returns {Undefined}
 * */
function reviewClientLessFiles() {
  let linesToBeFixed;
  try {
    linesToBeFixed = execSync(
      `grep -n -ri -o -E "\\.uil-[^ \\.,:]+" src/client --include *.less | grep -v -e ".uil-fits" -e ".uil-locale"`,
    );
  } catch (e) {
    return;
  }
  const linesToBeFixedArr = linesToBeFixed.toString().trim().split('\n');

  if (!linesToBeFixedArr.length) {
    return;
  }
  let lastFileName;
  linesToBeFixedArr.forEach(line => {
    const sections = line.split(':');
    if (sections.length === 1) {
      console.error(`   \x1b[31m%s\x1b[0m\n`, sections[0]);
    } else {
      const fileName = sections[0];
      if (fileName && fileName !== lastFileName) {
        lastFileName = fileName;
        console.error(`Problems found in : \x1b[31m%s\x1b[0m`, fileName);
      }
      console.error(
        `   Don't override DLS styles: \x1b[31m%s\x1b[0m\n`,
        sections.slice(-2),
      );
    }
  });
}

reviewClientLessFiles();
