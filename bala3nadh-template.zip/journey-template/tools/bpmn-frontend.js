const fs = require('fs');
const BpmnModdle = require('bpmn-moddle');
const util = require('util');

const readdir = util.promisify(fs.readdir);
const path = require('path');

// joining path of directory
const directoryPath = path.join(
  __dirname,
  '../src/client/_examples/licence-poc/bpmn',
);
const moddle = new BpmnModdle();
//

/**
 * show list of all endpoints in BPMN
 * @returns {Object}
 */
async function getFrontendEndpoints() {
  let xmlStr = false;
  try {
    const files = await readdir(directoryPath);
    const bpmn = files.filter(f => f.indexOf('.bpmn') !== 0);
    if (bpmn.length === 0)
      throw Error(
        'No BPMN files found in your src/client/config/bpmn folder.\nPlease make sure you place latest BPMN diagram in that folder.',
      );

    xmlStr = fs.readFileSync(
      path.join(__dirname, `../src/client/config/bpmn/${bpmn[0]}`),
      'utf8',
    );
  } catch (e) {
    // eslint-disable-next-line
    console.log('Error reading folder', e);
  }

  moddle.fromXML(xmlStr, (err, definitions) => {
    // add a root element
    const endpoints = definitions
      .get('rootElements')
      .filter(el => el.$type === 'bpmn:Process')[0]
      .flowElements.filter(el => el.id.indexOf('path') === 0)
      .map(el => el.name);

    definitions
      .get('rootElements')
      .filter(el => el.$type === 'bpmn:Process')[0]
      .flowElements.filter(el => el.$type === 'bpmn:SubProcess')
      .forEach(subProcess =>
        subProcess.flowElements
          .filter(el => el.id.indexOf('path') === 0)
          .forEach(el => endpoints.push(el.name)),
      );
    // eslint-disable-next-line
    console.log('ENDPOINTS IN CURRENT BPMN');
    // eslint-disable-next-line
    console.log(endpoints.sort());
  });
}

getFrontendEndpoints();
