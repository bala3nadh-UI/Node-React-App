#!/usr/bin/env node

/**
 * Command line script to
 *  1) Get change log from latest tag
 *  2) Save change log to CHANGELOG.json
 *  3) Create tag with new version number
 *  4) Notify in slack #templates channel with brief information
 *
 * Utilized enviromental variables
 *  {SLACK_USER} - username for slack bot to send a message, default value "SLACK_CI_BOT"
 *  {GITLAB_USER_LOGIN} - Gitlab username to be shown in slack message, default value "Unknown user"
 *  {CI_COMMIT_REF_NAME} - suffix for final tag name, optional
 *
 * To run execute script directly in bash "./tag-dev.js" or with yarn "yarn tag:dev"
 * @author Armen Nikoyan<armen.nikoyan@genesis.ae>
 */

const { execSync } = require('child_process');
const { writeFileSync, readFileSync, existsSync } = require('fs');

/**
 * Gets last development tag and next tag version
 * @returns {Object}: { lastDevTag, nextTag }
 */
function getTags() {
  const tags = execSync("git tag -l 'development-*' --sort=-creatordate")
    .toString()
    .split('\n');

  const lastDevTag = tags[0];
  const nextTag = lastDevTag
    .split('.')
    .map((el, i, list) => (i !== list.length - 1 ? el : parseInt(el, 10) + 1))
    .join('.');

  return { lastDevTag, nextTag };
}

/**
 * Returns changleLog betweet 2 commits
 *
 * @param {string} firstHash - start commit hash
 * @param {string} lastHash - end commit hash
 * @returns {string} changeLog
 */
function getChangeLog(firstHash, lastHash) {
  const gitOutput = execSync(
    `git log ${firstHash}..${lastHash} --no-merges --pretty=format:'%h -%d %s (%cd) <%an> %+b'`,
  );

  return gitOutput.toString().replace(/"/g, '\\"') || 'No valuable changes';
}

/**
 * Updates change log files
 *
 * @param {string} fileName - change log file name
 * @param {string} content - textual representation of changes
 * @returns {void}
 */
function updateChangeLog(fileName, content) {
  const ciCommitRefName = process.env.CI_COMMIT_REF_NAME || '';
  const repoURI = execSync('git remote get-url --push origin')
    .toString()
    .split('\n')[0];
  const latestVersion = execSync(`yarn info ${repoURI} 'dist-tags.latest' -s`)
    .toString()
    .trim();
  const suffix = ciCommitRefName
    .replace(/development-\d+\.\d+\.\d+/, '') // replace dev-tag
    .replace('-development', '') // replace dev-branch
    .replace(/-$/, ''); // rstrip with -
  const newVersion =
    latestVersion
      .split('.')
      .slice(0, 3)
      .map((el, index) => (index === 2 ? parseInt(el, 10) + 1 : +el))
      .join('.') + (suffix ? `-${suffix}` : '');

  const isChangeLogExists = existsSync(fileName);

  const changeLogJson = isChangeLogExists ? readFileSync(fileName) : '{}';

  const changeLogObj = JSON.parse(changeLogJson);
  changeLogObj[newVersion] = content || changeLogObj[newVersion] || '';

  writeFileSync(fileName, JSON.stringify(changeLogObj, null, 2));
  execSync(`git add ${fileName}`);
  execSync('git commit -m "Updated CHANGELOG"');
  execSync('git push');
  // eslint-disable-next-line
  console.log(`changeLog file '${fileName}' successfully updated`);
}

/**
 * Broadcast message to slack to specified channel
 *
 * @param {string} channel - slack channel name
 * @param {string} message - message body
 * @param {string} title - message title
 * @param {Array<[string, string]>} fields - additional fields for message
 *  Example [['field title', 'field value'], ...]
 * @returns {void}
 */
function broadcastToSlack(channel, message, title = '', fields = []) {
  const slackUser = process.env.SLACK_USER || 'SLACK_CI_BOT';
  // preprocessing fields
  const additionalFields = fields
    .map(([fieldTitle, value]) => `-e "${fieldTitle}" "${value}"`)
    .join(' ');

  const output = execSync(
    `echo "${message}" | slacktee.sh
      -u "${slackUser}"
      -c "${channel}"
      -a "good"
      -t "${title}"
      ${additionalFields}
      -q -p
    `
      .replace(/\n/gm, '')
      .replace(/ +/g, ' '),
  );
  // eslint-disable-next-line
  console.log('Broadcasted message: ', output.toString());
}

/* -Start Workflow- */
const currentSha1 = execSync('git rev-parse HEAD').toString().trim();

const { lastDevTag, nextTag } = getTags();

const changeLog = getChangeLog(lastDevTag, currentSha1);

// Update CHANGELOG.json
updateChangeLog('CHANGELOG.json', changeLog);

// Push tags to git
execSync(`git tag -a ${nextTag} -m "${changeLog}"`);
execSync(`git push --tags`);

// Populating data for slack message
const updateLink = execSync('git remote get-url --push origin')
  .toString()
  .split('\n')[0]
  .replace('git@', 'https://')
  .replace('.git', '#updates')
  .replace(':bala3nadh', '/bala3nadh');
const gitlabUser = process.env.GITLAB_USER_LOGIN || 'Unknown user';
const lastCommitMessage = execSync('git log -n 1 --pretty="format:%s"');
const tagMessage = execSync(`git tag -n99 --points-at ${currentSha1}`);

// Broadcast message to slack
broadcastToSlack(
  '#templates',
  `To update see section ${updateLink}`,
  `Journey template update to #${nextTag}`,
  [
    ['Deployer: ', gitlabUser],
    ['Commit title: ', lastCommitMessage],
    ['Changes: ', tagMessage],
  ],
);
// eslint-disable-next-line
console.log(`New tag ${nextTag} created`);
