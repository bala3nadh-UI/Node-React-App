const fs = require('fs');
const BpmnModdle = require('bpmn-moddle');
const util = require('util');

const readdir = util.promisify(fs.readdir);
const path = require('path');

// joining path of directory
const directoryPath = path.join(__dirname, '../src/client/config/bpmn');
const moddle = new BpmnModdle();
//

/**
 * show list of all endpoints in BPMN
 * @returns {Object}
 */
async function getFrontendEndpoints() {
  let xmlStr = false;
  try {
    const files = await readdir(directoryPath);
    const bpmn = files.filter(f => f.indexOf('.bpmn') !== 0);
    if (bpmn.length === 0)
      throw Error(
        'No BPMN files found in your src/client/config/bpmn folder.\nPlease make sure you place latest BPMN diagram in that folder.',
      );

    xmlStr = fs.readFileSync(
      path.join(__dirname, `../src/client/config/bpmn/${bpmn[0]}`),
      'utf8',
    );
  } catch (e) {
    // eslint-disable-next-line
    console.log('Error reading folder', e);
  }

  moddle.fromXML(xmlStr, (err, definitions) => {
    // add a root element
    const messageRefs = {};
    definitions
      .get('rootElements')
      .filter(el => el.$type === 'bpmn:Message')
      .forEach(el => {
        messageRefs[el.id] = el.name;
      });

    // console.log('messageRefs', messageRefs);

    const messages = [];
    Object.keys(messageRefs).forEach(ref => {
      const re = new RegExp(`messageRef="${ref}"`, 'g');
      const match = xmlStr.match(re);
      if (match) {
        messages.push(messageRefs[ref]);
      }
    });
    // eslint-disable-next-line
    console.log(messages);
  });
}

getFrontendEndpoints();
