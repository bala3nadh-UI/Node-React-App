const fs = require('fs');
const path = require('path');
const webpack = require('webpack');
const git = require('git-rev-sync');

const WebpackAssetsManifest = require('webpack-assets-manifest');
const nodeExternals = require('webpack-node-externals');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const TerserPlugin = require('terser-webpack-plugin');
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const HardSourceWebpackPlugin = require('hard-source-webpack-plugin');
const LodashModuleReplacementPlugin = require('lodash-webpack-plugin');

const pkg = require('../package');

if (process.env.NODE_ENV !== 'production') {
  const dotenv = require('dotenv').config(); // eslint-disable-line global-require
  if (dotenv.error) {
    require('dotenv').config({ path: '../../../.env' }); // eslint-disable-line global-require
  }
}

const ROOT_DIR = path.resolve(__dirname, '..');
const SRC_DIR = path.join(ROOT_DIR, 'src');
const BUILD_DIR = path.join(ROOT_DIR, 'build');
const NODE_MODULES_DIR = path.join(ROOT_DIR, 'node_modules');
const UILIB_DIR = path.join(NODE_MODULES_DIR, '@bala3nadh');

const isDebug = !process.argv.includes('--release');
const isVerbose = process.argv.includes('--verbose');
const isAnalyze =
  process.argv.includes('--analyze') || process.argv.includes('--analyse');

const jsRegex = /\.(js|jsx|ts|tsx)$/;
const lessRegex = /\.less$/;
const cssRegex = /\.css$/;
const imgRegex = /\.(bmp|gif|jpg|jpeg|png)$/;
const fileRegex = /\.(json|txt|md|wsdl)$/;
const svgRegex = /\.svg$/;

const staticAssetName = isDebug
  ? '[path][name].[ext]?[hash:8]'
  : '[hash:8].[ext]';
const locales = /en|ar/;
const globals = {
  GIT_SHORT: JSON.stringify(git.short()),
  GIT_LONG: JSON.stringify(git.long()),
  GIT_BRANCH: JSON.stringify(git.branch()),
  GIT_DATE: JSON.stringify(git.date()),
  GIT_TAG: JSON.stringify(git.tag()),
  APP_NESTED_PATH: JSON.stringify(`${process.env.APP_NESTED_PATH || ''}`),
  GLOBAL_CONTEXT: JSON.stringify(
    `${process.env.GLOBAL_CONTEXT_MICROSERVICE || ''}`,
  ),
  ESRI_JS_MAP_API: JSON.stringify(`${process.env.ESRI_JS_MAP_API || ''}`),
  COMPOSE_PROJECT_NAME: JSON.stringify(
    `${process.env.COMPOSE_PROJECT_NAME || ''}`,
  ),
  API_SERVER_URL: `"${process.env.API_SERVER_URL}"`,
  __DEV__: isDebug,
};

const excludeFiles = [
  /\.spec\.js$/,
  /test\.js$/,
  /\.js\.snap$/,
  /__snapshots__/,
  /.*\.story\.js$/,
];

const excludeForRelease = [/react-error-overlay\/lib\/.*/];

/**
 * Style loader generator
 * @param {Object} cssOptions
 * @param {string} preProcessor
 * @param {Object} preProcessorOptions
 * @returns {Array}
 */
const getStyleLoaders = (cssOptions, preProcessor, preProcessorOptions) => {
  const loaders = [
    {
      loader: isDebug
        ? require.resolve('style-loader')
        : MiniCssExtractPlugin.loader,
    },
    {
      loader: require.resolve('css-loader'),
      options: cssOptions,
    },
    {
      // Options for PostCSS as we reference these options twice
      // Adds vendor prefixing based on your specified browser support in
      // package.json
      loader: require.resolve('postcss-loader'),
      options: {
        // Necessary for external CSS imports to work
        config: {
          path: path.join(ROOT_DIR, 'tools/postcss.config'),
        },
      },
    },
  ];

  if (preProcessor) {
    loaders.push({
      loader: require.resolve(preProcessor),
      options: preProcessorOptions,
    });
  }

  return loaders;
};

//
// Common configuration chunk to be used for both
// client-side (client.js) and server-side (server.js) bundles
// -----------------------------------------------------------------------------

const commonConfig = {
  context: ROOT_DIR,

  mode: isDebug ? 'development' : 'production',
  output: {
    path: `${BUILD_DIR}/public/assets`,
    publicPath: `${process.env.APP_NESTED_PATH || ''}/assets/`.replace(
      '//',
      '/',
    ),
    pathinfo: isVerbose,
    filename: isDebug ? '[name].js' : '[name].[chunkhash:8].js',
    chunkFilename: isDebug
      ? '[name].chunk.js'
      : '[name].[chunkhash:8].chunk.js',
    // Point sourcemap entries to original disk location (format as URL on Windows)
    devtoolModuleFilenameTemplate: info =>
      path.resolve(info.absoluteResourcePath).replace(/\\/g, '/'),
  },

  resolve: {
    // Allow absolute paths in imports, e.g. import Button from 'components/Button'
    // Keep in sync with .eslintrc
    extensions: ['.js', '.jsx', '.ts', '.tsx', '.json'],
    modules: ['node_modules', 'src'],
    unsafeCache: true,
    symlinks: false,
  },

  module: {
    // Make missing exports an error instead of warning
    strictExportPresence: true,

    rules: [
      {
        test: [...excludeFiles, ...(isDebug ? [] : excludeForRelease)],
        include: [SRC_DIR, UILIB_DIR, NODE_MODULES_DIR],
        use: 'null-loader',
      },
      // Convert plain text into JS module
      {
        test: /\.txt$/,
        loader: 'raw-loader',
      },
      // Convert plain text into JS module
      {
        test: /\.wsdl$/,
        loader: 'raw-loader',
        options: {
          name: staticAssetName,
        },
      },
      // Convert Markdown into HTML
      {
        test: /\.md$/,
        loader: path.join(ROOT_DIR, 'tools/lib/markdown-loader'),
      },
      // Exclude dev modules from production build
      ...(!isDebug
        ? [
            {
              test: path.join(NODE_MODULES_DIR, 'react-deep-force-update/lib'),
              loader: 'null-loader',
            },
          ]
        : []),
    ],
  },

  // Don't attempt to continue if there are any errors.
  bail: !isDebug,

  cache: isDebug,

  // Specify what bundle information gets displayed
  stats: isVerbose ? 'verbose' : 'minimal',

  // Choose a developer tool to enhance debugging
  devtool: isDebug ? 'source-map' : false,
  plugins: [
    ...excludeFiles.map(re => new webpack.IgnorePlugin(re)),
    ...(isDebug
      ? [
          new HardSourceWebpackPlugin({
            environmentHash: {
              root: ROOT_DIR,
              directories: [],
              files: ['yarn.lock', '.env'],
            },
          }),
        ]
      : []),
    new webpack.ContextReplacementPlugin(/moment[/\\]locale$/, locales),
  ],
};

//
// Configuration for the client-side bundle (client.js)
// -----------------------------------------------------------------------------

const clientConfig = {
  ...commonConfig,

  name: 'client',
  target: 'web',

  entry: {
    client: path.join(SRC_DIR, 'client/client'),
  },

  module: {
    ...commonConfig.module,

    rules: [
      {
        test: jsRegex,
        include: [SRC_DIR, UILIB_DIR],
        exclude: [
          ...excludeFiles,
          path.join(
            NODE_MODULES_DIR,
            `@bala3nadh/ui-lib-v2-chat-bot/node_modules/axios`,
          ),
        ],
        use: [
          {
            loader: require.resolve('babel-loader'),
            options: {
              babelrc: false,
              presets: [
                [
                  require.resolve('@babel/preset-env'),
                  {
                    modules: false,
                    targets: {
                      browsers: ['> 1%', 'ie >= 11'],
                    },
                    useBuiltIns: 'usage',
                    corejs: { version: 2 },
                  },
                ],
                require.resolve('@babel/preset-typescript'),
                require.resolve('@babel/preset-react'),
              ],
              plugins: [
                // [
                //   require.resolve('babel-plugin-import'),
                //   {
                //     libraryName: 'antd',
                //     libraryDirectory: 'es',
                //     style: 'css',
                //   },
                // ],
                require.resolve('@babel/plugin-proposal-class-properties'),
                require.resolve('@babel/plugin-proposal-optional-chaining'),
                require.resolve('@babel/plugin-syntax-dynamic-import'),
                require.resolve('babel-plugin-lodash'),
                ...(isDebug
                  ? []
                  : [
                      require.resolve(
                        '@babel/plugin-transform-react-constant-elements',
                      ),
                      // require.resolve('babel-plugin-transform-remove-console'),
                    ]),
              ],
              // This is a feature of `babel-loader` for webpack (not Babel itself).
              // It enables caching results in ./node_modules/.cache/babel-loader/
              // directory for faster rebuilds.
              cacheDirectory: true,
              // Gzipping the cache
              cacheCompression: !isDebug,
              compact: !isDebug,
            },
          },
        ],
      },
      {
        test: cssRegex,
        include: [SRC_DIR, UILIB_DIR],
        use: getStyleLoaders({
          importLoaders: 1,
          sourceMap: isDebug,
        }),
      },
      {
        test: lessRegex,
        include: [SRC_DIR, UILIB_DIR],
        use: getStyleLoaders(
          {
            importLoaders: 2,
            sourceMap: isDebug,
          },
          'less-loader',
        ),
      },
      {
        test: imgRegex,
        oneOf: [
          // Inline lightweight images into CSS
          {
            issuer: cssRegex,
            oneOf: [
              // Inline lightweight images as Base64 encoded DataUrl string
              {
                loader: require.resolve('url-loader'),
                options: {
                  name: staticAssetName,
                  limit: 4096, // 4kb
                },
              },
            ],
          },
          // Or return public URL to image resource
          {
            loader: require.resolve('file-loader'),
            options: {
              name: staticAssetName,
            },
          },
        ],
      },
      {
        test: svgRegex,
        oneOf: [
          {
            // from @bala3nadh/ui-lib-v2-icon
            issuer: /svgIcons.js$/,
            use: [
              {
                loader: require.resolve('babel-loader'),
                options: {
                  babelrc: false,
                  presets: [
                    [
                      require.resolve('@babel/preset-env'),
                      {
                        modules: false,
                        targets: {
                          browsers: ['> 1%', 'ie >= 11'],
                        },
                        useBuiltIns: 'usage',
                        corejs: { version: 2 },
                      },
                    ],
                    require.resolve('@babel/preset-react'),
                  ],
                },
              },
              {
                // Inline lightweight SVGs as React components (for @bala3nadh/ui-lib-v2-icon)
                loader: require.resolve('react-svg-loader'),
                options: {
                  jsx: true, // true outputs JSX tags
                  svgo: {
                    plugins: [{ removeTitle: false }, { removeViewBox: false }],
                  },
                },
              },
            ],
          },
          {
            // Inline lightweight SVGs as UTF-8 encoded DataUrl string
            loader: require.resolve('svg-url-loader'),
            options: {
              name: staticAssetName,
              limit: 1024, // 1kb
            },
          },
        ],
      },

      ...commonConfig.module.rules,

      // Return public URL for all assets unless explicitly excluded
      // DO NOT FORGET to update `exclude` list when you adding a new loader
      {
        exclude: [
          jsRegex,
          cssRegex,
          lessRegex,
          imgRegex,
          fileRegex,
          svgRegex,
          ...excludeFiles,
        ],
        loader: 'file-loader',
        options: {
          name: staticAssetName,
        },
      },
    ],
  },

  plugins: [
    ...commonConfig.plugins,
    // Environment variables
    new webpack.EnvironmentPlugin({
      BROWSER: true,
    }),
    // Define global variables
    new webpack.DefinePlugin(
      Object.assign({}, globals, {
        RAVEN_LOGGING_DSN: process.env.RAVEN_LOGGING_DSN
          ? `"${process.env.RAVEN_LOGGING_DSN}"`
          : false,
      }),
    ),
    // Emit a file with assets paths
    new WebpackAssetsManifest({
      output: `${BUILD_DIR}/asset-manifest.json`,
      publicPath: true,
      writeToDisk: true,
      customize: ({ key, value }) => {
        // You can prevent adding items to the manifest by returning false.
        if (key.toLowerCase().endsWith('.map')) return false;
        return { key, value };
      },
      done: (manifest, stats) => {
        // Write chunk-manifest.json.json
        const chunkFileName = `${BUILD_DIR}/chunk-manifest.json`;
        try {
          const fileFilter = file => !file.endsWith('.map');
          const addPath = file => manifest.getPublicPath(file);
          const chunkFiles = stats.compilation.chunkGroups.reduce((acc, c) => {
            acc[c.name] = [
              ...(acc[c.name] || []),
              ...c.chunks.reduce(
                (files, cc) => [
                  ...files,
                  ...cc.files.filter(fileFilter).map(addPath),
                ],
                [],
              ),
            ];
            return acc;
          }, Object.create(null));
          fs.writeFileSync(chunkFileName, JSON.stringify(chunkFiles, null, 2));
        } catch (err) {
          console.error(`ERROR: Cannot write ${chunkFileName}: `, err);
          if (!isDebug) process.exit(1);
        }
      },
    }),
    new MiniCssExtractPlugin({
      filename: '[name].css',
      chunkFilename: '[contenthash].css',
    }),
    new LodashModuleReplacementPlugin(),
    ...(isDebug
      ? []
      : [
          ...(isAnalyze
            ? [new BundleAnalyzerPlugin({ generateStatsFile: true })]
            : []),
        ]),
  ],

  optimization: {
    minimizer: [
      ...(isDebug
        ? []
        : [
            new OptimizeCSSAssetsPlugin({}),
            new TerserPlugin({
              terserOptions: {
                mangle: {
                  // Work around the Safari 10 loop iterator bug
                  safari10: true,
                },
                output: {
                  // Avoid building with comments
                  comments: false,
                  // Turned on because emoji and regex is not minified properly using default
                  ascii_only: true,
                },
                keep_fnames: true,
              },
              // Use multi-process parallel running to improve the build speed
              parallel: true,
              // Enable file caching
              cache: true,
            }),
          ]),
    ],
    // Automatically split vendor and commons
    splitChunks: {
      chunks: 'all',
      maxSize: 3000000,
      minSize: 1000000,
    },
  },

  // Some libraries import Node modules but don't use them in the browser.
  // Tell Webpack to provide empty mocks for them so importing them works.
  node: {
    fs: 'empty',
    net: 'empty',
    tls: 'empty',
  },
};

//
// Configuration for the server-side bundle (server.js)
// -----------------------------------------------------------------------------

const serverConfig = {
  ...commonConfig,

  name: 'server',
  target: 'node',

  entry: {
    server: ['@babel/polyfill', path.join(SRC_DIR, 'server/server')],
  },

  devtool: 'source-map',

  output: {
    ...commonConfig.output,
    path: BUILD_DIR,
    filename: '[name].js',
    chunkFilename: 'chunks/[name].js',
    libraryTarget: 'commonjs2',
  },

  // Webpack mutates resolve object, so clone it to avoid issues
  resolve: {
    ...commonConfig.resolve,
  },

  module: {
    ...commonConfig.module,

    rules: [
      {
        test: jsRegex,
        include: SRC_DIR,
        exclude: [...excludeFiles],
        loader: require.resolve('babel-loader'),
        options: {
          cacheDirectory: isDebug,
          babelrc: false,
          presets: [
            [
              require.resolve('@babel/preset-env'),
              {
                targets: {
                  node: pkg.engines.node.match(/(\d+\.?)+/)[0],
                },
              },
            ],
            require.resolve('@babel/preset-typescript'),
            require.resolve('@babel/preset-react'),
          ],
          plugins: [
            require.resolve('@babel/plugin-proposal-class-properties'),
            require.resolve('@babel/plugin-proposal-optional-chaining'),
          ],
        },
      },
      ...commonConfig.module.rules,
      {
        exclude: [jsRegex, fileRegex, ...excludeFiles],
        loader: 'file-loader',
        options: {
          name: `public/assets/${staticAssetName}`,
          publicPath: url => url.replace(/^public/, ''),
        },
      },
    ],
  },

  externals: [
    './chunk-manifest.json',
    './asset-manifest.json',
    nodeExternals({
      allowlist: [cssRegex, imgRegex],
    }),
  ],

  plugins: [
    ...commonConfig.plugins,
    // Environment variables
    new webpack.EnvironmentPlugin({
      BROWSER: false,
    }),
    // Define free variables
    new webpack.DefinePlugin(globals),
    // Adds a banner to the top of each generated chunk
    new webpack.BannerPlugin({
      banner: 'require("source-map-support").install();',
      raw: true,
      entryOnly: false,
    }),
  ],

  // Do not replace node globals with polyfills
  node: {
    console: false,
    global: false,
    process: false,
    Buffer: false,
    __filename: false,
    __dirname: false,
  },
};

module.exports = [clientConfig, serverConfig];
