const GSPService = require('@bala3nadh/gsp').default;

const gspConfig = require('../../src/server/config/gsp.json');

if (process.env.NODE_ENV !== 'production') {
  const dotenv = require('dotenv').config(); // eslint-disable-line global-require
  if (dotenv.error) {
    require('dotenv').config({ path: '../../../.env' }); // eslint-disable-line global-require
  }
}

function cache() {
  const service = GSPService({
    gateway: {
      header: process.env.API_GATEWAY_HEADER || '',
      key: process.env.API_GATEWAY_KEY || '',
    },
    services: {
      url: `${process.env.GSP_HOST}${process.env.GSP_SERVICES_ENDPOINT}`,
      path: process.env.GSP_BASE_CACHE_DIR || 'public/gsp',
      config: gspConfig,
    },
  });

  service.scripts
    .cache()
    .then(() => console.info('GSP data fetched and cached successfully'))
    .catch(err => {
      console.info('GSP data failed to cache');
      throw err;
    });
}

cache();
