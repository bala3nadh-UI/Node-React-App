const GSPService = require('@bala3nadh/gsp').default;
const gspConfig = require('../../src/server/config/gsp.json');

if (process.env.NODE_ENV !== 'production') {
  const dotenv = require('dotenv').config(); // eslint-disable-line global-require
  if (dotenv.error) {
    require('dotenv').config({ path: '../../../.env' }); // eslint-disable-line global-require
  }
}

function cache() {
  const service = GSPService({
    gateway: {
      header: process.env.API_GATEWAY_HEADER || '',
      key: process.env.API_GATEWAY_KEY || '',
    },
    services: {
      url: `${process.env.GSP_HOST}${process.env.GSP_SERVICES_ENDPOINT}`,
      path: process.env.GSP_BASE_CACHE_DIR || 'public/gsp',
      config: gspConfig,
    },
    servicesAll: {
      path: process.env.GSP_PATH_BASE_CACHE_DIR || 'public/gsp-path',
      endpointAdgeList: `${process.env.GSP_HOST}${process.env.GSP_ADGE_LIST_ENDPOINT}`,
      endpointAdgeServiceList: `${process.env.GSP_HOST}${process.env.GSP_SERVICES_BY_ADGE_ENDPOINT}`,
      endpointServiceByPath: `${process.env.GSP_HOST}${process.env.GSP_SERVICE_BY_PATH_ENDPOINT}`,
    },
  });
  service.scripts
    .cacheAll()
    .then(() => console.info('GSP data fetched and cached successfully'))
    .catch(err => {
      console.error('GSP data failed to cache');
      throw err;
    });
}
cache();
