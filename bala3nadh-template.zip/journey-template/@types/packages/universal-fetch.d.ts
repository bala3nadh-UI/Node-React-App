declare module 'universal-fetch' {
  export default function(url: string, options: any): Promise<any>;
}
