declare module 'react-deep-force-update' {
  export default function(
    instance: any,
    shouldUpdate?: () => boolean,
    onUpdate?: () => any,
  ): any
}
