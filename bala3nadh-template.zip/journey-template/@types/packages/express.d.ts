declare namespace Express {
  interface Request {
    log: any;
    logUuid: string;
    cms: any;
    cmsJourneyInfo: any;
    resetSessionID: any;
  }

  interface Application {
    hot: any;
  }
}
