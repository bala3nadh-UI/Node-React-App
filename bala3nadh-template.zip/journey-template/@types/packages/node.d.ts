declare namespace NodeJS {
  interface Global {
    document: Document;
    window: Window;
    navigator: UserAgentNavigator;
  }

  interface UserAgentNavigator extends Navigator {
    userAgent: string;
  }
}

interface NodeModule {
  hot: {
    accept(path?: string, fn?: () => void, callback?: () => void): void;
  };
}
