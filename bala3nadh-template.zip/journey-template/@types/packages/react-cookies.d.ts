declare module 'react-cookies' {
  export function load(name: string, doNotParse?: boolean): any;
  export function loadAll(doNotParse: boolean): any;
  export function select(regex: string): any;
  export function save(name: string, val: any, opt: any): any;
  export function remove(name: string, opt: any): any;
  export function setRawCookie(rawCookie: any): any;
  export function plugToRequest(req: any, res: any): any;
}
