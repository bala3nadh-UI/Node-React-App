declare module '@bala3nadh/*'; // TODO: remove this line after @bala3nadh/module definitions would be provided

declare module '*.jpg';

declare const __DEV__: boolean; // eslint-disable-line no-underscore-dangle

declare const APP_NESTED_PATH: string;
declare const ESRI_JS_MAP_API: string;
declare const COMPOSE_PROJECT_NAME: string;
declare const GLOBAL_CONTEXT: string;

declare const GIT_TAG: string;
declare const GIT_SHORT: string;
declare const GIT_LONG: string;
declare const GIT_BRANCH: string;
declare const GIT_DATE: string;

declare const Analytics: any;
