declare namespace Redux {
  type Action<T = string> = {
    type: T
  }

  type ActionCreators<A> = {
    [key: string]: (...args: any[]) => A
  }

  type AnyService = {
    [key: string]: (...args: any[]) => any;
  };

  type AnyAction = Action<string | undefined> & { [actionProp: string]: any };

  type Actions = {
    actions: ActionCreators<AnyAction>;
  }

  type Reducer = (state: any | undefined, action: AnyAction) => any;

  type BaseObject = {
    name: string;
    reducer: Reducer;
  }

  type Output<T> = T & BaseObject;

  type Services = {
    Api: AnyService;
    ErrorHandler: AnyService;
  }
}
