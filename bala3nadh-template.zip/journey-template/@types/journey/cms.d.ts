declare namespace CMS {
  type EmergencyNumbersItems = {
    label: string;
    number: string | number;
  };

  interface NavigationItems {
    key: string;
    url: string;
    text: string;
    isVisible: boolean;
  }

  interface QuickMenuItems {
    chatLink: string;
    messageLink: string;
    feedbackLink: string;
    coCreateLink: string;
  }

  interface EmergencyNumbers {
    emergencyHeading: string;
    emergencyLabel: string;
    items: EmergencyNumbersItems[];
  }

  interface PoweredByLinks {
    title: string;
    image: string;
    url: string;
  }

  interface Page {
    id: string;
    title: string;
    description: string;
    link: string;
    keywords: string;
    short_description: string; // eslint-disable-line camelcase
    meta_description: string; // eslint-disable-line camelcase
  }

  interface PageMeta {
    [key: string]: Page;
  }

  interface BaseLink {
    label: string;
    link: string;
  }
}
