const { env } = process;

module.exports = {
  presets: [
    [
      '@babel/preset-env',
      {
        targets: {
          node: 'current',
        },
      },
    ],
  ],
  ignore: ['node_modules/(?!(@bala3nadh|@amcharts))', 'build'],
  env: {
    test: {
      presets: [
        ['@babel/preset-env'],
        '@babel/preset-typescript',
        '@babel/preset-react',
      ],
      plugins: [
        '@babel/plugin-proposal-class-properties',
        '@babel/plugin-proposal-optional-chaining',
        'dynamic-import-node',
      ],
    },
    development: {
      plugins: [...(env.STAGING === 'true' ? ["istanbul"] : [])],
    },
    production: {
      plugins: [...(env.STAGING === 'true' ? ["istanbul"] : [])],
    },
  },
};
