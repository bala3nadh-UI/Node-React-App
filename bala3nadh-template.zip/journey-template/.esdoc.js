module.exports = {
  source: './src',
  destination: './esdoc',
  plugins: [
    { name: 'esdoc-standard-plugin' },
    {
      name: 'esdoc-ecmascript-proposal-plugin',
      option: {
        classProperties: true,
        objectRestSpread: true,
        decorators: true,
        doExpressions: true,
        functionBind: true,
        asyncGenerators: true,
        exportExtensions: true,
        dynamicImport: true,
      },
    },
    // { name: 'esdoc-es7-plugin' },
    {
      name: 'esdoc-importpath-plugin',
      option: {
        stripPackageName: false,
        replaces: [
          { from: '^client/', to: 'src/client/' },
          { from: '^server/', to: 'src/server/' },
        ],
      },
    },
    { name: 'esdoc-jsx-plugin' },
    { name: 'esdoc-react-plugin' },
    { name: 'esdoc-external-ecmascript-plugin' },
    {
      name: 'esdoc-integrate-test-plugin',
      option: {
        source: './src/',
        interfaces: ['describe', 'it', 'context', 'suite', 'test'],
        includes: ['(spec|Spec|test|Test)\\.js$'],
        excludes: ['\\.config\\.js$'],
      },
    },
    { name: 'esdoc-undocumented-identifier-plugin' },
    // {
    //   name: 'esdoc-coverage-plugin',
    //   option: {
    //     enable: true,
    //     kind: [
    //       'class',
    //       'method',
    //       'member',
    //       'get',
    //       'set',
    //       'constructor',
    //       'function',
    //       'variable',
    //     ],
    //   },
    // },
    { name: 'esdoc-lint-plugin', option: { enable: true } },
    { name: 'esdoc-type-inference-plugin', option: { enable: true } },
    {
      name: 'esdoc-publish-markdown-plugin',
      option: {
        filename: 'ESDOC.md',
      },
    },
  ],
};
